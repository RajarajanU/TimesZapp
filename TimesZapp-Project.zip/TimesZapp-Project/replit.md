# TimesZapp - Minutz AI

## Overview

TimesZapp is a full-stack web application that provides an AI-powered social media aggregator. It unifies multiple social networks (Gmail, Facebook, Instagram, LinkedIn, WhatsApp, Twitter/X) into one intelligent dashboard. The application features a modern UI with real-time chat capabilities, unified feed from all connected networks, and AI assistance powered by OpenAI. Built as a monorepo with a React frontend and Express backend, it uses PostgreSQL for data persistence and OpenAI for AI capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, providing fast HMR and optimized production builds
- **Wouter** for lightweight client-side routing instead of React Router

**UI & Styling**
- **Tailwind CSS v4** (using `@tailwindcss/vite`) for utility-first styling with custom design tokens
- **shadcn/ui** component library (New York variant) built on Radix UI primitives
- **Framer Motion** for complex animations and transitions (AI avatar, notifications, widgets)
- Custom fonts: Orbitron, Rajdhani, and Inter for a futuristic aesthetic

**State Management**
- **TanStack Query (React Query)** for server state management, caching, and data synchronization
- Local React state (useState, useEffect) for UI-specific state
- Browser APIs: localStorage for authentication tokens and session persistence

**Key Features**
- Speech recognition and synthesis using Web Speech API
- Real-time geolocation tracking for context-aware assistance
- Multi-view dashboard: chat, notifications, services, social media
- Responsive design with mobile breakpoints

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript running on Node.js
- HTTP server with CORS enabled for cross-origin requests
- Custom logging middleware for request tracking
- JSON body parsing with raw body preservation for webhook handling

**Development Setup**
- **Hot Module Replacement (HMR)** in development via Vite middleware integration
- Production builds use esbuild to bundle server code with selective dependency bundling (allowlist approach to reduce cold start times)
- Separation of concerns: development uses tsx for TypeScript execution, production runs compiled JavaScript

**API Design**
- RESTful endpoints for user management, authentication, conversations, messages, services, and notifications
- Password-based authentication with bcrypt hashing
- Session management considered (connect-pg-simple imported but implementation not shown in provided files)

### Database Architecture

**ORM & Database**
- **Drizzle ORM** with PostgreSQL dialect for type-safe database operations
- **Neon Serverless** (@neondatabase/serverless) as the PostgreSQL client with WebSocket support
- Connection pooling (max 10 connections, 30s idle timeout, 10s connection timeout)
- Retry mechanism for database operations to handle transient network failures

**Schema Design**
The database schema supports a multi-user AI assistant platform:

1. **Users Table**: Stores user credentials (email, name, hashed password) with created timestamp
2. **Conversations Table**: Tracks chat sessions with title, timestamps, and user relationship
3. **Messages Table**: Stores individual messages with role (user/assistant/system), content, optional metadata for rich content (charts, images), and timestamps
4. **Connected Services Table**: OAuth integrations storing service name, access/refresh tokens, and expiration times
5. **Notifications Table**: Aggregated notifications from connected services with source, type, title, description, read status, and metadata
6. **Password Reset Tokens Table**: Temporary tokens for password recovery with expiration

**Data Relationships**
- One-to-many: Users → Conversations, Users → Connected Services, Users → Notifications
- One-to-many: Conversations → Messages
- Uses Drizzle relations for type-safe joins and data fetching

**Migration Strategy**
- Schema defined in `shared/schema.ts` for sharing between client and server
- Drizzle Kit for schema migrations with `db:push` command
- Migration files output to `./migrations` directory

### AI Integration

**OpenAI Integration**
- Uses OpenAI SDK with Replit AI Integrations support
- Falls back to standard OpenAI endpoint if Replit integration not available
- System prompt defines AI capabilities: Jarvis/Friday-style proactive assistant with email access, trend detection, source verification, and travel assistance
- OpenAI function calling with AI tools: fetch_social_items, detect_trends, classify_source_trust, travel_assist, daily_digest

**AI Tools System (server/ai-tools.ts)**
- `fetchSocialItems`: Retrieves normalized data from connected networks (Gmail fully integrated, others stubbed pending API keys)
- `detectTrends`: Analyzes social items for trending topics using word frequency and generates summaries
- `classifySourceTrust`: Evaluates source reliability with heuristics (known domains, engagement patterns)
- `travelAssist`: Weather via Open-Meteo API, safety tips, packing suggestions for mentioned destinations
- `generateDailyDigest`: Creates 24-hour activity summary across all connected networks
- `generateDocument`: Creates downloadable documents in multiple formats (Word, PDF, text, Excel, PowerPoint) for resumes, CVs, and cover letters
- Connection date filtering ensures only data since service connection is analyzed

**Document Generation (server/documents.ts)**
- Multi-format resume generation using:
  - `docx` library for Word documents (.docx)
  - `pdfkit` library for PDF documents (.pdf)
  - Plain text generation for .txt files
  - `exceljs` library for Excel spreadsheets (.xlsx) with multiple sheets
  - `pptxgenjs` library for PowerPoint presentations (.pptx) with slides
- Professional resume templates with consistent styling across all formats
- Secure file handling with path traversal protection
- Download endpoint with proper content-type headers for each format

**AI Capabilities Design**
- Jarvis/Friday-style proactive assistance with context awareness
- Multi-turn conversations with context preservation
- Proactive intent detection for automatic tool invocation (travel mentions, trend requests, digest requests)
- Intent detection for routing requests to appropriate services
- Metadata support in messages for rich responses (charts, job applications, media galleries)
- Safe math evaluation (no eval) for arithmetic expressions
- User approval workflow for sensitive actions

**Insights UI (Dashboard → Insights)**
- New Insights panel showing AI-analyzed trends from connected networks
- Trending topics grid with mention counts
- Trend cards with sentiment coloring (positive/negative/neutral)
- Connected networks status with availability indicators
- Quick actions to ask AI for daily digest or trend analysis
- Stored insights persisted to ai_insights table for future reference

**Mr Techie - Autonomous Tech News Agent (server/mr-techie.ts)**
- Autonomous agent that fetches top 10 technology news insights every hour
- Uses OpenAI to generate curated tech news across categories: AI & Machine Learning, Mobile Tech, Web Development, Cybersecurity, Cloud Computing, Startups, Hardware, Software, Blockchain, Gaming
- News stored in `tech_news` table with hour buckets for organization
- Dedicated sidebar section in dashboard for viewing hourly tech updates
- Browser push notifications support for hourly alerts (when enabled)
- API endpoints: GET /api/tech-news, POST /api/tech-news/fetch, GET /api/tech-news/current

**Browser Push Notifications (client/src/hooks/use-push-notifications.ts)**
- Web Notification API integration for desktop alerts
- Permission management for notification access
- Hourly tech news notifications when enabled in Mr Techie section
- Non-intrusive browser alerts with top 3 news headlines

## External Dependencies

### Third-Party Services

**AI Services**
- **OpenAI API**: Primary AI model for natural language understanding and generation
- **Replit AI Integrations**: Managed OpenAI endpoint when running on Replit platform

**Database**
- **Neon Database**: Serverless PostgreSQL provider (DATABASE_URL environment variable required)
- Uses WebSocket connections for serverless compatibility

**Authentication & OAuth** (Planned/Partial Implementation)
- **Passport.js** with passport-local strategy for authentication
- OAuth integrations implied for Gmail, LinkedIn, Twitter, Facebook, Instagram (connect-pg-simple for session storage)

**Frontend Services**
- **Google Fonts API**: Orbitron, Rajdhani, Inter font families
- **Browser APIs**: Web Speech API (recognition & synthesis), Geolocation API

### Build & Development Tools

**Replit-Specific Plugins**
- `@replit/vite-plugin-runtime-error-modal`: Error overlay in development
- `@replit/vite-plugin-cartographer`: Development navigation helper
- `@replit/vite-plugin-dev-banner`: Development mode indicator
- Custom `vite-plugin-meta-images`: Updates OpenGraph meta tags with Replit deployment URLs

**Code Quality**
- TypeScript for type safety across frontend, backend, and shared code
- Zod for runtime validation with drizzle-zod for schema validation
- ESModules throughout the codebase

### UI Component Libraries

**Radix UI Primitives** (30+ components)
- Headless UI components for accessibility: Dialog, Dropdown, Popover, Tooltip, Accordion, Tabs, etc.
- Provides ARIA-compliant, keyboard-navigable, and screen-reader-friendly interactions

**Utility Libraries**
- `class-variance-authority`: Component variant management
- `clsx` & `tailwind-merge`: Conditional className composition
- `cmdk`: Command palette component
- `date-fns`: Date manipulation and formatting
- `nanoid`: Unique ID generation

### Potential Additional Services (Based on Code Structure)

The codebase references several services not fully implemented in the provided files:
- Gmail API integration for email access
- LinkedIn API for professional networking features
- Job board integrations for automated applications
- Web search API for current information retrieval
- Notification aggregation from multiple platforms