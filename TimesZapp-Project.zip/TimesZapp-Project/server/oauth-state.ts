const oauthStates = new Map<string, { userId: number; platform: string; createdAt: number }>();

const STATE_TTL = 10 * 60 * 1000;

export function generateOAuthState(userId: number, platform: string): string {
  const state = Buffer.from(JSON.stringify({ 
    userId, 
    platform,
    nonce: Math.random().toString(36).substring(2) + Date.now()
  })).toString("base64");
  
  oauthStates.set(state, { userId, platform, createdAt: Date.now() });
  
  cleanupExpiredStates();
  
  return state;
}

export function validateOAuthState(state: string): { userId: number; platform: string } | null {
  const stateData = oauthStates.get(state);
  
  if (!stateData) {
    return null;
  }
  
  if (Date.now() - stateData.createdAt > STATE_TTL) {
    oauthStates.delete(state);
    return null;
  }
  
  oauthStates.delete(state);
  
  return { userId: stateData.userId, platform: stateData.platform };
}

function cleanupExpiredStates() {
  const now = Date.now();
  const entries = Array.from(oauthStates.entries());
  for (const [state, data] of entries) {
    if (now - data.createdAt > STATE_TTL) {
      oauthStates.delete(state);
    }
  }
}
