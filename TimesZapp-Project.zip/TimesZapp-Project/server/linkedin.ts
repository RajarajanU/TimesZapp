import { storage } from "./storage";

const LINKEDIN_CLIENT_ID = process.env.LINKEDIN_CLIENT_ID;
const LINKEDIN_CLIENT_SECRET = process.env.LINKEDIN_CLIENT_SECRET;
const LINKEDIN_REDIRECT_URI = process.env.LINKEDIN_REDIRECT_URI || "https://your-app.replit.app/api/linkedin/callback";

interface LinkedInTokens {
  accessToken: string;
  expiresIn: number;
  refreshToken?: string;
}

interface LinkedInProfile {
  id: string;
  firstName: string;
  lastName: string;
  profilePicture?: string;
  email?: string;
}

interface LinkedInStats {
  connections: number;
  posts: number;
  profileViews: number;
  connectedAt?: string;
  isFiltered?: boolean;
}

export function isLinkedInConfigured(): boolean {
  return !!(LINKEDIN_CLIENT_ID && LINKEDIN_CLIENT_SECRET);
}

export function getLinkedInAuthUrl(state: string): string {
  if (!LINKEDIN_CLIENT_ID) {
    throw new Error("LinkedIn Client ID not configured");
  }
  
  const scopes = [
    "openid",
    "profile",
    "email",
    "w_member_social"
  ].join(" ");
  
  const params = new URLSearchParams({
    response_type: "code",
    client_id: LINKEDIN_CLIENT_ID,
    redirect_uri: LINKEDIN_REDIRECT_URI,
    state: state,
    scope: scopes
  });
  
  return `https://www.linkedin.com/oauth/v2/authorization?${params.toString()}`;
}

export async function exchangeLinkedInCode(code: string): Promise<LinkedInTokens> {
  if (!LINKEDIN_CLIENT_ID || !LINKEDIN_CLIENT_SECRET) {
    throw new Error("LinkedIn credentials not configured");
  }
  
  const response = await fetch("https://www.linkedin.com/oauth/v2/accessToken", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code: code,
      client_id: LINKEDIN_CLIENT_ID,
      client_secret: LINKEDIN_CLIENT_SECRET,
      redirect_uri: LINKEDIN_REDIRECT_URI,
    }),
  });
  
  if (!response.ok) {
    const error = await response.text();
    console.error("[LinkedIn] Token exchange failed:", error);
    throw new Error("Failed to exchange LinkedIn authorization code");
  }
  
  const data = await response.json();
  return {
    accessToken: data.access_token,
    expiresIn: data.expires_in,
    refreshToken: data.refresh_token,
  };
}

export async function getLinkedInProfile(accessToken: string): Promise<LinkedInProfile> {
  const response = await fetch("https://api.linkedin.com/v2/userinfo", {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });
  
  if (!response.ok) {
    throw new Error("Failed to fetch LinkedIn profile");
  }
  
  const data = await response.json();
  return {
    id: data.sub,
    firstName: data.given_name || "",
    lastName: data.family_name || "",
    profilePicture: data.picture,
    email: data.email,
  };
}

export async function getLinkedInStats(userId: number): Promise<LinkedInStats | null> {
  const service = await storage.getService(userId, "linkedin");
  if (!service || !service.accessToken) {
    return null;
  }
  
  try {
    const profile = await getLinkedInProfile(service.accessToken);
    
    return {
      connections: 0,
      posts: 0,
      profileViews: 0,
      connectedAt: service.connectedAt?.toISOString(),
      isFiltered: false,
    };
  } catch (error) {
    console.error("[LinkedIn] Failed to get stats:", error);
    return null;
  }
}

export async function checkLinkedInConnection(userId: number): Promise<{ connected: boolean; profile?: LinkedInProfile }> {
  const service = await storage.getService(userId, "linkedin");
  if (!service || !service.accessToken) {
    return { connected: false };
  }
  
  try {
    const profile = await getLinkedInProfile(service.accessToken);
    return { connected: true, profile };
  } catch (error) {
    console.error("[LinkedIn] Connection check failed:", error);
    return { connected: false };
  }
}
