import {
  Document,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  BorderStyle,
  Packer,
  Table,
  TableRow,
  TableCell,
  WidthType,
  ShadingType,
} from "docx";
import PDFDocument from "pdfkit";
import ExcelJS from "exceljs";
import PptxGenJS from "pptxgenjs";
import * as fs from "fs";
import * as path from "path";

export type DocumentFormat = "docx" | "pdf" | "txt" | "xlsx" | "pptx";

export interface GeneratedDocument {
  filename: string;
  filepath: string;
  format: DocumentFormat;
}

interface ExperienceEntry {
  title: string;
  company: string;
  location?: string;
  startDate: string;
  endDate?: string;
  responsibilities?: string[];
}

interface EducationEntry {
  degree: string;
  institution: string;
  year: string;
  gpa?: string;
}

interface ResumeData {
  fullName: string;
  email?: string;
  phone?: string;
  location?: string;
  linkedin?: string;
  summary?: string;
  experience?: ExperienceEntry[];
  education?: EducationEntry[];
  skills?: string[];
  certifications?: string[];
  languages?: string[];
}

const uploadsDir = path.join(process.cwd(), "uploads");

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

function createContactInfo(data: ResumeData): Paragraph {
  const contactParts: string[] = [];
  if (data.email) contactParts.push(data.email);
  if (data.phone) contactParts.push(data.phone);
  if (data.location) contactParts.push(data.location);
  if (data.linkedin) contactParts.push(data.linkedin);

  return new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text: contactParts.join(" | "),
        size: 20,
        color: "666666",
      }),
    ],
    spacing: { after: 200 },
  });
}

function createSectionHeader(title: string): Paragraph {
  return new Paragraph({
    children: [
      new TextRun({
        text: title.toUpperCase(),
        bold: true,
        size: 24,
        color: "2C3E50",
      }),
    ],
    border: {
      bottom: {
        color: "2C3E50",
        space: 1,
        style: BorderStyle.SINGLE,
        size: 6,
      },
    },
    spacing: { before: 300, after: 150 },
  });
}

function createExperienceEntry(exp: ExperienceEntry): Paragraph[] {
  const paragraphs: Paragraph[] = [];

  paragraphs.push(
    new Paragraph({
      children: [
        new TextRun({
          text: exp.title,
          bold: true,
          size: 22,
        }),
        new TextRun({
          text: ` | ${exp.company}`,
          size: 22,
        }),
      ],
    })
  );

  const dateLocation = [];
  if (exp.location) dateLocation.push(exp.location);
  dateLocation.push(`${exp.startDate} - ${exp.endDate || "Present"}`);

  paragraphs.push(
    new Paragraph({
      children: [
        new TextRun({
          text: dateLocation.join(" | "),
          italics: true,
          size: 20,
          color: "666666",
        }),
      ],
      spacing: { after: 100 },
    })
  );

  if (exp.responsibilities) {
    exp.responsibilities.forEach((resp) => {
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `• ${resp}`,
              size: 20,
            }),
          ],
          indent: { left: 360 },
        })
      );
    });
  }

  paragraphs.push(new Paragraph({ spacing: { after: 150 } }));

  return paragraphs;
}

function createEducationEntry(edu: EducationEntry): Paragraph {
  let text = `${edu.degree} - ${edu.institution}, ${edu.year}`;
  if (edu.gpa) text += ` (GPA: ${edu.gpa})`;

  return new Paragraph({
    children: [
      new TextRun({
        text: `• ${text}`,
        size: 20,
      }),
    ],
    indent: { left: 360 },
  });
}

export async function generateResume(data: ResumeData): Promise<{ filename: string; filepath: string }> {
  const children: any[] = [];

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: data.fullName,
          bold: true,
          size: 36,
          color: "2C3E50",
        }),
      ],
      spacing: { after: 100 },
    })
  );

  children.push(createContactInfo(data));

  if (data.summary) {
    children.push(createSectionHeader("Professional Summary"));
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: data.summary,
            size: 20,
          }),
        ],
        spacing: { after: 200 },
      })
    );
  }

  if (data.experience && data.experience.length > 0) {
    children.push(createSectionHeader("Professional Experience"));
    data.experience.forEach((exp) => {
      children.push(...createExperienceEntry(exp));
    });
  }

  if (data.education && data.education.length > 0) {
    children.push(createSectionHeader("Education"));
    data.education.forEach((edu) => {
      children.push(createEducationEntry(edu));
    });
    children.push(new Paragraph({ spacing: { after: 150 } }));
  }

  if (data.skills && data.skills.length > 0) {
    children.push(createSectionHeader("Skills"));
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: data.skills.join(" • "),
            size: 20,
          }),
        ],
        spacing: { after: 150 },
      })
    );
  }

  if (data.certifications && data.certifications.length > 0) {
    children.push(createSectionHeader("Certifications"));
    data.certifications.forEach((cert) => {
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `• ${cert}`,
              size: 20,
            }),
          ],
          indent: { left: 360 },
        })
      );
    });
    children.push(new Paragraph({ spacing: { after: 150 } }));
  }

  if (data.languages && data.languages.length > 0) {
    children.push(createSectionHeader("Languages"));
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: data.languages.join(" • "),
            size: 20,
          }),
        ],
      })
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 720,
              right: 720,
              bottom: 720,
              left: 720,
            },
          },
        },
        children,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  const filename = `resume_${data.fullName.replace(/\s+/g, "_")}_${Date.now()}.docx`;
  const filepath = path.join(uploadsDir, filename);

  fs.writeFileSync(filepath, buffer);

  return { filename, filepath };
}

export async function generateSampleResume(): Promise<{ filename: string; filepath: string }> {
  const sampleData: ResumeData = {
    fullName: "John Doe",
    email: "john.doe@email.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    linkedin: "linkedin.com/in/johndoe",
    summary:
      "Results-driven software engineer with 5+ years of experience in full-stack development. Passionate about building scalable applications and leading cross-functional teams to deliver high-quality products.",
    experience: [
      {
        title: "Senior Software Engineer",
        company: "Tech Corp Inc.",
        location: "San Francisco, CA",
        startDate: "Jan 2021",
        endDate: "Present",
        responsibilities: [
          "Led development of microservices architecture serving 1M+ daily users",
          "Mentored junior developers and conducted code reviews",
          "Reduced API response times by 40% through optimization",
          "Implemented CI/CD pipelines using GitHub Actions and Docker",
        ],
      },
      {
        title: "Software Engineer",
        company: "StartupXYZ",
        location: "San Jose, CA",
        startDate: "Jun 2018",
        endDate: "Dec 2020",
        responsibilities: [
          "Built React-based dashboard for real-time data visualization",
          "Developed RESTful APIs using Node.js and Express",
          "Collaborated with design team to improve UX/UI",
        ],
      },
    ],
    education: [
      {
        degree: "B.S. Computer Science",
        institution: "University of California, Berkeley",
        year: "2018",
        gpa: "3.8",
      },
    ],
    skills: [
      "JavaScript",
      "TypeScript",
      "React",
      "Node.js",
      "Python",
      "PostgreSQL",
      "MongoDB",
      "AWS",
      "Docker",
      "Kubernetes",
      "Git",
      "Agile/Scrum",
    ],
    certifications: [
      "AWS Certified Solutions Architect",
      "Google Cloud Professional Developer",
    ],
    languages: ["English (Native)", "Spanish (Conversational)"],
  };

  return generateResume(sampleData);
}

export async function generateCustomResume(userInput: string): Promise<{ filename: string; filepath: string; data: ResumeData }> {
  const data: ResumeData = {
    fullName: "Your Name",
    email: "your.email@example.com",
    phone: "+1 (555) 000-0000",
    location: "Your City, State",
    summary: "Add your professional summary here. Describe your experience, skills, and career objectives.",
    experience: [
      {
        title: "Job Title",
        company: "Company Name",
        location: "City, State",
        startDate: "Start Date",
        endDate: "End Date or Present",
        responsibilities: [
          "Describe your key responsibility or achievement",
          "Another important accomplishment",
          "Skills or technologies you used",
        ],
      },
    ],
    education: [
      {
        degree: "Your Degree",
        institution: "University/College Name",
        year: "Graduation Year",
      },
    ],
    skills: ["Skill 1", "Skill 2", "Skill 3", "Skill 4", "Skill 5"],
  };

  const result = await generateResume(data);
  return { ...result, data };
}

// ===== PDF Generation =====
export async function generateResumePDF(data: ResumeData): Promise<GeneratedDocument> {
  return new Promise((resolve, reject) => {
    const filename = `resume_${data.fullName.replace(/\s+/g, "_")}_${Date.now()}.pdf`;
    const filepath = path.join(uploadsDir, filename);
    
    const doc = new PDFDocument({ margin: 50 });
    const writeStream = fs.createWriteStream(filepath);
    
    doc.pipe(writeStream);
    
    // Header - Name
    doc.fontSize(24).fillColor('#2C3E50').font('Helvetica-Bold')
       .text(data.fullName, { align: 'center' });
    
    // Contact Info
    const contactParts: string[] = [];
    if (data.email) contactParts.push(data.email);
    if (data.phone) contactParts.push(data.phone);
    if (data.location) contactParts.push(data.location);
    if (data.linkedin) contactParts.push(data.linkedin);
    
    doc.moveDown(0.3);
    doc.fontSize(10).fillColor('#666666').font('Helvetica')
       .text(contactParts.join(' | '), { align: 'center' });
    
    doc.moveDown(1);
    
    // Summary
    if (data.summary) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('PROFESSIONAL SUMMARY');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      doc.fontSize(10).fillColor('#333333').font('Helvetica')
         .text(data.summary);
      doc.moveDown(1);
    }
    
    // Experience
    if (data.experience && data.experience.length > 0) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('PROFESSIONAL EXPERIENCE');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      
      data.experience.forEach(exp => {
        doc.fontSize(11).fillColor('#333333').font('Helvetica-Bold')
           .text(`${exp.title} | ${exp.company}`);
        
        const dateLocation = [];
        if (exp.location) dateLocation.push(exp.location);
        dateLocation.push(`${exp.startDate} - ${exp.endDate || 'Present'}`);
        
        doc.fontSize(9).fillColor('#666666').font('Helvetica-Oblique')
           .text(dateLocation.join(' | '));
        
        if (exp.responsibilities) {
          doc.moveDown(0.3);
          exp.responsibilities.forEach(resp => {
            doc.fontSize(10).fillColor('#333333').font('Helvetica')
               .text(`• ${resp}`, { indent: 20 });
          });
        }
        doc.moveDown(0.5);
      });
      doc.moveDown(0.5);
    }
    
    // Education
    if (data.education && data.education.length > 0) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('EDUCATION');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      
      data.education.forEach(edu => {
        let text = `${edu.degree} - ${edu.institution}, ${edu.year}`;
        if (edu.gpa) text += ` (GPA: ${edu.gpa})`;
        doc.fontSize(10).fillColor('#333333').font('Helvetica')
           .text(`• ${text}`, { indent: 20 });
      });
      doc.moveDown(1);
    }
    
    // Skills
    if (data.skills && data.skills.length > 0) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('SKILLS');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      doc.fontSize(10).fillColor('#333333').font('Helvetica')
         .text(data.skills.join(' • '));
      doc.moveDown(1);
    }
    
    // Certifications
    if (data.certifications && data.certifications.length > 0) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('CERTIFICATIONS');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      data.certifications.forEach(cert => {
        doc.fontSize(10).fillColor('#333333').font('Helvetica')
           .text(`• ${cert}`, { indent: 20 });
      });
      doc.moveDown(1);
    }
    
    // Languages
    if (data.languages && data.languages.length > 0) {
      doc.fontSize(12).fillColor('#2C3E50').font('Helvetica-Bold')
         .text('LANGUAGES');
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke('#2C3E50');
      doc.moveDown(0.5);
      doc.fontSize(10).fillColor('#333333').font('Helvetica')
         .text(data.languages.join(' • '));
    }
    
    doc.end();
    
    writeStream.on('finish', () => {
      resolve({ filename, filepath, format: 'pdf' });
    });
    
    writeStream.on('error', reject);
  });
}

// ===== Text Generation =====
export async function generateResumeText(data: ResumeData): Promise<GeneratedDocument> {
  const lines: string[] = [];
  
  // Header
  lines.push('='.repeat(60));
  lines.push(data.fullName.toUpperCase());
  lines.push('='.repeat(60));
  
  const contactParts: string[] = [];
  if (data.email) contactParts.push(data.email);
  if (data.phone) contactParts.push(data.phone);
  if (data.location) contactParts.push(data.location);
  if (data.linkedin) contactParts.push(data.linkedin);
  lines.push(contactParts.join(' | '));
  lines.push('');
  
  // Summary
  if (data.summary) {
    lines.push('-'.repeat(40));
    lines.push('PROFESSIONAL SUMMARY');
    lines.push('-'.repeat(40));
    lines.push(data.summary);
    lines.push('');
  }
  
  // Experience
  if (data.experience && data.experience.length > 0) {
    lines.push('-'.repeat(40));
    lines.push('PROFESSIONAL EXPERIENCE');
    lines.push('-'.repeat(40));
    
    data.experience.forEach(exp => {
      lines.push(`${exp.title} | ${exp.company}`);
      const dateLocation = [];
      if (exp.location) dateLocation.push(exp.location);
      dateLocation.push(`${exp.startDate} - ${exp.endDate || 'Present'}`);
      lines.push(dateLocation.join(' | '));
      
      if (exp.responsibilities) {
        exp.responsibilities.forEach(resp => {
          lines.push(`  • ${resp}`);
        });
      }
      lines.push('');
    });
  }
  
  // Education
  if (data.education && data.education.length > 0) {
    lines.push('-'.repeat(40));
    lines.push('EDUCATION');
    lines.push('-'.repeat(40));
    
    data.education.forEach(edu => {
      let text = `${edu.degree} - ${edu.institution}, ${edu.year}`;
      if (edu.gpa) text += ` (GPA: ${edu.gpa})`;
      lines.push(`  • ${text}`);
    });
    lines.push('');
  }
  
  // Skills
  if (data.skills && data.skills.length > 0) {
    lines.push('-'.repeat(40));
    lines.push('SKILLS');
    lines.push('-'.repeat(40));
    lines.push(data.skills.join(' • '));
    lines.push('');
  }
  
  // Certifications
  if (data.certifications && data.certifications.length > 0) {
    lines.push('-'.repeat(40));
    lines.push('CERTIFICATIONS');
    lines.push('-'.repeat(40));
    data.certifications.forEach(cert => {
      lines.push(`  • ${cert}`);
    });
    lines.push('');
  }
  
  // Languages
  if (data.languages && data.languages.length > 0) {
    lines.push('-'.repeat(40));
    lines.push('LANGUAGES');
    lines.push('-'.repeat(40));
    lines.push(data.languages.join(' • '));
  }
  
  const content = lines.join('\n');
  const filename = `resume_${data.fullName.replace(/\s+/g, "_")}_${Date.now()}.txt`;
  const filepath = path.join(uploadsDir, filename);
  
  fs.writeFileSync(filepath, content, 'utf-8');
  
  return { filename, filepath, format: 'txt' };
}

// ===== Excel Generation =====
export async function generateResumeExcel(data: ResumeData): Promise<GeneratedDocument> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Minutz AI';
  workbook.created = new Date();
  
  // Personal Info Sheet
  const infoSheet = workbook.addWorksheet('Personal Info');
  infoSheet.columns = [
    { header: 'Field', key: 'field', width: 20 },
    { header: 'Value', key: 'value', width: 50 },
  ];
  
  infoSheet.addRow({ field: 'Full Name', value: data.fullName });
  if (data.email) infoSheet.addRow({ field: 'Email', value: data.email });
  if (data.phone) infoSheet.addRow({ field: 'Phone', value: data.phone });
  if (data.location) infoSheet.addRow({ field: 'Location', value: data.location });
  if (data.linkedin) infoSheet.addRow({ field: 'LinkedIn', value: data.linkedin });
  if (data.summary) infoSheet.addRow({ field: 'Summary', value: data.summary });
  
  // Style header row
  infoSheet.getRow(1).font = { bold: true };
  infoSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2C3E50' } };
  infoSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  
  // Experience Sheet
  if (data.experience && data.experience.length > 0) {
    const expSheet = workbook.addWorksheet('Experience');
    expSheet.columns = [
      { header: 'Title', key: 'title', width: 25 },
      { header: 'Company', key: 'company', width: 25 },
      { header: 'Location', key: 'location', width: 20 },
      { header: 'Start Date', key: 'startDate', width: 15 },
      { header: 'End Date', key: 'endDate', width: 15 },
      { header: 'Responsibilities', key: 'responsibilities', width: 60 },
    ];
    
    data.experience.forEach(exp => {
      expSheet.addRow({
        title: exp.title,
        company: exp.company,
        location: exp.location || '',
        startDate: exp.startDate,
        endDate: exp.endDate || 'Present',
        responsibilities: exp.responsibilities ? exp.responsibilities.join('; ') : '',
      });
    });
    
    expSheet.getRow(1).font = { bold: true };
    expSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2C3E50' } };
    expSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  }
  
  // Education Sheet
  if (data.education && data.education.length > 0) {
    const eduSheet = workbook.addWorksheet('Education');
    eduSheet.columns = [
      { header: 'Degree', key: 'degree', width: 30 },
      { header: 'Institution', key: 'institution', width: 35 },
      { header: 'Year', key: 'year', width: 15 },
      { header: 'GPA', key: 'gpa', width: 10 },
    ];
    
    data.education.forEach(edu => {
      eduSheet.addRow({
        degree: edu.degree,
        institution: edu.institution,
        year: edu.year,
        gpa: edu.gpa || '',
      });
    });
    
    eduSheet.getRow(1).font = { bold: true };
    eduSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2C3E50' } };
    eduSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  }
  
  // Skills Sheet
  if (data.skills && data.skills.length > 0) {
    const skillsSheet = workbook.addWorksheet('Skills');
    skillsSheet.columns = [
      { header: 'Skill', key: 'skill', width: 40 },
    ];
    
    data.skills.forEach(skill => {
      skillsSheet.addRow({ skill });
    });
    
    skillsSheet.getRow(1).font = { bold: true };
    skillsSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2C3E50' } };
    skillsSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  }
  
  const filename = `resume_${data.fullName.replace(/\s+/g, "_")}_${Date.now()}.xlsx`;
  const filepath = path.join(uploadsDir, filename);
  
  await workbook.xlsx.writeFile(filepath);
  
  return { filename, filepath, format: 'xlsx' };
}

// ===== PowerPoint Generation =====
export async function generateResumePPT(data: ResumeData): Promise<GeneratedDocument> {
  const pptx = new PptxGenJS();
  pptx.author = 'Minutz AI';
  pptx.title = `${data.fullName} - Resume`;
  pptx.subject = 'Professional Resume';
  
  // Title Slide
  let slide = pptx.addSlide();
  slide.addText(data.fullName, {
    x: 0.5, y: 2, w: 9, h: 1,
    fontSize: 44, bold: true, color: '2C3E50',
    align: 'center'
  });
  
  const contactParts: string[] = [];
  if (data.email) contactParts.push(data.email);
  if (data.phone) contactParts.push(data.phone);
  if (data.location) contactParts.push(data.location);
  
  slide.addText(contactParts.join(' | '), {
    x: 0.5, y: 3.2, w: 9, h: 0.5,
    fontSize: 14, color: '666666',
    align: 'center'
  });
  
  // Summary Slide
  if (data.summary) {
    slide = pptx.addSlide();
    slide.addText('Professional Summary', {
      x: 0.5, y: 0.5, w: 9, h: 0.7,
      fontSize: 28, bold: true, color: '2C3E50'
    });
    slide.addText(data.summary, {
      x: 0.5, y: 1.5, w: 9, h: 4,
      fontSize: 18, color: '333333',
      valign: 'top'
    });
  }
  
  // Experience Slide(s)
  if (data.experience && data.experience.length > 0) {
    slide = pptx.addSlide();
    slide.addText('Professional Experience', {
      x: 0.5, y: 0.5, w: 9, h: 0.7,
      fontSize: 28, bold: true, color: '2C3E50'
    });
    
    let yPos = 1.3;
    data.experience.slice(0, 3).forEach(exp => {
      slide.addText(`${exp.title} - ${exp.company}`, {
        x: 0.5, y: yPos, w: 9, h: 0.4,
        fontSize: 16, bold: true, color: '333333'
      });
      yPos += 0.4;
      
      slide.addText(`${exp.startDate} - ${exp.endDate || 'Present'}`, {
        x: 0.5, y: yPos, w: 9, h: 0.3,
        fontSize: 12, italic: true, color: '666666'
      });
      yPos += 0.4;
      
      if (exp.responsibilities && exp.responsibilities.length > 0) {
        const bullets = exp.responsibilities.slice(0, 3).map(r => ({ text: r }));
        slide.addText(bullets, {
          x: 0.7, y: yPos, w: 8.5, h: 1,
          fontSize: 12, color: '333333',
          bullet: { type: 'bullet' },
          valign: 'top'
        });
        yPos += 1.2;
      }
    });
  }
  
  // Education Slide
  if (data.education && data.education.length > 0) {
    slide = pptx.addSlide();
    slide.addText('Education', {
      x: 0.5, y: 0.5, w: 9, h: 0.7,
      fontSize: 28, bold: true, color: '2C3E50'
    });
    
    let yPos = 1.3;
    data.education.forEach(edu => {
      let text = `${edu.degree} - ${edu.institution}, ${edu.year}`;
      if (edu.gpa) text += ` (GPA: ${edu.gpa})`;
      
      slide.addText(text, {
        x: 0.5, y: yPos, w: 9, h: 0.5,
        fontSize: 16, color: '333333'
      });
      yPos += 0.6;
    });
  }
  
  // Skills Slide
  if (data.skills && data.skills.length > 0) {
    slide = pptx.addSlide();
    slide.addText('Skills', {
      x: 0.5, y: 0.5, w: 9, h: 0.7,
      fontSize: 28, bold: true, color: '2C3E50'
    });
    
    const skillBullets = data.skills.map(s => ({ text: s }));
    slide.addText(skillBullets, {
      x: 0.5, y: 1.3, w: 9, h: 4,
      fontSize: 14, color: '333333',
      bullet: { type: 'bullet' },
      valign: 'top'
    });
  }
  
  const filename = `resume_${data.fullName.replace(/\s+/g, "_")}_${Date.now()}.pptx`;
  const filepath = path.join(uploadsDir, filename);
  
  await pptx.writeFile({ fileName: filepath });
  
  return { filename, filepath, format: 'pptx' };
}

// ===== Universal Format Generator =====
export async function generateResumeInFormat(data: ResumeData, format: DocumentFormat): Promise<GeneratedDocument> {
  switch (format) {
    case 'docx':
      const docxResult = await generateResume(data);
      return { ...docxResult, format: 'docx' };
    case 'pdf':
      return generateResumePDF(data);
    case 'txt':
      return generateResumeText(data);
    case 'xlsx':
      return generateResumeExcel(data);
    case 'pptx':
      return generateResumePPT(data);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

export async function generateSampleResumeInFormat(format: DocumentFormat): Promise<GeneratedDocument> {
  const sampleData: ResumeData = {
    fullName: "John Doe",
    email: "john.doe@email.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    linkedin: "linkedin.com/in/johndoe",
    summary:
      "Results-driven software engineer with 5+ years of experience in full-stack development. Passionate about building scalable applications and leading cross-functional teams to deliver high-quality products.",
    experience: [
      {
        title: "Senior Software Engineer",
        company: "Tech Corp Inc.",
        location: "San Francisco, CA",
        startDate: "Jan 2021",
        endDate: "Present",
        responsibilities: [
          "Led development of microservices architecture serving 1M+ daily users",
          "Mentored junior developers and conducted code reviews",
          "Reduced API response times by 40% through optimization",
          "Implemented CI/CD pipelines using GitHub Actions and Docker",
        ],
      },
      {
        title: "Software Engineer",
        company: "StartupXYZ",
        location: "San Jose, CA",
        startDate: "Jun 2018",
        endDate: "Dec 2020",
        responsibilities: [
          "Built React-based dashboard for real-time data visualization",
          "Developed RESTful APIs using Node.js and Express",
          "Collaborated with design team to improve UX/UI",
        ],
      },
    ],
    education: [
      {
        degree: "B.S. Computer Science",
        institution: "University of California, Berkeley",
        year: "2018",
        gpa: "3.8",
      },
    ],
    skills: [
      "JavaScript",
      "TypeScript",
      "React",
      "Node.js",
      "Python",
      "PostgreSQL",
      "MongoDB",
      "AWS",
      "Docker",
      "Kubernetes",
      "Git",
      "Agile/Scrum",
    ],
    certifications: [
      "AWS Certified Solutions Architect",
      "Google Cloud Professional Developer",
    ],
    languages: ["English (Native)", "Spanish (Conversational)"],
  };

  return generateResumeInFormat(sampleData, format);
}
