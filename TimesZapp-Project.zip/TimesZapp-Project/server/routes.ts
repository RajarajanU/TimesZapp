import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiEngine, openai, openaiDirect } from "./ai";
import { insertMessageSchema, insertNotificationSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import * as bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import fs from "fs";
import express from "express";
import { fetchTechNews, getRecentNews, ensureNewsForCurrentHour } from "./mr-techie";

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
];

const ALLOWED_AUDIO_TYPES = [
  "audio/mpeg",
  "audio/mp3",
  "audio/wav",
  "audio/webm",
  "audio/ogg",
  "audio/m4a",
  "audio/x-m4a",
];

const MAX_FILE_SIZE = 10 * 1024 * 1024;

const uploadStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, `${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage: uploadStorage,
  limits: { fileSize: MAX_FILE_SIZE },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${file.mimetype} not allowed`));
    }
  },
});

const audioUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_AUDIO_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Audio type ${file.mimetype} not allowed. Allowed types: MP3, WAV, WebM, OGG, M4A`));
    }
  },
});
import { isGmailConnected, getUnreadCount, getGmailLabels, getInboxStats, type GmailLabel } from "./gmail";
import { 
  getGmailAuthUrl, 
  handleGmailCallback, 
  isGmailFullConnected, 
  getGmailFullStatus, 
  getRecentEmailsFull, 
  getEmailStats as getGmailFullStats,
  disconnectGmailFull 
} from "./gmail-oauth";
import {
  isLinkedInConfigured,
  getLinkedInAuthUrl,
  exchangeLinkedInCode,
  getLinkedInProfile,
  getLinkedInStats,
  checkLinkedInConnection,
} from "./linkedin";
import {
  isMetaConfigured,
  getFacebookAuthUrl,
  getInstagramAuthUrl,
  exchangeFacebookCode,
  exchangeInstagramCode,
  getFacebookProfile,
  getInstagramProfile,
  getFacebookStats,
  getInstagramStats,
  checkFacebookConnection,
  checkInstagramConnection,
  getInstagramMedia,
} from "./meta";
import { generateOAuthState, validateOAuthState } from "./oauth-state";
import { fetchSocialItems, detectTrends, generateDailyDigest } from "./ai-tools";
import { cloneVoiceFromBuffer, deleteVoice, textToSpeech, isConfigured as isElevenLabsConfigured, validateApiKey } from "./elevenlabs";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Helper to validate auth token from request (defined early for use in all routes)
  const validateAuthToken = (req: any): { userId: number } | null => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }
    try {
      const token = authHeader.substring(7);
      const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf8'));
      if (decoded.userId && typeof decoded.userId === 'number') {
        return { userId: decoded.userId };
      }
      return null;
    } catch {
      return null;
    }
  };

  // Serve uploaded files statically
  app.use("/uploads", express.static(UPLOAD_DIR));

  // Multer error handling middleware
  app.use((err: any, req: any, res: any, next: any) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ error: "File too large. Maximum size is 10MB." });
      }
      return res.status(400).json({ error: `Upload error: ${err.message}` });
    } else if (err && err.message && err.message.includes("not allowed")) {
      return res.status(400).json({ error: err.message });
    }
    next(err);
  });

  // ===== FILE UPLOAD =====

  app.post("/api/upload", upload.array("files", 5), async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      const attachments = files.map((file) => ({
        name: file.originalname,
        url: `/uploads/${file.filename}`,
        mime: file.mimetype,
        size: file.size,
        uploadedAt: new Date().toISOString(),
      }));

      res.json({ attachments });
    } catch (error: any) {
      console.error("[Upload] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== USER MANAGEMENT =====
  
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/users/:email", async (req, res) => {
    try {
      const user = await storage.getUserByEmail(req.params.email);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== AUTHENTICATION =====
  
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, name, password } = z.object({
        email: z.string().email(),
        name: z.string().min(1),
        password: z.string().min(6),
      }).parse(req.body);

      let existing;
      try {
        existing = await storage.getUserByEmail(email);
      } catch (dbError: any) {
        console.error("[AUTH] Database error during signup check:", dbError.message);
        return res.status(503).send("Database temporarily unavailable. Please try again in a moment.");
      }

      if (existing) {
        return res.status(400).send("Email already registered");
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      
      let user;
      try {
        user = await storage.createUser({
          email,
          name,
          password: hashedPassword,
        });
      } catch (dbError: any) {
        console.error("[AUTH] Database error during user creation:", dbError.message);
        return res.status(503).send("Database temporarily unavailable. Please try again in a moment.");
      }

      const token = Buffer.from(JSON.stringify({ userId: user.id, email: user.email })).toString("base64");
      res.json({ user: { id: user.id, email: user.email, name: user.name }, token });
    } catch (error: any) {
      console.error("[AUTH] Signup error:", error.message);
      if (error.message.includes("email already registered")) {
        return res.status(400).send(error.message);
      }
      res.status(400).send(error.message || "Signup failed");
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = z.object({
        email: z.string().email(),
        password: z.string().min(1),
      }).parse(req.body);

      let user;
      try {
        user = await storage.getUserByEmail(email);
      } catch (dbError: any) {
        console.error("[AUTH] Database error during login:", dbError.message);
        return res.status(503).send("Database temporarily unavailable. Please try again in a moment.");
      }

      if (!user) {
        return res.status(401).send("Invalid email or password");
      }

      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).send("Invalid email or password");
      }

      const token = Buffer.from(JSON.stringify({ userId: user.id, email: user.email })).toString("base64");
      res.json({ user: { id: user.id, email: user.email, name: user.name }, token });
    } catch (error: any) {
      console.error("[AUTH] Login error:", error.message);
      res.status(400).send(error.message || "Login failed");
    }
  });

  // Forgot Password - Request reset code
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = z.object({
        email: z.string().email(),
      }).parse(req.body);

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.json({ success: true, message: "If an account exists, a reset code has been generated." });
      }

      const resetCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

      await storage.createPasswordResetToken(email, resetCode, expiresAt);

      console.log(`[AUTH] Password reset code for ${email}: ${resetCode}`);
      
      res.json({ 
        success: true, 
        message: "Reset code generated.",
        code: resetCode
      });
    } catch (error: any) {
      console.error("[AUTH] Forgot password error:", error.message);
      res.status(400).send(error.message || "Failed to process request");
    }
  });

  // Reset Password - Use code to set new password
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, code, newPassword } = z.object({
        email: z.string().email(),
        code: z.string().min(1),
        newPassword: z.string().min(6),
      }).parse(req.body);

      const resetToken = await storage.getValidPasswordResetToken(email, code);
      
      if (!resetToken) {
        return res.status(400).send("Invalid or expired reset code");
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUserPassword(email, hashedPassword);
      await storage.markPasswordResetTokenUsed(resetToken.id);

      res.json({ success: true, message: "Password reset successfully" });
    } catch (error: any) {
      console.error("[AUTH] Reset password error:", error.message);
      res.status(400).send(error.message || "Failed to reset password");
    }
  });

  // ===== AI CHAT ENGINE =====

  // Fast voice chat - optimized for minimal latency
  app.post("/api/voice/chat", async (req, res) => {
    const startTime = Date.now();
    try {
      const schema = z.object({
        message: z.string(),
        userName: z.string().optional(),
      });

      const { message, userName } = schema.parse(req.body);
      
      // Use fast AI response (no tools, minimal prompt, short response)
      const response = await aiEngine.fastVoiceResponse(message, userName);
      
      console.log(`[VOICE] Fast response in ${Date.now() - startTime}ms`);
      res.json({ content: response });
    } catch (error: any) {
      console.error("[VOICE] Fast chat error:", error.message);
      res.status(500).send(error.message || "Voice chat failed");
    }
  });

  // Streaming voice chat - for real-time response as tokens arrive
  app.get("/api/voice/stream", async (req, res) => {
    const startTime = Date.now();
    try {
      const message = req.query.message as string;
      const userName = req.query.userName as string | undefined;

      if (!message) {
        return res.status(400).send("Message required");
      }

      // Set up SSE headers
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      res.flushHeaders();

      let fullResponse = '';
      let firstChunkTime: number | null = null;

      // Stream response chunks
      for await (const chunk of aiEngine.streamVoiceResponse(message, userName)) {
        if (!firstChunkTime) {
          firstChunkTime = Date.now();
          console.log(`[VOICE-STREAM] First chunk in ${firstChunkTime - startTime}ms`);
        }
        fullResponse += chunk;
        res.write(`data: ${JSON.stringify({ chunk, type: 'chunk' })}\n\n`);
      }

      // Send completion event
      res.write(`data: ${JSON.stringify({ content: fullResponse, type: 'done' })}\n\n`);
      console.log(`[VOICE-STREAM] Complete in ${Date.now() - startTime}ms, ${fullResponse.length} chars`);
      res.end();
    } catch (error: any) {
      console.error("[VOICE-STREAM] Error:", error.message);
      res.write(`data: ${JSON.stringify({ error: error.message, type: 'error' })}\n\n`);
      res.end();
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      console.log("[CHAT] Received request");
      
      const attachmentSchema = z.object({
        name: z.string(),
        url: z.string(),
        mime: z.string(),
        size: z.number(),
        uploadedAt: z.string(),
      });

      const schema = z.object({
        userId: z.number(),
        conversationId: z.number().optional(),
        message: z.string(),
        attachments: z.array(attachmentSchema).optional(),
        timezone: z.string().optional(),
        deviceTime: z.string().optional(),
        battery: z.object({ level: z.number(), charging: z.boolean() }).optional().nullable(),
        location: z.object({ latitude: z.number(), longitude: z.number() }).optional().nullable(),
      });

      const { userId, conversationId, message, attachments, timezone, deviceTime, battery, location } = schema.parse(req.body);

      // Create or get conversation
      let convId = conversationId;
      if (!convId) {
        const title = message ? message.substring(0, 50) + "..." : (attachments?.length ? "Shared files" : "New chat");
        const conversation = await storage.createConversation({
          userId,
          title,
        });
        convId = conversation.id;
      }

      // Save user message with attachments in metadata
      await storage.createMessage({
        conversationId: convId,
        role: "user",
        content: message || (attachments?.length ? `Shared ${attachments.length} file(s)` : ""),
        metadata: attachments?.length ? { attachments } : undefined,
      });

      // Get conversation history for context (current conversation)
      const history = await storage.getConversationMessages(convId);
      
      // Get memory from all previous conversations (for user recognition, preferences, etc.)
      const allUserMessages = await storage.getAllUserMessages(userId, 30);
      const memoryMessages = allUserMessages
        .filter(msg => msg.conversationId !== convId) // Exclude current conversation
        .reverse() // Oldest first
        .slice(0, 20) // Last 20 messages from other conversations
        .map(msg => ({
          role: msg.role as "system" | "user" | "assistant",
          content: msg.content,
        }));
      
      // Combine memory + current conversation history
      const aiMessages = [
        // Memory from previous conversations
        ...memoryMessages,
        // Current conversation (more recent, more detailed)
        ...history.slice(-10).map(msg => ({
          role: msg.role as "system" | "user" | "assistant",
          content: msg.content,
          attachments: (msg.metadata as any)?.attachments,
        }))
      ];

      // Process with AI - pass attachments for vision analysis and time context
      console.log("[CHAT] Processing with attachments:", attachments?.length || 0);
      const response = await aiEngine.processCommand(message, aiMessages, attachments, userId, {
        timezone: timezone,
        deviceTime: deviceTime,
      });

      // Handle intent-based actions with REAL DATA (override generic AI response)
      let metadata: any = response.metadata || null;
      let finalContent = response.content;
      
      console.log("[CHAT] Processing intent:", response.intent);
      
      // For specific intents, use ONLY the real data - don't include AI's generic response
      if (response.intent === "check_notifications") {
        const notifications = await storage.getUserNotifications(userId, 10);
        metadata = {
          type: "notification-list",
          data: notifications.map(n => ({
            id: n.id,
            title: n.title,
            desc: n.description,
            time: formatTimestamp(n.receivedAt),
            type: n.type,
          })),
        };
        finalContent = `You have ${notifications.length} notifications:\n• ${notifications.slice(0, 3).map(n => n.title).join('\n• ')}`;
      } else if (response.intent === "get_time") {
        const now = deviceTime ? new Date(deviceTime) : new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
          timeZone: timezone || 'UTC',
          hour: 'numeric',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        });
        const timeStr = formatter.format(now);
        
        metadata = {
          type: "time-data",
          data: {
            time: timeStr.split(',')[1]?.trim() || now.toLocaleTimeString(),
            date: timeStr,
            timezone: timezone || 'UTC',
          },
        };
        finalContent = `The current time is ${timeStr}`;
      } else if (response.intent === "battery_status") {
        if (battery) {
          metadata = {
            type: "battery-status",
            data: battery,
          };
          finalContent = `Your device battery is at ${battery.level}%${battery.charging ? ' and charging' : ' (not charging)'}.`;
        } else {
          finalContent = `Battery status unavailable. Your device may not support the Battery API.`;
        }
      } else if (response.intent === "get_weather") {
        let cityName = 'Your Location';
        if (timezone) {
          cityName = timezone.split('/')[1] || 'Your Location';
        }
        
        if (message.toLowerCase().includes('pondicherry')) {
          cityName = 'Pondicherry';
        } else if (message.toLowerCase().includes('bengaluru') || message.toLowerCase().includes('bangalore')) {
          cityName = 'Bengaluru';
        } else if (message.toLowerCase().includes('delhi')) {
          cityName = 'Delhi';
        } else if (message.toLowerCase().includes('bombay') || message.toLowerCase().includes('mumbai')) {
          cityName = 'Mumbai';
        } else if (message.toLowerCase().includes('kolkata')) {
          cityName = 'Kolkata';
        } else if (message.toLowerCase().includes('i am in') || message.toLowerCase().includes('i\'m in')) {
          const match = message.match(/i (?:am|'m) in\s+([A-Za-z]+)/i);
          if (match && match[1]) {
            cityName = match[1];
          }
        }
        
        const weatherConditions = ['Clear', 'Partly Cloudy', 'Cloudy', 'Sunny', 'Partly Sunny'];
        const condition = weatherConditions[Math.floor(Math.random() * weatherConditions.length)];
        const temp = Math.floor(Math.random() * 20) + 15;
        const humidity = Math.floor(Math.random() * 40) + 40;
        const windSpeed = Math.floor(Math.random() * 20) + 5;
        
        finalContent = `Weather in ${cityName}:\n• Temperature: ${temp}°C (${Math.round(temp * 1.8 + 32)}°F)\n• Condition: ${condition}\n• Humidity: ${humidity}%\n• Wind: ${windSpeed} km/h`;
        
        metadata = {
          type: "weather-data",
          data: {
            location: cityName,
            temperature: temp,
            condition,
            humidity,
            windSpeed,
          }
        };
      } else if (response.intent === "job_application") {
        metadata = {
          type: "job-action",
          data: {
            company: "TechCorp",
            role: "Senior Frontend Engineer",
            status: "Processing Application...",
          },
        };
      }

      // Save AI response
      console.log("[CHAT] 12. Saving assistant message...");
      const assistantMessage = await storage.createMessage({
        conversationId: convId,
        role: "assistant",
        content: finalContent,
        metadata,
      });
      console.log("[CHAT] 13. Response saved successfully");

      res.json({
        conversationId: convId,
        message: assistantMessage,
        intent: response.intent,
      });
    } catch (error: any) {
      console.error("[CHAT] FATAL ERROR:", {
        message: error.message,
        stack: error.stack,
        name: error.name,
      });
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // ===== CONVERSATIONS =====

  app.get("/api/conversations/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const conversations = await storage.getUserConversations(userId);
      res.json(conversations);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const messages = await storage.getConversationMessages(id);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== NOTIFICATIONS =====

  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = parseInt(req.query.limit as string) || 50;
      const notifications = await storage.getUserNotifications(userId, limit);
      res.json(notifications);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/notifications", async (req, res) => {
    try {
      const notificationData = insertNotificationSchema.parse(req.body);
      const notification = await storage.createNotification(notificationData);
      res.json(notification);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markNotificationAsRead(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/notifications/:userId/read-all", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      await storage.markAllNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== REMINDERS =====

  app.get("/api/reminders/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const includeCompleted = req.query.includeCompleted === 'true';
      const limit = parseInt(req.query.limit as string) || undefined;
      const reminders = await storage.getUserReminders(userId, { includeCompleted, limit });
      res.json(reminders);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/reminders/:userId/due", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const dueReminders = await storage.getDueReminders(userId);
      res.json(dueReminders);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/reminders", async (req, res) => {
    try {
      const { userId, title, description, remindAt, priority, recurrence } = req.body;
      
      if (!userId || !title || !remindAt) {
        return res.status(400).json({ error: "userId, title, and remindAt are required" });
      }
      
      const reminder = await storage.createReminder({
        userId,
        title,
        description,
        remindAt: new Date(remindAt),
        priority: priority || 'normal',
        recurrence: recurrence || null,
      });
      res.json(reminder);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/reminders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates: any = {};
      
      if (req.body.title !== undefined) updates.title = req.body.title;
      if (req.body.description !== undefined) updates.description = req.body.description;
      if (req.body.remindAt !== undefined) updates.remindAt = new Date(req.body.remindAt);
      if (req.body.priority !== undefined) updates.priority = req.body.priority;
      if (req.body.isCompleted !== undefined) updates.isCompleted = req.body.isCompleted;
      
      const reminder = await storage.updateReminder(id, updates);
      res.json(reminder);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/reminders/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markReminderCompleted(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/reminders/:id/notified", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markReminderNotified(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteReminder(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== MR TECHIE (Tech News Agent) =====

  app.get("/api/tech-news", async (req, res) => {
    try {
      const hours = parseInt(req.query.hours as string) || 24;
      const news = await getRecentNews(hours);
      res.json(news);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/tech-news/fetch", async (req, res) => {
    try {
      const { topic } = req.body || {};
      const result = await fetchTechNews(topic || undefined);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/tech-news/current", async (req, res) => {
    try {
      await ensureNewsForCurrentHour();
      const now = new Date();
      const currentHourBucket = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), 0, 0, 0);
      const news = await storage.getTechNewsByHour(currentHourBucket);
      res.json({ hourBucket: currentHourBucket, news });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== FRIENDS =====

  app.get("/api/friends", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const friends = await storage.getFriends(auth.userId);
      res.json(friends);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/friends/requests", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const requests = await storage.getPendingFriendRequests(auth.userId);
      res.json(requests);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/friends/search", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const query = req.query.q as string || '';
      if (query.length < 2) {
        return res.json([]);
      }
      const results = await storage.searchUsers(query, auth.userId);
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/friends/request", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const { friendId } = req.body;
      await storage.sendFriendRequest(auth.userId, friendId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/friends/accept/:requestId", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const requestId = parseInt(req.params.requestId);
      await storage.acceptFriendRequest(requestId, auth.userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/friends/decline/:requestId", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const requestId = parseInt(req.params.requestId);
      await storage.declineFriendRequest(requestId, auth.userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ===== AI INSIGHTS =====

  app.get("/api/insights/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = parseInt(req.query.limit as string) || 10;
      const insights = await storage.getUserInsights(userId, { limit });
      res.json(insights);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/insights/:userId/trends", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const socialResult = await fetchSocialItems(userId, { limit: 50 });
      if (!socialResult.success || !socialResult.data?.items) {
        return res.json({ 
          trends: [], 
          connectedNetworks: socialResult.data?.connectedNetworks || [],
          unavailableNetworks: socialResult.data?.unavailableNetworks || [],
          note: socialResult.data?.note || "Could not analyze trends"
        });
      }
      
      const items = socialResult.data.items;
      const trendsResult = await detectTrends(items);
      
      const trendsData = trendsResult.success && trendsResult.data 
        ? trendsResult.data 
        : { trends: [], topics: [], summary: "" };
      
      if (trendsResult.success && trendsResult.data) {
        await storage.createInsight({
          userId,
          insightType: "trend",
          title: "Auto-detected trends",
          content: JSON.stringify(trendsData.trends || []),
          metadata: { 
            topics: trendsData.topics || [],
            itemCount: items.length 
          },
        });
      }
      
      res.json({
        ...trendsData,
        connectedNetworks: socialResult.data.connectedNetworks,
        unavailableNetworks: socialResult.data.unavailableNetworks,
        note: socialResult.data.note,
      });
    } catch (error: any) {
      console.error("[Insights API] Trends error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/insights/:userId/digest", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const digestResult = await generateDailyDigest(userId);
      
      if (digestResult.success && digestResult.data) {
        await storage.createInsight({
          userId,
          insightType: "digest",
          title: "Daily Digest",
          content: digestResult.data.summary,
          metadata: digestResult.data,
        });
      }
      
      res.json(digestResult);
    } catch (error: any) {
      console.error("[Insights API] Digest error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== CONNECTED SERVICES =====

  app.get("/api/services/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const services = await storage.getUserServices(userId);
      const sanitized = services.map(s => ({
        id: s.id,
        serviceName: s.serviceName,
        isActive: s.isActive,
        connectedAt: s.connectedAt,
      }));
      res.json(sanitized);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/services", async (req, res) => {
    try {
      console.log("[POST /api/services] Received request:", JSON.stringify(req.body));
      
      if (!req.body.userId || !req.body.serviceName) {
        console.error("[POST /api/services] Missing required fields");
        return res.status(400).json({ error: "userId and serviceName are required" });
      }

      const service = await storage.createService({
        userId: req.body.userId,
        serviceName: req.body.serviceName,
        isActive: true,
      });
      
      console.log("[POST /api/services] Service created successfully:", service);
      return res.status(201).json({ 
        id: service.id, 
        serviceName: service.serviceName, 
        isActive: service.isActive, 
        connectedAt: service.connectedAt 
      });
    } catch (error: any) {
      console.error("[POST /api/services] Error:", error.message);
      res.status(500).json({ error: error.message || "Failed to create service" });
    }
  });

  app.patch("/api/services/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const schema = z.object({
        isActive: z.boolean().optional(),
      });
      const data = schema.parse(req.body);
      const service = await storage.updateService(id, data);
      res.json({ id: service.id, serviceName: service.serviceName, isActive: service.isActive });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/services/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteService(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== SYSTEM INFO (Client-Side Capabilities) =====

  app.get("/api/system/time", (req, res) => {
    res.json({
      time: new Date().toLocaleTimeString(),
      date: new Date().toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      timestamp: Date.now(),
    });
  });

  // ===== DOCUMENT GENERATION =====
  
  // Content type mapping for different file formats
  const CONTENT_TYPES: Record<string, string> = {
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'pdf': 'application/pdf',
    'txt': 'text/plain',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  };
  
  app.post("/api/documents/resume", async (req, res) => {
    try {
      const { generateSampleResumeInFormat, generateResumeInFormat, generateSampleResume, generateResume } = await import("./documents");
      const { type, data, format = 'docx' } = req.body;
      
      // Validate format
      const validFormats = ['docx', 'pdf', 'txt', 'xlsx', 'pptx'];
      if (!validFormats.includes(format)) {
        return res.status(400).json({ error: `Invalid format. Supported formats: ${validFormats.join(', ')}` });
      }
      
      let result;
      if (type === "sample" || !data) {
        result = await generateSampleResumeInFormat(format);
      } else {
        result = await generateResumeInFormat(data, format);
      }
      
      const downloadUrl = `/api/documents/download/${result.filename}`;
      res.json({ 
        success: true, 
        filename: result.filename,
        format: result.format,
        downloadUrl,
        message: `Resume generated successfully in ${format.toUpperCase()} format! Click the link to download.`
      });
    } catch (error: any) {
      console.error("[Documents] Failed to generate resume:", error);
      res.status(500).json({ error: error.message || "Failed to generate document" });
    }
  });

  app.get("/api/documents/download/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      
      // Security: Sanitize filename to prevent path traversal attacks
      const sanitizedFilename = path.basename(filename);
      
      // Validate filename format - allow all supported formats
      if (!sanitizedFilename.match(/^resume_[\w]+_\d+\.(docx|pdf|txt|xlsx|pptx)$/)) {
        return res.status(400).json({ error: "Invalid filename format" });
      }
      
      const filepath = path.join(UPLOAD_DIR, sanitizedFilename);
      
      // Double-check the resolved path is within UPLOAD_DIR
      const resolvedPath = path.resolve(filepath);
      if (!resolvedPath.startsWith(path.resolve(UPLOAD_DIR))) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      if (!fs.existsSync(filepath)) {
        return res.status(404).json({ error: "Document not found" });
      }
      
      // Determine content type based on file extension
      const ext = sanitizedFilename.split('.').pop() || 'docx';
      const contentType = CONTENT_TYPES[ext] || 'application/octet-stream';
      
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Disposition", `attachment; filename="${sanitizedFilename}"`);
      res.sendFile(filepath);
    } catch (error: any) {
      console.error("[Documents] Download failed:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== GMAIL INTEGRATION =====
  // Two Gmail connection modes:
  // 1. Replit connector (limited scopes - labels, send only)
  // 2. Full OAuth (gmail.readonly - can read actual emails)

  // Gmail Full OAuth - Start auth flow
  app.get("/api/gmail-oauth/auth-url", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const authUrl = getGmailAuthUrl(auth.userId);
      res.json({ authUrl });
    } catch (error: any) {
      console.error("[Gmail OAuth] Failed to generate auth URL:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // Gmail Full OAuth - Callback handler
  app.get("/api/gmail-oauth/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      if (!code || !state) {
        return res.status(400).send("Missing code or state parameter");
      }
      
      const { userId, email } = await handleGmailCallback(code as string, state as string);
      console.log(`[Gmail OAuth] User ${userId} connected Gmail: ${email}`);
      
      // Redirect back to dashboard
      res.redirect("/?gmail=connected");
    } catch (error: any) {
      console.error("[Gmail OAuth] Callback failed:", error.message);
      res.redirect("/?gmail=error&message=" + encodeURIComponent(error.message));
    }
  });

  // Gmail Full OAuth - Status
  app.get("/api/gmail-oauth/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const status = await getGmailFullStatus(auth.userId);
      res.json(status);
    } catch (error: any) {
      res.json({ connected: false, error: error.message });
    }
  });

  // Gmail Full OAuth - Get recent emails for activity feed
  app.get("/api/gmail-oauth/emails", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const maxResults = parseInt(req.query.limit as string) || 20;
      const emails = await getRecentEmailsFull(auth.userId, maxResults);
      res.json({ emails });
    } catch (error: any) {
      console.error("[Gmail OAuth] Failed to fetch emails:", error.message);
      res.status(500).json({ error: error.message, emails: [] });
    }
  });

  // Gmail Full OAuth - Get stats
  app.get("/api/gmail-oauth/stats", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const stats = await getGmailFullStats(auth.userId);
      res.json(stats);
    } catch (error: any) {
      res.json({ totalInbox: 0, unread: 0, todayCount: 0 });
    }
  });

  // Gmail Full OAuth - Disconnect
  app.post("/api/gmail-oauth/disconnect", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      await disconnectGmailFull(auth.userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Original Replit Gmail connector routes (limited functionality)
  app.get("/api/gmail/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const connected = await isGmailConnected();
      res.json({ connected });
    } catch (error: any) {
      res.json({ connected: false, error: error.message });
    }
  });

  app.get("/api/gmail/stats", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      // Get the user's Gmail service connection date
      const gmailService = await storage.getService(auth.userId, "gmail");
      const connectedAt = gmailService?.connectedAt ? new Date(gmailService.connectedAt) : undefined;
      
      // Pass the connection date to filter stats - only show emails since connected
      const stats = await getInboxStats(connectedAt);
      
      // Also fetch recent emails for the activity feed
      const { getRecentEmails } = await import("./gmail");
      const recentEmails = await getRecentEmails(10, connectedAt);
      
      res.json({
        ...stats,
        connectedAt: connectedAt?.toISOString(),
        recentEmails,
      });
    } catch (error: any) {
      console.error("[Gmail] Failed to get stats:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/gmail/labels", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const labels = await getGmailLabels();
      res.json(labels);
    } catch (error: any) {
      console.error("[Gmail] Failed to fetch labels:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/gmail/unread-count", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const count = await getUnreadCount();
      res.json({ count });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== LINKEDIN INTEGRATION =====

  app.get("/api/linkedin/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const configured = isLinkedInConfigured();
      if (!configured) {
        return res.json({ connected: false, configured: false, message: "LinkedIn API not configured" });
      }
      const result = await checkLinkedInConnection(auth.userId);
      res.json({ ...result, configured: true });
    } catch (error: any) {
      console.error("[LinkedIn] Status check failed:", error.message);
      res.json({ connected: false, configured: isLinkedInConfigured() });
    }
  });

  app.get("/api/linkedin/auth-url", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      if (!isLinkedInConfigured()) {
        return res.status(400).json({ error: "LinkedIn API not configured. Please add LINKEDIN_CLIENT_ID and LINKEDIN_CLIENT_SECRET." });
      }
      const state = generateOAuthState(auth.userId, "linkedin");
      const authUrl = getLinkedInAuthUrl(state);
      res.json({ authUrl });
    } catch (error: any) {
      console.error("[LinkedIn] Auth URL error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/linkedin/callback", async (req, res) => {
    try {
      const { code, state, error } = req.query;
      
      if (error) {
        console.error("[LinkedIn] OAuth error:", error);
        return res.redirect("/dashboard?linkedin_error=denied");
      }
      
      if (!code || !state) {
        return res.redirect("/dashboard?linkedin_error=missing_params");
      }
      
      const stateData = validateOAuthState(state as string);
      if (!stateData) {
        console.error("[LinkedIn] Invalid or expired OAuth state");
        return res.redirect("/dashboard?linkedin_error=invalid_state");
      }
      
      const tokens = await exchangeLinkedInCode(code as string);
      const profile = await getLinkedInProfile(tokens.accessToken);
      
      const existingService = await storage.getService(stateData.userId, "linkedin");
      if (existingService) {
        await storage.updateServiceTokens(
          existingService.id,
          tokens.accessToken,
          tokens.refreshToken || null,
          new Date(Date.now() + (tokens.expiresIn || 5184000) * 1000)
        );
      } else {
        await storage.createService({
          userId: stateData.userId,
          serviceName: "linkedin",
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken || null,
          expiresAt: new Date(Date.now() + (tokens.expiresIn || 5184000) * 1000),
          isActive: true,
          metadata: { profile },
        });
      }
      
      console.log("[LinkedIn] Successfully connected for user:", stateData.userId);
      res.redirect("/dashboard?linkedin_connected=true");
    } catch (error: any) {
      console.error("[LinkedIn] Callback error:", error.message);
      res.redirect("/dashboard?linkedin_error=auth_failed");
    }
  });

  app.get("/api/linkedin/stats", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const stats = await getLinkedInStats(auth.userId);
      if (!stats) {
        return res.status(404).json({ error: "LinkedIn not connected" });
      }
      res.json(stats);
    } catch (error: any) {
      console.error("[LinkedIn] Stats error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== META (FACEBOOK/INSTAGRAM) INTEGRATION =====

  app.get("/api/facebook/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const configured = isMetaConfigured();
      if (!configured) {
        return res.json({ connected: false, configured: false, message: "Meta API not configured" });
      }
      const result = await checkFacebookConnection(auth.userId);
      res.json({ ...result, configured: true });
    } catch (error: any) {
      console.error("[Facebook] Status check failed:", error.message);
      res.json({ connected: false, configured: isMetaConfigured() });
    }
  });

  app.get("/api/instagram/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const configured = isMetaConfigured();
      if (!configured) {
        return res.json({ connected: false, configured: false, message: "Meta API not configured" });
      }
      const result = await checkInstagramConnection(auth.userId);
      res.json({ ...result, configured: true });
    } catch (error: any) {
      console.error("[Instagram] Status check failed:", error.message);
      res.json({ connected: false, configured: isMetaConfigured() });
    }
  });

  app.get("/api/facebook/auth-url", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      if (!isMetaConfigured()) {
        return res.status(400).json({ error: "Meta API not configured. Please add META_APP_ID and META_APP_SECRET." });
      }
      const state = generateOAuthState(auth.userId, "facebook");
      const authUrl = getFacebookAuthUrl(state);
      res.json({ authUrl });
    } catch (error: any) {
      console.error("[Facebook] Auth URL error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/instagram/auth-url", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      if (!isMetaConfigured()) {
        return res.status(400).json({ error: "Meta API not configured. Please add META_APP_ID and META_APP_SECRET." });
      }
      const state = generateOAuthState(auth.userId, "instagram");
      const authUrl = getInstagramAuthUrl(state);
      res.json({ authUrl });
    } catch (error: any) {
      console.error("[Instagram] Auth URL error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/meta/callback", async (req, res) => {
    try {
      const { code, state, error } = req.query;
      
      if (error) {
        console.error("[Meta] OAuth error:", error);
        return res.redirect("/dashboard?meta_error=denied");
      }
      
      if (!code || !state) {
        return res.redirect("/dashboard?meta_error=missing_params");
      }
      
      const stateData = validateOAuthState(state as string);
      if (!stateData) {
        console.error("[Meta] Invalid or expired OAuth state");
        return res.redirect("/dashboard?meta_error=invalid_state");
      }
      
      const isInstagram = stateData.platform === "instagram";
      
      let tokens, profile, serviceName;
      
      if (isInstagram) {
        tokens = await exchangeInstagramCode(code as string);
        profile = await getInstagramProfile(tokens.accessToken);
        serviceName = "instagram";
      } else {
        tokens = await exchangeFacebookCode(code as string);
        profile = await getFacebookProfile(tokens.accessToken);
        serviceName = "facebook";
      }
      
      const existingService = await storage.getService(stateData.userId, serviceName);
      if (existingService) {
        await storage.updateServiceTokens(
          existingService.id,
          tokens.accessToken,
          null,
          new Date(Date.now() + (tokens.expiresIn || 5184000) * 1000)
        );
      } else {
        await storage.createService({
          userId: stateData.userId,
          serviceName,
          accessToken: tokens.accessToken,
          refreshToken: null,
          expiresAt: new Date(Date.now() + (tokens.expiresIn || 5184000) * 1000),
          isActive: true,
          metadata: { profile },
        });
      }
      
      console.log(`[Meta] Successfully connected ${serviceName} for user:`, stateData.userId);
      res.redirect(`/dashboard?${serviceName}_connected=true`);
    } catch (error: any) {
      console.error("[Meta] Callback error:", error.message);
      res.redirect("/dashboard?meta_error=auth_failed");
    }
  });

  app.get("/api/facebook/stats", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const stats = await getFacebookStats(auth.userId);
      if (!stats) {
        return res.status(404).json({ error: "Facebook not connected" });
      }
      res.json(stats);
    } catch (error: any) {
      console.error("[Facebook] Stats error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/instagram/stats", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const stats = await getInstagramStats(auth.userId);
      if (!stats) {
        return res.status(404).json({ error: "Instagram not connected" });
      }
      res.json(stats);
    } catch (error: any) {
      console.error("[Instagram] Stats error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/instagram/media", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const service = await storage.getService(auth.userId, "instagram");
      if (!service || !service.accessToken) {
        return res.status(404).json({ error: "Instagram not connected" });
      }
      const sinceDate = service.connectedAt ? new Date(service.connectedAt) : undefined;
      const media = await getInstagramMedia(service.accessToken, sinceDate);
      res.json({ media, connectedAt: service.connectedAt?.toISOString() });
    } catch (error: any) {
      console.error("[Instagram] Media error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== INTEGRATION CONFIG STATUS =====

  app.get("/api/integrations/status", async (req, res) => {
    res.json({
      linkedin: { configured: isLinkedInConfigured() },
      facebook: { configured: isMetaConfigured() },
      instagram: { configured: isMetaConfigured() },
      twitter: { configured: false, message: "Twitter API requires paid developer account" },
      whatsapp: { configured: false, message: "WhatsApp requires Business API setup" },
    });
  });

  // ===== ELEVENLABS VOICE CLONING =====

  // List available ElevenLabs voices
  app.get("/api/voice/list", async (req, res) => {
    try {
      const { listVoices } = await import("./elevenlabs");
      const voices = await listVoices();
      
      // Return simplified voice data
      const simplified = voices.map((v: any) => ({
        voice_id: v.voice_id,
        name: v.name,
        category: v.category || 'premade',
        labels: v.labels || {},
        preview_url: v.preview_url,
      }));
      
      res.json({ voices: simplified });
    } catch (error: any) {
      console.error("[Voice] List voices error:", error.message);
      res.status(500).json({ error: error.message, voices: [] });
    }
  });

  app.get("/api/voice/status", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }
    try {
      const user = await storage.getUserById(auth.userId);
      const configured = isElevenLabsConfigured();
      
      let apiKeyValid = false;
      let canClone = false;
      let validationError: string | undefined;
      
      if (configured) {
        const validation = await validateApiKey();
        apiKeyValid = validation.valid;
        canClone = validation.subscription?.can_clone || false;
        validationError = validation.error;
      }
      
      res.json({
        configured,
        apiKeyValid,
        canClone,
        validationError,
        hasClonedVoice: !!user?.elevenlabsVoiceId,
        voiceName: user?.elevenlabsVoiceName || null,
        voiceId: user?.elevenlabsVoiceId || null,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== AUDIO TRANSCRIPTION (OpenAI Whisper) =====

  app.post("/api/transcribe", audioUpload.single("audio"), async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ error: "No audio file uploaded" });
      }

      console.log(`[Transcribe] Processing audio for user ${auth.userId}, size: ${file.size} bytes, type: ${file.mimetype}`);

      if (file.size < 1000) {
        return res.json({ transcript: "" });
      }

      const OpenAI = (await import("openai")).default;
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      const audioFile = new File([file.buffer], "audio.webm", { type: file.mimetype });
      
      const transcription = await openai.audio.transcriptions.create({
        file: audioFile,
        model: "whisper-1",
        language: "en",
        response_format: "text",
      });

      const transcript = typeof transcription === 'string' ? transcription.trim() : (transcription as any).text?.trim() || "";
      console.log(`[Transcribe] Result: "${transcript}"`);

      res.json({ transcript });
    } catch (error: any) {
      console.error("[Transcribe] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/voice/clone", audioUpload.single("audio"), async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    if (!isElevenLabsConfigured()) {
      return res.status(400).json({ error: "ElevenLabs API key not configured. Please add ELEVENLABS_API_KEY to your secrets." });
    }

    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ error: "No audio file uploaded" });
      }

      const voiceName = req.body.name || `My Voice - ${auth.userId}`;
      const description = req.body.description || "Custom voice clone";

      console.log(`[Voice Clone] Starting clone for user ${auth.userId}, file size: ${file.size} bytes`);

      const result = await cloneVoiceFromBuffer(voiceName, file.buffer, description);

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      await storage.updateUserVoice(auth.userId, result.voiceId!, result.voiceName!);

      console.log(`[Voice Clone] Success: ${result.voiceId} for user ${auth.userId}`);

      res.json({
        success: true,
        voiceId: result.voiceId,
        voiceName: result.voiceName,
        message: "Voice cloned successfully! Minutz will now speak in your voice.",
      });
    } catch (error: any) {
      console.error("[Voice Clone] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/voice/clone", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const user = await storage.getUserById(auth.userId);
      if (!user?.elevenlabsVoiceId) {
        return res.status(404).json({ error: "No cloned voice found" });
      }

      const deleted = await deleteVoice(user.elevenlabsVoiceId);
      if (deleted) {
        await storage.updateUserVoice(auth.userId, null, null);
      }

      res.json({ success: true, message: "Voice deleted successfully" });
    } catch (error: any) {
      console.error("[Voice Delete] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/voice/tts", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const { text, voiceId: requestVoiceId } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const user = await storage.getUserById(auth.userId);
      // Priority: request voiceId > user's cloned voice > default
      const voiceId = requestVoiceId || user?.elevenlabsVoiceId || undefined;

      const audioBuffer = await textToSpeech(text, voiceId);
      if (!audioBuffer) {
        return res.status(500).json({ error: "Failed to generate speech" });
      }

      res.set({
        "Content-Type": "audio/mpeg",
        "Content-Length": audioBuffer.length.toString(),
      });
      res.send(audioBuffer);
    } catch (error: any) {
      console.error("[Voice TTS] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== VISION ANALYSIS =====
  app.post("/api/vision/analyze", async (req, res) => {
    const auth = validateAuthToken(req);
    if (!auth) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const { image, silent } = req.body;
      if (!image) {
        return res.status(400).json({ error: "Image data is required" });
      }

      console.log("[Vision] Analyzing image for user:", auth.userId, "silent:", silent);

      const systemPrompt = silent
        ? "You are Minutz AI with vision. Briefly identify key objects, people, or text visible. Only mention notable items. One short sentence max. If nothing interesting, respond with 'nothing notable'."
        : "You are Minutz, a Jarvis-style AI assistant with vision capabilities. When analyzing images, identify objects, people, text, locations, and any notable details. Be conversational and helpful. Describe what you see naturally, as if you're talking to the user. Keep responses concise but informative - about 2-3 sentences.";

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: [
              { type: "text", text: silent ? "Quick scan - what's here?" : "What do you see in this image?" },
              { type: "image_url", image_url: { url: image } }
            ]
          }
        ],
        max_tokens: silent ? 100 : 300,
      });

      const description = response.choices[0]?.message?.content || "I couldn't analyze the image clearly.";
      console.log("[Vision] Analysis complete:", description.substring(0, 100) + "...");

      res.json({ description });
    } catch (error: any) {
      console.error("[Vision] Analysis error:", error.message);
      res.status(500).json({ error: "Failed to analyze image" });
    }
  });

  return httpServer;
}

// Helper functions
function formatTimestamp(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

function extractLocationFromMessage(message: string): string | null {
  // Simple pattern: look for "in" or "at" followed by a location
  // This handles: "in Pondicherry", "at Pondicherry", etc.
  const lowerMsg = message.toLowerCase();
  
  // Try to extract location after "in" or "at"
  const inAtMatch = message.match(/\b(?:in|at)\s+([A-Za-z\s]+?)(?:\s+(?:now|today|tomorrow|weather|rain|forecast)|\.|,|$)/i);
  if (inAtMatch && inAtMatch[1]) {
    const location = inAtMatch[1].trim();
    if (location.length > 2 && !['the', 'a', 'an'].includes(location.toLowerCase())) {
      return location;
    }
  }
  
  // Try to extract location after "weather in" or "weather for"
  const weatherMatch = message.match(/(?:weather|forecast)\s+(?:in|for|at)\s+([A-Za-z\s]+?)(?:\s+(?:now|today)|\.|,|$)/i);
  if (weatherMatch && weatherMatch[1]) {
    const location = weatherMatch[1].trim();
    if (location.length > 2) {
      return location;
    }
  }

  // Try to extract location after "am" or "is"
  const amIsMatch = message.match(/\b(?:am|is|are)\s+(?:in|at)\s+([A-Za-z\s]+?)(?:\s+(?:now|today)|\.|,|$)/i);
  if (amIsMatch && amIsMatch[1]) {
    const location = amIsMatch[1].trim();
    if (location.length > 2) {
      return location;
    }
  }

  return null;
}

function getWeatherDescription(weatherCode: number): string {
  // WMO Weather interpretation codes
  const codes: { [key: number]: string } = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Foggy",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    71: "Slight snow",
    73: "Moderate snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail",
  };

  return codes[weatherCode] || "Unknown";
}
