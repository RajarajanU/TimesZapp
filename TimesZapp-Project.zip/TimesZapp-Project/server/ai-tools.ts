import { storage } from "./storage";
import { isGmailConnected, getRecentEmails } from "./gmail";

export interface ToolResult {
  success: boolean;
  data?: any;
  error?: string;
}

export interface SocialItemSummary {
  id: number;
  source: string;
  type: string;
  title: string;
  author: string;
  date: string;
  trustScore?: number;
  snippet: string;
}

export async function fetchSocialItems(
  userId: number,
  options: { sources?: string[]; limit?: number; since?: Date }
): Promise<ToolResult> {
  try {
    const items: SocialItemSummary[] = [];
    const services = await storage.getUserServices(userId);
    const serviceMap = new Map(services.map(s => [s.serviceName.toLowerCase(), s]));
    const connectedSources = Array.from(serviceMap.keys());
    
    const sourcesToFetch = options.sources 
      ? options.sources.filter(s => connectedSources.includes(s))
      : connectedSources;

    const unavailableSources: string[] = [];

    for (const source of sourcesToFetch) {
      const service = serviceMap.get(source);
      const connectionDate = service?.connectedAt;
      const sinceDate = options.since || connectionDate;
      
      if (source === "gmail") {
        try {
          const gmailConnected = await isGmailConnected();
          if (gmailConnected) {
            const emails = await getRecentEmails(options.limit || 10);
            for (const email of emails) {
              const emailDate = email.date ? new Date(email.date) : new Date();
              if (connectionDate && emailDate < connectionDate) continue;
              
              items.push({
                id: 0,
                source: "gmail",
                type: "email",
                title: email.subject || "(No subject)",
                author: email.from || "Unknown",
                date: email.date || new Date().toISOString(),
                snippet: email.snippet || "",
              });
            }
          }
        } catch (e) {
          console.log("[AI Tools] Gmail fetch error:", e);
          unavailableSources.push("gmail");
        }
      } else {
        unavailableSources.push(source);
      }
      
      const dbItems = await storage.getUserSocialItems(userId, {
        source,
        limit: options.limit || 20,
        since: sinceDate,
      });
      
      for (const item of dbItems) {
        items.push({
          id: item.id,
          source: item.source,
          type: item.itemType,
          title: item.title || "",
          author: item.author || item.authorHandle || "Unknown",
          date: item.itemDate?.toISOString() || item.fetchedAt.toISOString(),
          trustScore: item.trustScore || undefined,
          snippet: (item.content || "").substring(0, 200),
        });
      }
    }

    const uniqueSources = Array.from(new Set(items.map(i => i.source)));
    
    return {
      success: true,
      data: {
        itemCount: items.length,
        sources: uniqueSources,
        items: items.slice(0, options.limit || 20),
        connectedNetworks: connectedSources,
        unavailableNetworks: unavailableSources.length > 0 ? unavailableSources : undefined,
        note: unavailableSources.length > 0 
          ? `Data from ${unavailableSources.join(', ')} is not yet available. Full API integration is coming soon.`
          : undefined,
      },
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function detectTrends(
  items: SocialItemSummary[]
): Promise<ToolResult> {
  try {
    if (items.length === 0) {
      return {
        success: true,
        data: {
          trends: [],
          summary: "No items to analyze for trends.",
        },
      };
    }

    const wordFreq: Record<string, number> = {};
    const sourceFreq: Record<string, number> = {};
    const topicClusters: Record<string, SocialItemSummary[]> = {};

    for (const item of items) {
      sourceFreq[item.source] = (sourceFreq[item.source] || 0) + 1;
      
      const words = `${item.title} ${item.snippet}`
        .toLowerCase()
        .split(/\W+/)
        .filter(w => w.length > 4);
      
      for (const word of words) {
        if (!STOP_WORDS.has(word)) {
          wordFreq[word] = (wordFreq[word] || 0) + 1;
        }
      }
    }

    const topWords = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([word, count]) => ({ word, count }));

    const trends = topWords.slice(0, 5).map(({ word, count }) => ({
      topic: word,
      mentions: count,
      sources: Object.keys(sourceFreq),
    }));

    return {
      success: true,
      data: {
        trends,
        sourceBreakdown: sourceFreq,
        topKeywords: topWords,
        totalItems: items.length,
      },
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function classifySourceTrust(
  author: string,
  domain?: string
): Promise<ToolResult> {
  try {
    let trustScore = 50;
    const signals: string[] = [];

    const verifiedDomains = [
      "gmail.com", "google.com", "microsoft.com", "apple.com",
      "linkedin.com", "facebook.com", "twitter.com", "github.com",
      "amazon.com", "bbc.com", "cnn.com", "nytimes.com", "reuters.com",
      "washingtonpost.com", "theguardian.com", "wsj.com", "forbes.com"
    ];
    
    const suspiciousDomains = [
      "bit.ly", "tinyurl.com", "t.co", "goo.gl"
    ];

    if (domain) {
      const lowerDomain = domain.toLowerCase();
      
      if (verifiedDomains.some(d => lowerDomain.includes(d))) {
        trustScore += 30;
        signals.push("Verified major platform/publication");
      }
      
      if (suspiciousDomains.some(d => lowerDomain.includes(d))) {
        trustScore -= 20;
        signals.push("Uses URL shortener - verify destination");
      }
      
      if (lowerDomain.match(/\d{4,}/)) {
        trustScore -= 15;
        signals.push("Domain contains unusual number sequences");
      }
    }

    if (author) {
      if (author.includes("@") && author.includes(".")) {
        const emailDomain = author.split("@")[1]?.toLowerCase();
        if (emailDomain && verifiedDomains.some(d => emailDomain.includes(d))) {
          trustScore += 15;
          signals.push("Email from verified domain");
        }
      }
      
      if (author.toLowerCase().includes("verified") || author.includes("✓")) {
        trustScore += 10;
        signals.push("Account appears verified");
      }
      
      if (author.match(/[A-Z]{3,}\d+/) || author.match(/user\d{6,}/i)) {
        trustScore -= 20;
        signals.push("Username pattern suggests bot/spam account");
      }
    }

    trustScore = Math.max(0, Math.min(100, trustScore));

    let reliability: string;
    if (trustScore >= 80) reliability = "highly_reliable";
    else if (trustScore >= 60) reliability = "generally_reliable";
    else if (trustScore >= 40) reliability = "neutral";
    else if (trustScore >= 20) reliability = "potentially_unreliable";
    else reliability = "likely_spam";

    return {
      success: true,
      data: {
        trustScore,
        reliability,
        signals,
        recommendation: trustScore < 50 
          ? "Verify this source independently before trusting the content."
          : "This source appears reasonably trustworthy.",
      },
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

export async function travelAssist(
  destination: string,
  travelDate?: string,
  purpose?: string
): Promise<ToolResult> {
  try {
    let weatherInfo = null;
    
    try {
      const geoResponse = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(destination)}&count=1`
      );
      const geoData = await geoResponse.json();
      
      if (geoData.results && geoData.results.length > 0) {
        const { latitude, longitude, name, country } = geoData.results[0];
        
        const weatherResponse = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode&timezone=auto&forecast_days=7`
        );
        const weatherData = await weatherResponse.json();
        
        if (weatherData.daily) {
          const daily = weatherData.daily;
          weatherInfo = {
            location: `${name}, ${country}`,
            forecast: daily.time.slice(0, 7).map((date: string, i: number) => ({
              date,
              tempMax: daily.temperature_2m_max[i],
              tempMin: daily.temperature_2m_min[i],
              rainChance: daily.precipitation_probability_max[i],
              condition: getWeatherCondition(daily.weathercode[i]),
            })),
          };
        }
      }
    } catch (e) {
      console.log("[AI Tools] Weather fetch error:", e);
    }

    const generalTips = [
      "Carry copies of important documents (passport, ID, insurance)",
      "Share your itinerary with someone you trust",
      "Check visa requirements for your destination",
      "Register with your country's embassy if traveling abroad",
      "Have emergency contacts saved offline",
    ];

    const packingEssentials = [
      "Travel documents and copies",
      "Phone charger and power bank",
      "First aid kit with personal medications",
      "Appropriate clothing for the weather",
      "Travel adapter if going abroad",
    ];

    const safetyPrecautions = [
      "Research local customs and laws",
      "Be aware of common scams in the area",
      "Keep valuables secure and out of sight",
      "Note emergency numbers for your destination",
      "Have travel insurance coverage",
    ];

    if (purpose?.toLowerCase().includes("business")) {
      packingEssentials.push("Business cards", "Laptop and chargers", "Professional attire");
    }
    
    if (weatherInfo) {
      const avgTemp = weatherInfo.forecast.reduce((a: number, f: any) => a + f.tempMax, 0) / weatherInfo.forecast.length;
      if (avgTemp > 30) {
        packingEssentials.push("Sunscreen and sunglasses", "Light breathable clothing", "Hat for sun protection");
        safetyPrecautions.push("Stay hydrated and avoid peak sun hours");
      } else if (avgTemp < 10) {
        packingEssentials.push("Warm layers and jacket", "Gloves and hat", "Warm waterproof footwear");
        safetyPrecautions.push("Watch for icy conditions");
      }
      
      const hasRain = weatherInfo.forecast.some((f: any) => f.rainChance > 50);
      if (hasRain) {
        packingEssentials.push("Umbrella or rain jacket", "Waterproof bag for electronics");
      }
    }

    return {
      success: true,
      data: {
        destination,
        travelDate: travelDate || "Not specified",
        purpose: purpose || "General travel",
        weather: weatherInfo,
        tips: generalTips,
        packingList: packingEssentials,
        safetyPrecautions,
        recommendation: weatherInfo
          ? `Based on the weather forecast for ${weatherInfo.location}, plan accordingly for the conditions.`
          : `Prepare for various weather conditions as forecast data is not available.`,
      },
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

function getWeatherCondition(code: number): string {
  const conditions: Record<number, string> = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Freezing fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Light rain",
    63: "Moderate rain",
    65: "Heavy rain",
    71: "Light snow",
    73: "Moderate snow",
    75: "Heavy snow",
    80: "Light rain showers",
    81: "Moderate rain showers",
    82: "Heavy rain showers",
    95: "Thunderstorm",
  };
  return conditions[code] || "Unknown";
}

export async function setReminder(
  userId: number,
  title: string,
  remindAt: Date,
  options?: { description?: string; priority?: string; recurrence?: string }
): Promise<ToolResult> {
  try {
    const reminder = await storage.createReminder({
      userId,
      title,
      description: options?.description || null,
      remindAt,
      priority: options?.priority || 'normal',
      recurrence: options?.recurrence || null,
    });

    return {
      success: true,
      data: {
        reminder: {
          id: reminder.id,
          title: reminder.title,
          description: reminder.description,
          remindAt: reminder.remindAt.toISOString(),
          priority: reminder.priority,
          recurrence: reminder.recurrence,
        },
        message: `Reminder set for ${reminder.remindAt.toLocaleString()}`,
      },
    };
  } catch (error: any) {
    return {
      success: false,
      error: `Failed to set reminder: ${error.message}`,
    };
  }
}

export async function getUserReminders(userId: number): Promise<ToolResult> {
  try {
    const reminders = await storage.getUserReminders(userId, { includeCompleted: false, limit: 20 });
    
    return {
      success: true,
      data: {
        reminderCount: reminders.length,
        reminders: reminders.map(r => ({
          id: r.id,
          title: r.title,
          description: r.description,
          remindAt: r.remindAt.toISOString(),
          priority: r.priority,
          isCompleted: r.isCompleted,
        })),
      },
    };
  } catch (error: any) {
    return {
      success: false,
      error: `Failed to get reminders: ${error.message}`,
    };
  }
}

export async function completeReminder(reminderId: number): Promise<ToolResult> {
  try {
    await storage.markReminderCompleted(reminderId);
    return {
      success: true,
      data: { message: "Reminder marked as complete" },
    };
  } catch (error: any) {
    return {
      success: false,
      error: `Failed to complete reminder: ${error.message}`,
    };
  }
}

export async function deleteReminder(reminderId: number): Promise<ToolResult> {
  try {
    await storage.deleteReminder(reminderId);
    return {
      success: true,
      data: { message: "Reminder deleted" },
    };
  } catch (error: any) {
    return {
      success: false,
      error: `Failed to delete reminder: ${error.message}`,
    };
  }
}

export async function generateDailyDigest(userId: number): Promise<ToolResult> {
  try {
    const since = new Date();
    since.setHours(since.getHours() - 24);
    
    const socialResult = await fetchSocialItems(userId, { limit: 50, since });
    if (!socialResult.success) {
      return { success: false, error: "Failed to fetch social items" };
    }

    const items = socialResult.data?.items || [];
    const trendsResult = await detectTrends(items);
    
    const unreadBySource: Record<string, number> = {};
    for (const item of items) {
      unreadBySource[item.source] = (unreadBySource[item.source] || 0) + 1;
    }

    const priorityItems = items
      .filter((i: SocialItemSummary) => i.trustScore === undefined || i.trustScore >= 60)
      .slice(0, 5);

    return {
      success: true,
      data: {
        period: "Last 24 hours",
        totalItems: items.length,
        bySource: unreadBySource,
        trends: trendsResult.data?.trends || [],
        priorityItems,
        summary: `You have ${items.length} new items across your connected networks.`,
      },
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

const STOP_WORDS = new Set([
  "about", "after", "again", "being", "could", "doing", "during", "every",
  "first", "found", "getting", "going", "having", "these", "thing", "think",
  "those", "through", "under", "using", "where", "which", "while", "would",
  "there", "their", "other", "should", "really", "right", "before", "because",
]);

export const AI_TOOLS_DEFINITIONS = [
  {
    type: "function",
    function: {
      name: "fetch_social_items",
      description: "Fetch recent items from user's connected social networks (emails, posts, messages). Use this when user asks about updates, what's new, or wants to see recent activity.",
      parameters: {
        type: "object",
        properties: {
          sources: {
            type: "array",
            items: { type: "string" },
            description: "Which networks to fetch from: gmail, facebook, instagram, linkedin, twitter, whatsapp. Leave empty for all.",
          },
          limit: {
            type: "number",
            description: "Maximum number of items to fetch (default: 20)",
          },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "detect_trends",
      description: "Analyze social items to identify trending topics and patterns. Use after fetching items to find what's trending.",
      parameters: {
        type: "object",
        properties: {
          itemIds: {
            type: "array",
            items: { type: "number" },
            description: "IDs of items to analyze for trends",
          },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "classify_source_trust",
      description: "Evaluate the trustworthiness of a source (sender, website, author). Use when user asks if something is reliable or legitimate.",
      parameters: {
        type: "object",
        properties: {
          author: {
            type: "string",
            description: "The author name, email, or username to evaluate",
          },
          domain: {
            type: "string",
            description: "The domain or website URL if available",
          },
        },
        required: ["author"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "travel_assist",
      description: "Provide travel assistance including weather forecast, safety tips, and packing suggestions. Use when user mentions traveling, going somewhere, or trip planning.",
      parameters: {
        type: "object",
        properties: {
          destination: {
            type: "string",
            description: "The destination city or country",
          },
          travelDate: {
            type: "string",
            description: "When the user plans to travel (optional)",
          },
          purpose: {
            type: "string",
            description: "Purpose of travel: business, vacation, family, etc. (optional)",
          },
        },
        required: ["destination"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "daily_digest",
      description: "Generate a summary of all activity across connected networks in the last 24 hours. Use when user asks for a summary or 'what did I miss'.",
      parameters: {
        type: "object",
        properties: {},
      },
    },
  },
  {
    type: "function",
    function: {
      name: "generate_document",
      description: "Generate a downloadable document in various formats. Use when user asks for a resume, CV, cover letter, template, or any downloadable document. Supports Word, PDF, Text, Excel, and PowerPoint formats.",
      parameters: {
        type: "object",
        properties: {
          type: {
            type: "string",
            enum: ["resume", "cv", "cover_letter"],
            description: "Type of document to generate",
          },
          format: {
            type: "string",
            enum: ["docx", "pdf", "txt", "xlsx", "pptx"],
            description: "Output format: docx (Word), pdf (PDF), txt (plain text), xlsx (Excel spreadsheet), pptx (PowerPoint). Default is docx.",
          },
          data: {
            type: "object",
            description: "Optional data for the document. For resumes: fullName, email, phone, location, summary, experience[], education[], skills[]",
          },
        },
        required: ["type"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "set_reminder",
      description: "Set a reminder for the user at a specific time. Use when user asks to remind them about something, set an alert, or remember something later. Parse natural language time like 'in 5 minutes', 'tomorrow at 9am', 'next Monday at 2pm'.",
      parameters: {
        type: "object",
        properties: {
          title: {
            type: "string",
            description: "What to remind the user about",
          },
          remindAt: {
            type: "string",
            description: "ISO 8601 datetime string for when to trigger the reminder",
          },
          description: {
            type: "string",
            description: "Additional details about the reminder (optional)",
          },
          priority: {
            type: "string",
            enum: ["low", "normal", "high", "urgent"],
            description: "Priority level of the reminder. Default is 'normal'.",
          },
          recurrence: {
            type: "string",
            enum: ["none", "daily", "weekly", "monthly"],
            description: "How often to repeat the reminder. Default is 'none' (one-time).",
          },
        },
        required: ["title", "remindAt"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_reminders",
      description: "Get the user's list of active reminders. Use when user asks 'what reminders do I have', 'show my reminders', or 'what did I ask you to remind me about'.",
      parameters: {
        type: "object",
        properties: {},
      },
    },
  },
  {
    type: "function",
    function: {
      name: "complete_reminder",
      description: "Mark a reminder as complete/done. Use when user says they've completed a task or want to dismiss a reminder.",
      parameters: {
        type: "object",
        properties: {
          reminderId: {
            type: "number",
            description: "The ID of the reminder to mark as complete",
          },
        },
        required: ["reminderId"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "delete_reminder",
      description: "Delete a reminder entirely. Use when user wants to cancel or remove a reminder.",
      parameters: {
        type: "object",
        properties: {
          reminderId: {
            type: "number",
            description: "The ID of the reminder to delete",
          },
        },
        required: ["reminderId"],
      },
    },
  },
];
