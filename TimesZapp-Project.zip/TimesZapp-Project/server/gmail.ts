// Gmail Integration Module - Using Replit Gmail Connector
// Note: This connector has limited scopes for add-on style access:
// - gmail.labels (list and manage labels)
// - gmail.send (send emails)
// - gmail.addons.current.message.readonly (read currently viewed message in add-on context)
// Full inbox listing requires gmail.readonly scope which is not available
import { google } from 'googleapis';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=google-mail',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Gmail not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
async function getUncachableGmailClient() {
  const accessToken = await getAccessToken();

  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({
    access_token: accessToken
  });

  return google.gmail({ version: 'v1', auth: oauth2Client });
}

export interface GmailMessage {
  id: string;
  threadId: string;
  from: string;
  subject: string;
  snippet: string;
  date: string;
  isUnread: boolean;
}

export interface GmailLabel {
  id: string;
  name: string;
  type: string;
  messagesTotal?: number;
  messagesUnread?: number;
  threadsTotal?: number;
  threadsUnread?: number;
}

export async function isGmailConnected(): Promise<boolean> {
  try {
    await getAccessToken();
    return true;
  } catch {
    return false;
  }
}

// Get labels with their statistics (unread counts, etc.)
export async function getGmailLabels(): Promise<GmailLabel[]> {
  try {
    const gmail = await getUncachableGmailClient();
    const response = await gmail.users.labels.list({
      userId: 'me',
    });
    
    const labels = response.data.labels || [];
    const labelDetails: GmailLabel[] = [];
    
    // Get detailed info for important system labels
    const importantLabels = ['INBOX', 'UNREAD', 'IMPORTANT', 'STARRED', 'SPAM', 'TRASH', 'SENT', 'DRAFT'];
    
    for (const label of labels) {
      if (!label.id) continue;
      
      // Only get details for important labels to avoid rate limits
      if (importantLabels.includes(label.id)) {
        try {
          const detail = await gmail.users.labels.get({
            userId: 'me',
            id: label.id,
          });
          
          labelDetails.push({
            id: label.id,
            name: label.name || label.id,
            type: label.type || 'user',
            messagesTotal: detail.data.messagesTotal || 0,
            messagesUnread: detail.data.messagesUnread || 0,
            threadsTotal: detail.data.threadsTotal || 0,
            threadsUnread: detail.data.threadsUnread || 0,
          });
        } catch (err) {
          // Add basic info if details fail
          labelDetails.push({
            id: label.id,
            name: label.name || label.id,
            type: label.type || 'user',
          });
        }
      }
    }
    
    return labelDetails;
  } catch (error) {
    console.error('Failed to fetch Gmail labels:', error);
    throw error;
  }
}

// Get inbox statistics using label API (available with gmail.labels scope)
// If sinceDate is provided, tries to count messages received after that date
// Note: Date filtering requires gmail.readonly scope which may not be available
export async function getInboxStats(sinceDate?: Date): Promise<{
  totalMessages: number;
  unreadMessages: number;
  totalThreads: number;
  unreadThreads: number;
  sinceDate?: string;
  isFiltered?: boolean;
}> {
  try {
    const gmail = await getUncachableGmailClient();
    
    // If sinceDate provided, try to count messages since that date
    if (sinceDate) {
      const dateStr = formatDateForGmailQuery(sinceDate);
      
      try {
        // Count total messages since date using messages.list API
        const response: any = await gmail.users.messages.list({
          userId: 'me',
          q: `after:${dateStr} in:inbox`,
          maxResults: 1,
        });
        const totalMessages = response.data.resultSizeEstimate || 0;
        
        // Count unread messages since date
        const unreadResponse: any = await gmail.users.messages.list({
          userId: 'me',
          q: `after:${dateStr} in:inbox is:unread`,
          maxResults: 1,
        });
        const unreadMessages = unreadResponse.data.resultSizeEstimate || 0;
        
        return {
          totalMessages,
          unreadMessages,
          totalThreads: 0,
          unreadThreads: 0,
          sinceDate: sinceDate.toISOString(),
          isFiltered: true,
        };
      } catch (filterError: any) {
        // If filtering fails (e.g., insufficient scope), fall back to label stats
        console.log('[Gmail] Date filtering not available, using label stats');
        const inboxLabel = await gmail.users.labels.get({
          userId: 'me',
          id: 'INBOX',
        });
        
        return {
          totalMessages: inboxLabel.data.messagesTotal || 0,
          unreadMessages: inboxLabel.data.messagesUnread || 0,
          totalThreads: inboxLabel.data.threadsTotal || 0,
          unreadThreads: inboxLabel.data.threadsUnread || 0,
          sinceDate: sinceDate.toISOString(),
          isFiltered: false, // Indicates we couldn't filter by date
        };
      }
    }
    
    // Default: get all-time stats from label
    const inboxLabel = await gmail.users.labels.get({
      userId: 'me',
      id: 'INBOX',
    });
    
    return {
      totalMessages: inboxLabel.data.messagesTotal || 0,
      unreadMessages: inboxLabel.data.messagesUnread || 0,
      totalThreads: inboxLabel.data.threadsTotal || 0,
      unreadThreads: inboxLabel.data.threadsUnread || 0,
    };
  } catch (error) {
    console.error('Failed to get inbox stats:', error);
    return {
      totalMessages: 0,
      unreadMessages: 0,
      totalThreads: 0,
      unreadThreads: 0,
    };
  }
}

// Format date for Gmail query (YYYY/MM/DD format)
function formatDateForGmailQuery(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}/${month}/${day}`;
}

export async function getUnreadCount(): Promise<number> {
  try {
    const stats = await getInboxStats();
    return stats.unreadMessages;
  } catch (error) {
    console.error('Failed to get unread count:', error);
    return 0;
  }
}

// Fetch recent emails from inbox
export async function getRecentEmails(maxResults: number = 10, sinceDate?: Date): Promise<GmailMessage[]> {
  try {
    const gmail = await getUncachableGmailClient();
    
    // Build query - filter by date if provided
    let query = 'in:inbox';
    if (sinceDate) {
      const dateStr = formatDateForGmailQuery(sinceDate);
      query = `after:${dateStr} in:inbox`;
    }
    
    // Get message IDs
    const response = await gmail.users.messages.list({
      userId: 'me',
      q: query,
      maxResults: maxResults,
    });
    
    const messageIds = response.data.messages || [];
    if (messageIds.length === 0) {
      return [];
    }
    
    // Fetch full message details for each
    const messages: GmailMessage[] = [];
    for (const msg of messageIds.slice(0, maxResults)) {
      try {
        const fullMsg = await gmail.users.messages.get({
          userId: 'me',
          id: msg.id!,
          format: 'metadata',
          metadataHeaders: ['From', 'Subject', 'Date'],
        });
        
        const headers = fullMsg.data.payload?.headers || [];
        const fromHeader = headers.find(h => h.name?.toLowerCase() === 'from');
        const subjectHeader = headers.find(h => h.name?.toLowerCase() === 'subject');
        const dateHeader = headers.find(h => h.name?.toLowerCase() === 'date');
        
        // Extract email address from "Name <email@domain.com>" format
        const fromValue = fromHeader?.value || 'Unknown';
        const fromMatch = fromValue.match(/<([^>]+)>/);
        const fromEmail = fromMatch ? fromMatch[1] : fromValue;
        const fromName = fromValue.replace(/<[^>]+>/, '').trim() || fromEmail;
        
        const labelIds = fullMsg.data.labelIds || [];
        
        messages.push({
          id: msg.id!,
          threadId: fullMsg.data.threadId || msg.id!,
          from: fromName,
          subject: subjectHeader?.value || 'No Subject',
          snippet: fullMsg.data.snippet || '',
          date: dateHeader?.value || new Date().toISOString(),
          isUnread: labelIds.includes('UNREAD'),
        });
      } catch (msgErr) {
        console.error(`[Gmail] Failed to fetch message ${msg.id}:`, msgErr);
      }
    }
    
    return messages;
  } catch (error: any) {
    console.error('[Gmail] Failed to fetch recent emails:', error.message);
    return [];
  }
}
