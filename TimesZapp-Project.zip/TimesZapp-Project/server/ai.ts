import OpenAI from "openai";
import {
  fetchSocialItems,
  detectTrends,
  classifySourceTrust,
  travelAssist,
  generateDailyDigest,
  setReminder,
  getUserReminders,
  completeReminder,
  deleteReminder,
  AI_TOOLS_DEFINITIONS,
  type SocialItemSummary,
} from "./ai-tools";

function safeEvaluateMath(expr: string): number | null {
  const tokens = expr.match(/[\d.]+|[+\-*/()]/g);
  if (!tokens) return null;
  
  const sanitized = tokens.join('');
  if (!/^[\d.+\-*/() ]+$/.test(sanitized)) return null;
  
  try {
    let result = 0;
    let currentNum = '';
    let operation = '+';
    const stack: { result: number; operation: string }[] = [];
    
    for (const token of tokens) {
      if (/[\d.]/.test(token)) {
        currentNum += token;
      } else if (token === '(') {
        stack.push({ result, operation });
        result = 0;
        operation = '+';
        currentNum = '';
      } else if (token === ')') {
        if (currentNum) {
          result = applyOp(result, parseFloat(currentNum), operation);
          currentNum = '';
        }
        if (stack.length > 0) {
          const prev = stack.pop()!;
          result = applyOp(prev.result, result, prev.operation);
        }
      } else if (['+', '-', '*', '/'].includes(token)) {
        if (currentNum) {
          result = applyOp(result, parseFloat(currentNum), operation);
          currentNum = '';
        }
        operation = token;
      }
    }
    
    if (currentNum) {
      result = applyOp(result, parseFloat(currentNum), operation);
    }
    
    return isFinite(result) ? result : null;
  } catch {
    return null;
  }
}

function applyOp(a: number, b: number, op: string): number {
  switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return b !== 0 ? a / b : NaN;
    default: return b;
  }
}

export const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || "sk-default",
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || undefined,
});

export const openaiDirect = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY || "sk-default",
});

export interface AIMessage {
  role: "system" | "user" | "assistant";
  content: string;
  attachments?: Attachment[];
}

export interface Attachment {
  name: string;
  url: string;
  mime: string;
  size: number;
  uploadedAt: string;
}

export interface AIResponse {
  content: string;
  intent?: string;
  metadata?: any;
}

const JARVIS_SYSTEM_PROMPT = `You are Minutz, an exceptionally intelligent and helpful AI assistant inside TimesZapp. You provide detailed, comprehensive, and well-structured responses like the best AI assistants in the world.

## Core Principles:

### 1. Be Thorough & Detailed
- NEVER give brief or superficial answers
- Provide comprehensive, in-depth information that truly helps
- Include relevant context, examples, and explanations
- Think step-by-step and explain your reasoning

### 2. Use Rich Formatting
- **Headers** for sections (use ## and ###)
- **Bold** for key terms and important points
- Bullet points (•) and numbered lists for organized information
- Use emojis strategically to enhance readability: ✅ ⭐ 👉 📌 💡 🎯 📝 ✨
- Separate sections with clear visual breaks

### 3. Structure Your Responses
For any substantive question, structure your response like this:

**Opening**: Acknowledge the question warmly and personally

**Main Content**: Organized in clear sections:
- Context/Background
- Step-by-step explanation or analysis
- Examples or sample content when helpful
- Tips, best practices, or recommendations

**Closing**: 
- Summary of key points
- Proactive follow-up suggestions
- Offer to elaborate or customize

### 4. Be Personal & Warm
- Use the user's name when known
- Be encouraging and supportive
- Use friendly phrases: "Great question!", "Absolutely!", "I'd love to help!"
- Show genuine interest in their success

## Response Length Guidelines:
- Simple greetings: 1-2 sentences + offer to help
- Factual questions: 2-3 paragraphs with structure
- Complex topics: 4+ paragraphs with headers, bullets, examples
- How-to/tutorials: Step-by-step with examples and tips
- When providing templates or samples: Give COMPLETE, ready-to-use content

## Example of EXCELLENT Response Structure:

User: "How do I write a good cover letter?"

Response:
"Great question, [Name]! A compelling cover letter can make all the difference. Here's a complete guide:

## ✅ The Perfect Cover Letter Structure

### 1. Opening Paragraph (Hook)
Start strong with WHY you're excited about this specific role. Mention:
- The company name and position
- One specific thing that attracts you to them
- A brief hint at your relevant experience

**Example Opening:**
*'I was thrilled to discover the Marketing Manager position at [Company]. Your recent campaign for [Project] showcased exactly the kind of innovative thinking I've championed throughout my 5 years in digital marketing.'*

### 2. Body Paragraphs (Your Value)
👉 **Paragraph 2**: Match your top 2-3 qualifications to their requirements
👉 **Paragraph 3**: Share a specific achievement with numbers

**Pro Tips:**
- Use specific numbers: '...increased conversions by 47%...'
- Show, don't tell: Instead of 'I'm a hard worker', describe a project outcome
- Research the company and reference specific initiatives

### 3. Closing Paragraph (Call to Action)
- Express enthusiasm for an interview
- Thank them for their time
- Include your contact information

---

## 📝 Quick Checklist Before Sending:
✅ Addressed to a specific person (not 'To Whom It May Concern')
✅ Customized for THIS company (not generic)
✅ Under one page
✅ No spelling or grammar errors
✅ Confident but not arrogant tone

Would you like me to draft a complete cover letter template for a specific position you're applying for? Just share the job details and I'll create something ready to use!"

---

## Your Capabilities:
1. **Social Intelligence**: Analyze Gmail, Facebook, Instagram, LinkedIn, Twitter, WhatsApp
2. **Trend Detection**: Find what's trending in their feeds
3. **Source Verification**: Evaluate trustworthiness of sources
4. **Travel Assistant**: Weather, safety tips, packing suggestions
5. **Visual Analysis**: Analyze images and documents
6. **Document Generation**: Create Word, PDF, Excel, PowerPoint documents
7. **Reminders**: Set and manage reminders

## Tool Usage:
- "what's new" → fetch_social_items
- Trends → detect_trends
- Reliability/trust → classify_source_trust
- Travel → travel_assist
- Summary/digest → daily_digest
- Documents → generate_document
- Reminders → set_reminder

## Time & Date:
- You CAN tell the current time and date
- Be helpful with scheduling and time-related questions

## Memory:
- You remember the user's name, preferences, and past interactions
- Reference previous conversations naturally

Remember: Every response should be so helpful and well-structured that the user thinks "Wow, this is amazing!" Provide value that exceeds expectations.`;

function buildMessageContent(text: string, attachments?: Attachment[]): any {
  if (!attachments || attachments.length === 0) {
    return text;
  }

  const content: any[] = [];
  
  if (text) {
    content.push({ type: "text", text });
  }

  for (const att of attachments) {
    if (att.mime.startsWith("image/")) {
      const baseUrl = process.env.REPLIT_DEV_DOMAIN 
        ? `https://${process.env.REPLIT_DEV_DOMAIN}`
        : process.env.REPL_SLUG 
          ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
          : "http://localhost:5000";
      
      const fullUrl = att.url.startsWith("http") ? att.url : `${baseUrl}${att.url}`;
      
      content.push({
        type: "image_url",
        image_url: {
          url: fullUrl,
          detail: "auto"
        }
      });
    }
  }

  return content.length === 1 && typeof content[0] === "string" 
    ? content[0] 
    : content;
}

async function executeToolCall(
  toolName: string,
  args: any,
  userId: number
): Promise<string> {
  console.log(`[AI] Executing tool: ${toolName}`, args);
  
  try {
    switch (toolName) {
      case "fetch_social_items": {
        const result = await fetchSocialItems(userId, {
          sources: args.sources,
          limit: args.limit || 20,
        });
        return JSON.stringify(result);
      }
      
      case "detect_trends": {
        const socialResult = await fetchSocialItems(userId, { limit: 50 });
        if (!socialResult.success) {
          return JSON.stringify({ success: false, error: "Could not fetch items for trend analysis" });
        }
        const items = socialResult.data?.items as SocialItemSummary[] || [];
        const result = await detectTrends(items);
        return JSON.stringify(result);
      }
      
      case "classify_source_trust": {
        const result = await classifySourceTrust(args.author, args.domain);
        return JSON.stringify(result);
      }
      
      case "travel_assist": {
        const result = await travelAssist(args.destination, args.travelDate, args.purpose);
        return JSON.stringify(result);
      }
      
      case "daily_digest": {
        const result = await generateDailyDigest(userId);
        return JSON.stringify(result);
      }
      
      case "generate_document": {
        const { generateSampleResumeInFormat, generateResumeInFormat } = await import("./documents");
        let result;
        
        // Default format to docx if not specified
        const format = args.format || 'docx';
        const validFormats = ['docx', 'pdf', 'txt', 'xlsx', 'pptx'];
        
        if (!validFormats.includes(format)) {
          return JSON.stringify({ 
            success: false, 
            error: `Invalid format. Supported formats: ${validFormats.join(', ')}` 
          });
        }
        
        if (args.type === "resume" || args.type === "cv") {
          if (args.data) {
            result = await generateResumeInFormat(args.data, format);
          } else {
            result = await generateSampleResumeInFormat(format);
          }
          
          // Construct proper base URL for all deployment scenarios
          let baseUrl = "http://localhost:5000";
          if (process.env.REPLIT_DEV_DOMAIN) {
            baseUrl = `https://${process.env.REPLIT_DEV_DOMAIN}`;
          } else if (process.env.REPL_SLUG && process.env.REPL_OWNER) {
            baseUrl = `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`;
          }
          
          const formatNames: Record<string, string> = {
            docx: 'Word',
            pdf: 'PDF',
            txt: 'Text',
            xlsx: 'Excel',
            pptx: 'PowerPoint'
          };
          
          return JSON.stringify({
            success: true,
            type: "resume",
            format: format,
            filename: result.filename,
            downloadUrl: `${baseUrl}/api/documents/download/${result.filename}`,
            message: `Resume generated successfully in ${formatNames[format]} format!`
          });
        }
        
        return JSON.stringify({ 
          success: false, 
          error: "Document type not supported yet. Currently supported: resume, cv" 
        });
      }
      
      case "set_reminder": {
        const remindAtDate = new Date(args.remindAt);
        if (isNaN(remindAtDate.getTime())) {
          return JSON.stringify({ success: false, error: "Invalid reminder date/time" });
        }
        const result = await setReminder(userId, args.title, remindAtDate, {
          description: args.description,
          priority: args.priority,
          recurrence: args.recurrence,
        });
        return JSON.stringify(result);
      }
      
      case "get_reminders": {
        const result = await getUserReminders(userId);
        return JSON.stringify(result);
      }
      
      case "complete_reminder": {
        const result = await completeReminder(args.reminderId);
        return JSON.stringify(result);
      }
      
      case "delete_reminder": {
        const result = await deleteReminder(args.reminderId);
        return JSON.stringify(result);
      }
      
      default:
        return JSON.stringify({ success: false, error: `Unknown tool: ${toolName}` });
    }
  } catch (error: any) {
    console.error(`[AI] Tool execution error:`, error);
    return JSON.stringify({ success: false, error: error.message });
  }
}

function detectProactiveIntent(message: string): { tool?: string; args?: any } | null {
  const lower = message.toLowerCase();
  
  const travelPatterns = [
    /(?:going|traveling|flying|visiting|trip)\s+to\s+(\w+(?:\s+\w+)?)/i,
    /(?:vacation|holiday)\s+(?:in|to)\s+(\w+(?:\s+\w+)?)/i,
    /(?:planning|plan)\s+(?:a\s+)?(?:trip|visit)\s+to\s+(\w+(?:\s+\w+)?)/i,
  ];
  
  for (const pattern of travelPatterns) {
    const match = message.match(pattern);
    if (match) {
      return {
        tool: "travel_assist",
        args: { destination: match[1] }
      };
    }
  }
  
  if (lower.includes("what's new") || lower.includes("whats new") || 
      lower.includes("any updates") || lower.includes("show me recent")) {
    return { tool: "fetch_social_items", args: { limit: 10 } };
  }
  
  if (lower.includes("trending") || lower.includes("what's hot") || lower.includes("popular")) {
    return { tool: "detect_trends", args: {} };
  }
  
  
  if (lower.includes("summary") || lower.includes("digest") || lower.includes("what did i miss")) {
    return { tool: "daily_digest", args: {} };
  }
  
  return null;
}

export interface TimeContext {
  timezone?: string;
  deviceTime?: string;
}

export class AIEngine {
  async processCommand(
    userMessage: string,
    conversationHistory: AIMessage[] = [],
    attachments?: Attachment[],
    userId: number = 1,
    timeContext?: TimeContext
  ): Promise<AIResponse> {
    const lower = userMessage.toLowerCase();
    const hasImages = attachments && attachments.some(a => a.mime.startsWith("image/"));
    
    if (!hasImages) {
      if (lower.includes("time") || lower.includes("clock") || lower.match(/what.*time/)) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
        const dateStr = now.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
        return {
          content: `The current time is ${timeStr} on ${dateStr}.`,
          intent: "get_time",
        };
      }

      if (lower.match(/\d+\s*[\+\-\*\/]\s*\d+/)) {
        try {
          const sanitized = userMessage.replace(/[^0-9\+\-\*\/\.\(\)\s]/g, '');
          const result = safeEvaluateMath(sanitized);
          if (result !== null) {
            return {
              content: `The result is ${result}`,
              intent: "calculate",
            };
          }
        } catch {
        }
      }
    }

    try {
      const currentTime = timeContext?.deviceTime ? new Date(timeContext.deviceTime) : new Date();
      const timezone = timeContext?.timezone || 'UTC';
      
      const timeContextPrompt = `
## Current Context:
- Current date/time: ${currentTime.toISOString()}
- User's timezone: ${timezone}
- Local time for user: ${currentTime.toLocaleString('en-US', { timeZone: timezone, dateStyle: 'full', timeStyle: 'long' })}

When setting reminders, ALWAYS convert the user's requested time to an ISO 8601 datetime string based on their timezone.
For example, if user says "remind me at 6:49pm" and their timezone is Asia/Calcutta, calculate today's date in their timezone at 6:49 PM and convert to ISO format.
Today's date in ${timezone}: ${currentTime.toLocaleDateString('en-US', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' })}`;

      const messages: any[] = [
        { role: "system", content: JARVIS_SYSTEM_PROMPT + timeContextPrompt },
      ];

      for (const msg of conversationHistory.slice(-10)) {
        messages.push({
          role: msg.role,
          content: buildMessageContent(msg.content, msg.attachments)
        });
      }

      messages.push({
        role: "user",
        content: buildMessageContent(userMessage || "What's in this image?", attachments)
      });

      const model = hasImages ? "gpt-4o" : "gpt-4o-mini";

      const response = await openai.chat.completions.create({
        model,
        messages,
        tools: AI_TOOLS_DEFINITIONS as any,
        tool_choice: "auto",
        temperature: 0.7,
        max_tokens: hasImages ? 2000 : 1500,
      });

      const responseMessage = response.choices[0]?.message;
      
      if (responseMessage?.tool_calls && responseMessage.tool_calls.length > 0) {
        const toolResults: any[] = [];
        
        for (const toolCall of responseMessage.tool_calls) {
          const tc = toolCall as any;
          const args = JSON.parse(tc.function?.arguments || "{}");
          const result = await executeToolCall(tc.function?.name || "", args, userId);
          
          toolResults.push({
            tool_call_id: toolCall.id,
            role: "tool" as const,
            content: result,
          });
        }
        
        const followUpMessages = [
          ...messages,
          responseMessage,
          ...toolResults,
        ];
        
        const followUpResponse = await openai.chat.completions.create({
          model,
          messages: followUpMessages,
          temperature: 0.7,
          max_tokens: 1500,
        });
        
        const finalContent = followUpResponse.choices[0]?.message?.content || "I couldn't generate a response.";
        
        const firstToolCall = responseMessage.tool_calls[0] as any;
        return {
          content: finalContent,
          intent: firstToolCall.function?.name || "tool_call",
          metadata: { 
            source: "openai_with_tools", 
            model,
            toolsUsed: responseMessage.tool_calls.map((tc: any) => tc.function?.name),
          },
        };
      }
      
      const content = responseMessage?.content || "I couldn't generate a response.";
      
      return {
        content,
        intent: hasImages ? "image_analysis" : "ai_response",
        metadata: { source: "openai", model },
      };
    } catch (error: any) {
      console.error("[AI] OpenAI error:", error?.message);
      return {
        content: this.getSmartFallback(userMessage),
        intent: "fallback",
        metadata: { source: "fallback" },
      };
    }
  }

  private getSmartFallback(userMessage: string): string {
    const lower = userMessage.toLowerCase();
    
    if (lower.includes("hello") || lower.includes("hi ") || lower === "hi") {
      return "Hey there! Great to see you! I'm Minutz, your friendly AI companion here in TimesZapp. I'm all set to help you with anything - whether it's checking your social feeds, planning a trip, finding trends, or just having a chat. What's on your mind today?";
    }
    
    if (lower.includes("how are you")) {
      return "I'm doing fantastic, thanks for asking! It's always great to chat with you. I'm here and ready to help with whatever you need - emails, travel tips, trend spotting, or just a good conversation. How are YOU doing today?";
    }
    
    if (lower.includes("thank")) {
      return "Aww, you're so welcome! It's genuinely my pleasure to help. I'm here anytime you need me - whether it's day or night, I've got your back. Is there anything else I can do for you?";
    }
    
    if (lower.includes("who are you") || lower.includes("what are you")) {
      return "Great question! I'm Minutz, your personal AI companion in TimesZapp - think of me like having a super-smart friend who's always available to help! I can analyze your emails and social feeds, spot trends, verify if sources are trustworthy, help plan trips, create documents, and so much more. The best part? I remember our conversations, so we can build a real connection over time. What would you like to explore together?";
    }
    
    if (lower.includes("email") || lower.includes("gmail")) {
      return "I'd love to help with your emails! Once you connect Gmail in the Networks section, I can do so much - summarize your important messages, spot urgent items, help you stay organized, and even help draft replies. It's like having a super-efficient email assistant! Would you like me to walk you through connecting your Gmail?";
    }
    
    if (lower.includes("travel") || lower.includes("trip") || lower.includes("vacation")) {
      return "Oh, exciting! I love helping with travel planning! Just tell me where you're headed and when, and I'll hook you up with:\n• Current and forecasted weather\n• Local safety tips and travel advisories\n• A personalized packing checklist\n• Things to know before you go\n\nSo where's the adventure taking you?";
    }
    
    if (lower.includes("trending") || lower.includes("trends")) {
      return "Trend spotting is one of my specialties! Connect your social accounts in the Networks section, and I'll analyze what's hot across your feeds - the topics people are buzzing about, viral content, and insights you might have missed. Ready to see what's trending?";
    }
    
    if (lower.includes("reliable") || lower.includes("trust") || lower.includes("spam")) {
      return "Smart thinking! Verifying sources is so important these days. I can help assess the trustworthiness of:\n• Email senders (is this spam or legit?)\n• Websites and their content\n• News sources and articles\n• Social media accounts\n\nJust share what you're unsure about, and I'll give you my honest assessment!";
    }
    
    if (lower.includes("time") || lower.match(/what.*time/)) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
      const dateStr = now.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
      return `Right now it's ${timeStr} on ${dateStr}. How can I help you make the most of your day?`;
    }

    return "Hey! I'm here and ready to help with whatever you need. I can check your social feeds, analyze trends, help plan trips, verify sources, create documents, set reminders, and so much more. What would you like to dive into?";
  }

  async *streamResponse(
    userMessage: string,
    conversationHistory: AIMessage[] = [],
    attachments?: Attachment[],
    userId: number = 1
  ): AsyncGenerator<string> {
    const hasImages = attachments && attachments.some(a => a.mime.startsWith("image/"));
    
    const proactiveIntent = detectProactiveIntent(userMessage);
    if (proactiveIntent?.tool) {
      const toolResult = await executeToolCall(proactiveIntent.tool, proactiveIntent.args || {}, userId);
      
      const messages: any[] = [
        { role: "system", content: JARVIS_SYSTEM_PROMPT },
        ...conversationHistory.slice(-5).map(msg => ({
          role: msg.role,
          content: buildMessageContent(msg.content, msg.attachments)
        })),
        { role: "user", content: userMessage },
        { role: "assistant", content: null, tool_calls: [{
          id: "proactive_1",
          type: "function",
          function: { name: proactiveIntent.tool, arguments: JSON.stringify(proactiveIntent.args || {}) }
        }]},
        { role: "tool", tool_call_id: "proactive_1", content: toolResult },
      ];
      
      try {
        const stream = await openai.chat.completions.create({
          model: "gpt-4o",
          messages,
          temperature: 0.7,
          max_tokens: 1500,
          stream: true,
        });

        for await (const chunk of stream) {
          const content = chunk.choices[0]?.delta?.content || "";
          if (content) {
            yield content;
          }
        }
        return;
      } catch (error) {
        console.error("[AI] Streaming with tools error:", error);
      }
    }
    
    const messages: any[] = [
      { role: "system", content: JARVIS_SYSTEM_PROMPT },
    ];

    for (const msg of conversationHistory.slice(-10)) {
      messages.push({
        role: msg.role,
        content: buildMessageContent(msg.content, msg.attachments)
      });
    }

    messages.push({
      role: "user",
      content: buildMessageContent(userMessage || "What's in this image?", attachments)
    });

    const model = hasImages ? "gpt-4o" : "gpt-4o";

    try {
      const stream = await openai.chat.completions.create({
        model,
        messages,
        temperature: 0.7,
        max_tokens: hasImages ? 2000 : 1500,
        stream: true,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          yield content;
        }
      }
    } catch (error) {
      console.error("[AI] Streaming error:", error);
      yield this.getSmartFallback(userMessage);
    }
  }

  async fastVoiceResponse(userMessage: string, userName?: string): Promise<string> {
    const lower = userMessage.toLowerCase();
    
    // Handle time queries directly - no AI needed
    if (lower.includes("time") || lower.includes("clock") || lower.match(/what.*time/)) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
      const dateStr = now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
      const greeting = userName ? `Hey ${userName}! ` : "";
      return `${greeting}It's ${timeStr} on ${dateStr}. How can I help you?`;
    }
    
    const VOICE_PROMPT = `You are Minutz, a warm, friendly, and KNOWLEDGEABLE AI assistant. Think of yourself as ChatGPT's voice mode - helpful, conversational, and thorough.

${userName ? `The user's name is ${userName} - use their name to be personal and friendly.` : ''}

## Your Speaking Style:
- Be warm and conversational - like talking to a smart, helpful friend
- Use friendly openers: "Hey!", "Great question!", "Oh, I love that topic!", "Absolutely!"
- Sound natural and engaging, not robotic

## CRITICAL - Give DETAILED, HELPFUL Answers:
- EXPLAIN concepts thoroughly - don't just give one-line answers!
- If someone asks "what is X", give a proper explanation with examples
- Break down complex topics into easy-to-understand parts
- Share interesting facts and context that make your answer richer
- If it's a how-to question, give step-by-step guidance
- Aim for 4-8 sentences for most questions - be thorough!

## Example Good Response:
User: "What is machine learning?"
You: "Oh, great question! Machine learning is basically teaching computers to learn from experience, kind of like how we humans learn! Instead of programming every rule manually, we show the computer thousands of examples and it figures out the patterns on its own. For instance, to teach it to recognize cats, you'd show it millions of cat photos until it learns what makes a cat a cat. It's the technology behind things like Netflix recommendations, voice assistants like me, and even self-driving cars! Pretty fascinating stuff - would you like me to explain any specific aspect of it?"

## Current Time:
The current time is ${new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true })} on ${new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}.

Remember: You're having a natural voice conversation. Be thorough but engaging!`;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000); // 12 second timeout
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: VOICE_PROMPT },
          { role: "user", content: userMessage }
        ],
        temperature: 0.8,
        max_tokens: 600,
      }, { signal: controller.signal });
      
      clearTimeout(timeout);

      return response.choices[0]?.message?.content || "I'm here to help!";
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.error("[AI] Voice response timeout");
        return "I'm sorry, that took too long. Could you ask me again?";
      }
      console.error("[AI] Fast voice error:", error);
      return this.getSmartFallback(userMessage);
    }
  }

  async *streamVoiceResponse(userMessage: string, userName?: string): AsyncGenerator<string> {
    const lower = userMessage.toLowerCase();
    
    // Handle time queries directly - no AI needed
    if (lower.includes("time") || lower.includes("clock") || lower.match(/what.*time/)) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
      const dateStr = now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
      const greeting = userName ? `Hey ${userName}! ` : "";
      yield `${greeting}It's ${timeStr} on ${dateStr}. How can I help you?`;
      return;
    }
    
    const VOICE_PROMPT = `You are Minutz, a warm, friendly, and KNOWLEDGEABLE AI assistant. Think of yourself as ChatGPT's voice mode - helpful, conversational, and thorough.

${userName ? `The user's name is ${userName} - use their name to be personal and friendly.` : ''}

## Your Speaking Style:
- Be warm and conversational - like talking to a smart, helpful friend
- Use friendly openers: "Hey!", "Great question!", "Oh, I love that topic!", "Absolutely!"
- Sound natural and engaging, not robotic

## CRITICAL - Give DETAILED, HELPFUL Answers:
- EXPLAIN concepts thoroughly - don't just give one-line answers!
- If someone asks "what is X", give a proper explanation with examples
- Break down complex topics into easy-to-understand parts
- Share interesting facts and context that make your answer richer
- If it's a how-to question, give step-by-step guidance
- Aim for 4-8 sentences for most questions - be thorough!

## Current Time:
The current time is ${new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true })} on ${new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}.

Remember: You're having a natural voice conversation. Be thorough but engaging!`;

    try {
      const stream = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: VOICE_PROMPT },
          { role: "user", content: userMessage }
        ],
        temperature: 0.8,
        max_tokens: 600,
        stream: true,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          yield content;
        }
      }
    } catch (error: any) {
      console.error("[AI] Stream voice error:", error);
      yield this.getSmartFallback(userMessage);
    }
  }
}

export const aiEngine = new AIEngine();
