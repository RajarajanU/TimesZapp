import { storage } from "./storage";

const META_APP_ID = process.env.META_APP_ID;
const META_APP_SECRET = process.env.META_APP_SECRET;
const META_REDIRECT_URI = process.env.META_REDIRECT_URI || "https://your-app.replit.app/api/meta/callback";

interface MetaTokens {
  accessToken: string;
  expiresIn?: number;
  tokenType: string;
}

interface InstagramProfile {
  id: string;
  username: string;
  name?: string;
  profilePicture?: string;
  followersCount?: number;
  followsCount?: number;
  mediaCount?: number;
}

interface FacebookProfile {
  id: string;
  name: string;
  email?: string;
  picture?: string;
}

interface MetaStats {
  platform: "facebook" | "instagram";
  followers?: number;
  following?: number;
  posts?: number;
  likes?: number;
  connectedAt?: string;
  isFiltered?: boolean;
}

export function isMetaConfigured(): boolean {
  return !!(META_APP_ID && META_APP_SECRET);
}

export function getFacebookAuthUrl(state: string): string {
  if (!META_APP_ID) {
    throw new Error("Meta App ID not configured");
  }
  
  const scopes = [
    "email",
    "public_profile",
    "pages_show_list",
    "pages_read_engagement"
  ].join(",");
  
  const params = new URLSearchParams({
    client_id: META_APP_ID,
    redirect_uri: META_REDIRECT_URI,
    state: state,
    scope: scopes,
    response_type: "code"
  });
  
  return `https://www.facebook.com/v18.0/dialog/oauth?${params.toString()}`;
}

export function getInstagramAuthUrl(state: string): string {
  if (!META_APP_ID) {
    throw new Error("Meta App ID not configured");
  }
  
  const scopes = [
    "instagram_business_basic",
    "instagram_business_manage_messages",
    "instagram_business_manage_comments",
    "instagram_business_content_publish"
  ].join(",");
  
  const params = new URLSearchParams({
    client_id: META_APP_ID,
    redirect_uri: META_REDIRECT_URI,
    state: `instagram_${state}`,
    scope: scopes,
    response_type: "code"
  });
  
  return `https://www.instagram.com/oauth/authorize?${params.toString()}`;
}

export async function exchangeFacebookCode(code: string): Promise<MetaTokens> {
  if (!META_APP_ID || !META_APP_SECRET) {
    throw new Error("Meta credentials not configured");
  }
  
  const params = new URLSearchParams({
    client_id: META_APP_ID,
    client_secret: META_APP_SECRET,
    redirect_uri: META_REDIRECT_URI,
    code: code,
  });
  
  const response = await fetch(`https://graph.facebook.com/v18.0/oauth/access_token?${params.toString()}`);
  
  if (!response.ok) {
    const error = await response.text();
    console.error("[Meta] Facebook token exchange failed:", error);
    throw new Error("Failed to exchange Facebook authorization code");
  }
  
  const data = await response.json();
  return {
    accessToken: data.access_token,
    expiresIn: data.expires_in,
    tokenType: data.token_type || "bearer",
  };
}

export async function exchangeInstagramCode(code: string): Promise<MetaTokens> {
  if (!META_APP_ID || !META_APP_SECRET) {
    throw new Error("Meta credentials not configured");
  }
  
  const response = await fetch("https://api.instagram.com/oauth/access_token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      client_id: META_APP_ID,
      client_secret: META_APP_SECRET,
      grant_type: "authorization_code",
      redirect_uri: META_REDIRECT_URI,
      code: code,
    }),
  });
  
  if (!response.ok) {
    const error = await response.text();
    console.error("[Meta] Instagram token exchange failed:", error);
    throw new Error("Failed to exchange Instagram authorization code");
  }
  
  const data = await response.json();
  
  const longLivedResponse = await fetch(
    `https://graph.instagram.com/access_token?grant_type=ig_exchange_token&client_secret=${META_APP_SECRET}&access_token=${data.access_token}`
  );
  
  if (longLivedResponse.ok) {
    const longLivedData = await longLivedResponse.json();
    return {
      accessToken: longLivedData.access_token,
      expiresIn: longLivedData.expires_in,
      tokenType: "bearer",
    };
  }
  
  return {
    accessToken: data.access_token,
    tokenType: "bearer",
  };
}

export async function getFacebookProfile(accessToken: string): Promise<FacebookProfile> {
  const response = await fetch(
    `https://graph.facebook.com/v18.0/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`
  );
  
  if (!response.ok) {
    throw new Error("Failed to fetch Facebook profile");
  }
  
  const data = await response.json();
  return {
    id: data.id,
    name: data.name,
    email: data.email,
    picture: data.picture?.data?.url,
  };
}

export async function getInstagramProfile(accessToken: string): Promise<InstagramProfile> {
  const response = await fetch(
    `https://graph.instagram.com/me?fields=id,username,name,profile_picture_url,followers_count,follows_count,media_count&access_token=${accessToken}`
  );
  
  if (!response.ok) {
    throw new Error("Failed to fetch Instagram profile");
  }
  
  const data = await response.json();
  return {
    id: data.id,
    username: data.username,
    name: data.name,
    profilePicture: data.profile_picture_url,
    followersCount: data.followers_count,
    followsCount: data.follows_count,
    mediaCount: data.media_count,
  };
}

export async function getFacebookStats(userId: number): Promise<MetaStats | null> {
  const service = await storage.getService(userId, "facebook");
  if (!service || !service.accessToken) {
    return null;
  }
  
  try {
    const profile = await getFacebookProfile(service.accessToken);
    
    return {
      platform: "facebook",
      posts: 0,
      likes: 0,
      connectedAt: service.connectedAt?.toISOString(),
      isFiltered: false,
    };
  } catch (error) {
    console.error("[Meta] Failed to get Facebook stats:", error);
    return null;
  }
}

export async function getInstagramStats(userId: number): Promise<MetaStats | null> {
  const service = await storage.getService(userId, "instagram");
  if (!service || !service.accessToken) {
    return null;
  }
  
  try {
    const profile = await getInstagramProfile(service.accessToken);
    
    return {
      platform: "instagram",
      followers: profile.followersCount,
      following: profile.followsCount,
      posts: profile.mediaCount,
      connectedAt: service.connectedAt?.toISOString(),
      isFiltered: false,
    };
  } catch (error) {
    console.error("[Meta] Failed to get Instagram stats:", error);
    return null;
  }
}

export async function checkFacebookConnection(userId: number): Promise<{ connected: boolean; profile?: FacebookProfile }> {
  const service = await storage.getService(userId, "facebook");
  if (!service || !service.accessToken) {
    return { connected: false };
  }
  
  try {
    const profile = await getFacebookProfile(service.accessToken);
    return { connected: true, profile };
  } catch (error) {
    console.error("[Meta] Facebook connection check failed:", error);
    return { connected: false };
  }
}

export async function checkInstagramConnection(userId: number): Promise<{ connected: boolean; profile?: InstagramProfile }> {
  const service = await storage.getService(userId, "instagram");
  if (!service || !service.accessToken) {
    return { connected: false };
  }
  
  try {
    const profile = await getInstagramProfile(service.accessToken);
    return { connected: true, profile };
  } catch (error) {
    console.error("[Meta] Instagram connection check failed:", error);
    return { connected: false };
  }
}

export async function getInstagramMedia(accessToken: string, sinceDate?: Date): Promise<any[]> {
  try {
    let url = `https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,thumbnail_url,permalink,timestamp&access_token=${accessToken}`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Failed to fetch Instagram media");
    }
    
    const data = await response.json();
    let media = data.data || [];
    
    if (sinceDate) {
      media = media.filter((item: any) => new Date(item.timestamp) >= sinceDate);
    }
    
    return media;
  } catch (error) {
    console.error("[Meta] Failed to get Instagram media:", error);
    return [];
  }
}
