import { db, withRetry } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import {
  users,
  conversations,
  messages,
  connectedServices,
  notifications,
  passwordResetTokens,
  socialItems,
  aiInsights,
  reminders,
  techNews,
  friendships,
  type User,
  type InsertUser,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type ConnectedService,
  type InsertConnectedService,
  type Notification,
  type InsertNotification,
  type PasswordResetToken,
  type InsertPasswordResetToken,
  type SocialItem,
  type InsertSocialItem,
  type AiInsight,
  type InsertAiInsight,
  type Reminder,
  type InsertReminder,
  type TechNews,
  type InsertTechNews,
  type Friendship,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserVoice(userId: number, voiceId: string | null, voiceName: string | null): Promise<void>;

  // Conversations
  getConversation(id: number): Promise<Conversation | undefined>;
  getUserConversations(userId: number): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversationTimestamp(id: number): Promise<void>;

  // Messages
  getConversationMessages(conversationId: number): Promise<Message[]>;
  getAllUserMessages(userId: number, limit?: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Connected Services
  getUserServices(userId: number): Promise<ConnectedService[]>;
  getService(userId: number, serviceName: string): Promise<ConnectedService | undefined>;
  createService(service: InsertConnectedService): Promise<ConnectedService>;
  updateServiceTokens(id: number, accessToken: string, refreshToken: string | null, expiresAt: Date): Promise<void>;

  // Notifications
  getUserNotifications(userId: number, limit?: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;
  markAllNotificationsAsRead(userId: number): Promise<void>;

  // Password Reset
  createPasswordResetToken(email: string, token: string, expiresAt: Date): Promise<PasswordResetToken>;
  getValidPasswordResetToken(email: string, token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenUsed(id: number): Promise<void>;
  updateUserPassword(email: string, hashedPassword: string): Promise<void>;

  // Social Items (for AI analysis)
  getUserSocialItems(userId: number, options?: { source?: string; limit?: number; since?: Date }): Promise<SocialItem[]>;
  createSocialItem(item: InsertSocialItem): Promise<SocialItem>;
  createManySocialItems(items: InsertSocialItem[]): Promise<SocialItem[]>;
  updateSocialItemTrust(id: number, trustScore: number, sentiment?: string, tags?: string[]): Promise<void>;

  // AI Insights
  getUserInsights(userId: number, options?: { type?: string; limit?: number; unreadOnly?: boolean }): Promise<AiInsight[]>;
  createInsight(insight: InsertAiInsight): Promise<AiInsight>;
  markInsightAsRead(id: number): Promise<void>;

  // Reminders
  getUserReminders(userId: number, options?: { includeCompleted?: boolean; limit?: number }): Promise<Reminder[]>;
  getReminder(id: number): Promise<Reminder | undefined>;
  getDueReminders(userId: number): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: number, updates: Partial<Reminder>): Promise<Reminder>;
  markReminderCompleted(id: number): Promise<void>;
  markReminderNotified(id: number): Promise<void>;
  deleteReminder(id: number): Promise<void>;

  // Tech News (Mr Techie)
  getTechNewsByHour(hourBucket: Date): Promise<TechNews[]>;
  getRecentTechNews(hours?: number): Promise<{ hourBucket: Date; news: TechNews[] }[]>;
  createTechNews(news: InsertTechNews): Promise<TechNews>;
  createManyTechNews(newsItems: InsertTechNews[]): Promise<TechNews[]>;
  getLatestTechNewsHour(): Promise<Date | null>;

  // Friends
  getFriends(userId: number): Promise<{ id: number; name: string | null; email: string }[]>;
  getPendingFriendRequests(userId: number): Promise<{ id: number; requesterId: number; requesterName: string | null; requesterEmail: string; createdAt: Date }[]>;
  searchUsers(query: string, currentUserId: number): Promise<{ id: number; name: string | null; email: string }[]>;
  sendFriendRequest(userId: number, friendId: number): Promise<void>;
  acceptFriendRequest(requestId: number, userId: number): Promise<void>;
  declineFriendRequest(requestId: number, userId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return withRetry(async () => {
      const [user] = await db.select().from(users).where(eq(users.email, email));
      return user;
    });
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    return withRetry(async () => {
      const [user] = await db.insert(users).values(insertUser).returning();
      return user;
    });
  }

  async getUserById(id: number): Promise<User | undefined> {
    return this.getUser(id);
  }

  async updateUserVoice(userId: number, voiceId: string | null, voiceName: string | null): Promise<void> {
    await db.update(users).set({
      elevenlabsVoiceId: voiceId,
      elevenlabsVoiceName: voiceName,
    }).where(eq(users.id, userId));
  }

  // Conversations
  async getConversation(id: number): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation;
  }

  async getUserConversations(userId: number): Promise<Conversation[]> {
    return db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const [conversation] = await db.insert(conversations).values(insertConversation).returning();
    return conversation;
  }

  async updateConversationTimestamp(id: number): Promise<void> {
    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, id));
  }

  // Messages
  async getConversationMessages(conversationId: number): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.timestamp);
  }

  async getAllUserMessages(userId: number, limit: number = 50): Promise<Message[]> {
    // Get all conversations for this user
    const userConversations = await this.getUserConversations(userId);
    const conversationIds = userConversations.map(c => c.id);
    
    if (conversationIds.length === 0) {
      return [];
    }
    
    // Get messages from all conversations, ordered by timestamp desc
    const allMessages: Message[] = [];
    for (const convId of conversationIds) {
      const convMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, convId))
        .orderBy(desc(messages.timestamp));
      allMessages.push(...convMessages);
    }
    
    // Sort all messages by timestamp descending and limit
    allMessages.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return allMessages.slice(0, limit);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    // Update conversation timestamp
    await this.updateConversationTimestamp(insertMessage.conversationId);
    return message;
  }

  // Connected Services
  async getUserServices(userId: number): Promise<ConnectedService[]> {
    return db.select().from(connectedServices).where(eq(connectedServices.userId, userId));
  }

  async getService(userId: number, serviceName: string): Promise<ConnectedService | undefined> {
    const [service] = await db
      .select()
      .from(connectedServices)
      .where(and(eq(connectedServices.userId, userId), eq(connectedServices.serviceName, serviceName)));
    return service;
  }

  async createService(insertService: InsertConnectedService): Promise<ConnectedService> {
    const [service] = await db.insert(connectedServices).values(insertService).returning();
    return service;
  }

  async updateServiceTokens(
    id: number,
    accessToken: string,
    refreshToken: string | null,
    expiresAt: Date
  ): Promise<void> {
    await db
      .update(connectedServices)
      .set({ accessToken, refreshToken, expiresAt })
      .where(eq(connectedServices.id, id));
  }

  async updateService(id: number, updates: Partial<ConnectedService>): Promise<ConnectedService> {
    const [service] = await db
      .update(connectedServices)
      .set(updates)
      .where(eq(connectedServices.id, id))
      .returning();
    return service;
  }

  async deleteService(id: number): Promise<void> {
    await db.delete(connectedServices).where(eq(connectedServices.id, id));
  }

  // Notifications
  async getUserNotifications(userId: number, limit: number = 50): Promise<Notification[]> {
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.receivedAt))
      .limit(limit);
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db.insert(notifications).values(insertNotification).returning();
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
  }

  // Password Reset
  async createPasswordResetToken(email: string, token: string, expiresAt: Date): Promise<PasswordResetToken> {
    return withRetry(async () => {
      const [resetToken] = await db.insert(passwordResetTokens).values({
        email,
        token,
        expiresAt,
        used: false,
      }).returning();
      return resetToken;
    });
  }

  async getValidPasswordResetToken(email: string, token: string): Promise<PasswordResetToken | undefined> {
    return withRetry(async () => {
      const now = new Date();
      const results = await db
        .select()
        .from(passwordResetTokens)
        .where(
          and(
            eq(passwordResetTokens.email, email),
            eq(passwordResetTokens.token, token),
            eq(passwordResetTokens.used, false)
          )
        );
      
      const validToken = results.find(t => t.expiresAt > now);
      return validToken;
    });
  }

  async markPasswordResetTokenUsed(id: number): Promise<void> {
    await db.update(passwordResetTokens).set({ used: true }).where(eq(passwordResetTokens.id, id));
  }

  async updateUserPassword(email: string, hashedPassword: string): Promise<void> {
    return withRetry(async () => {
      await db.update(users).set({ password: hashedPassword }).where(eq(users.email, email));
    });
  }

  // Social Items (for AI analysis)
  async getUserSocialItems(
    userId: number,
    options?: { source?: string; limit?: number; since?: Date }
  ): Promise<SocialItem[]> {
    const conditions = [eq(socialItems.userId, userId)];
    
    if (options?.source) {
      conditions.push(eq(socialItems.source, options.source));
    }
    
    let query = db
      .select()
      .from(socialItems)
      .where(and(...conditions))
      .orderBy(desc(socialItems.fetchedAt));
    
    if (options?.limit) {
      query = query.limit(options.limit) as typeof query;
    }
    
    const results = await query;
    
    if (options?.since) {
      return results.filter(item => 
        item.itemDate && new Date(item.itemDate) >= options.since!
      );
    }
    
    return results;
  }

  async createSocialItem(item: InsertSocialItem): Promise<SocialItem> {
    const [socialItem] = await db.insert(socialItems).values(item).returning();
    return socialItem;
  }

  async createManySocialItems(items: InsertSocialItem[]): Promise<SocialItem[]> {
    if (items.length === 0) return [];
    const result = await db.insert(socialItems).values(items).returning();
    return result;
  }

  async updateSocialItemTrust(
    id: number,
    trustScore: number,
    sentiment?: string,
    tags?: string[]
  ): Promise<void> {
    const updates: Partial<SocialItem> = { trustScore };
    if (sentiment) updates.sentiment = sentiment;
    if (tags) updates.tags = tags;
    
    await db.update(socialItems).set(updates).where(eq(socialItems.id, id));
  }

  // AI Insights
  async getUserInsights(
    userId: number,
    options?: { type?: string; limit?: number; unreadOnly?: boolean }
  ): Promise<AiInsight[]> {
    const conditions = [eq(aiInsights.userId, userId)];
    
    if (options?.type) {
      conditions.push(eq(aiInsights.insightType, options.type));
    }
    
    if (options?.unreadOnly) {
      conditions.push(eq(aiInsights.isRead, false));
    }
    
    let query = db
      .select()
      .from(aiInsights)
      .where(and(...conditions))
      .orderBy(desc(aiInsights.createdAt));
    
    if (options?.limit) {
      query = query.limit(options.limit) as typeof query;
    }
    
    return query;
  }

  async createInsight(insight: InsertAiInsight): Promise<AiInsight> {
    const [aiInsight] = await db.insert(aiInsights).values(insight).returning();
    return aiInsight;
  }

  async markInsightAsRead(id: number): Promise<void> {
    await db.update(aiInsights).set({ isRead: true }).where(eq(aiInsights.id, id));
  }

  // Reminders
  async getUserReminders(
    userId: number,
    options?: { includeCompleted?: boolean; limit?: number }
  ): Promise<Reminder[]> {
    const conditions = [eq(reminders.userId, userId)];
    
    if (!options?.includeCompleted) {
      conditions.push(eq(reminders.isCompleted, false));
    }
    
    let query = db
      .select()
      .from(reminders)
      .where(and(...conditions))
      .orderBy(reminders.remindAt);
    
    if (options?.limit) {
      query = query.limit(options.limit) as typeof query;
    }
    
    return query;
  }

  async getReminder(id: number): Promise<Reminder | undefined> {
    const [reminder] = await db.select().from(reminders).where(eq(reminders.id, id));
    return reminder;
  }

  async getDueReminders(userId: number): Promise<Reminder[]> {
    const now = new Date();
    const results = await db
      .select()
      .from(reminders)
      .where(
        and(
          eq(reminders.userId, userId),
          eq(reminders.isCompleted, false),
          eq(reminders.isNotified, false)
        )
      )
      .orderBy(reminders.remindAt);
    
    return results.filter(r => new Date(r.remindAt) <= now);
  }

  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    const [newReminder] = await db.insert(reminders).values(reminder).returning();
    return newReminder;
  }

  async updateReminder(id: number, updates: Partial<Reminder>): Promise<Reminder> {
    const [reminder] = await db
      .update(reminders)
      .set(updates)
      .where(eq(reminders.id, id))
      .returning();
    return reminder;
  }

  async markReminderCompleted(id: number): Promise<void> {
    await db.update(reminders).set({ isCompleted: true }).where(eq(reminders.id, id));
  }

  async markReminderNotified(id: number): Promise<void> {
    await db.update(reminders).set({ isNotified: true }).where(eq(reminders.id, id));
  }

  async deleteReminder(id: number): Promise<void> {
    await db.delete(reminders).where(eq(reminders.id, id));
  }

  // Tech News (Mr Techie)
  async getTechNewsByHour(hourBucket: Date): Promise<TechNews[]> {
    return await db
      .select()
      .from(techNews)
      .where(eq(techNews.hourBucket, hourBucket))
      .orderBy(desc(techNews.fetchedAt));
  }

  async getRecentTechNews(hours: number = 24): Promise<{ hourBucket: Date; news: TechNews[] }[]> {
    const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
    const allNews = await db
      .select()
      .from(techNews)
      .where(gte(techNews.hourBucket, cutoff))
      .orderBy(desc(techNews.hourBucket));
    
    const grouped = new Map<string, TechNews[]>();
    for (const item of allNews) {
      const key = item.hourBucket.toISOString();
      if (!grouped.has(key)) {
        grouped.set(key, []);
      }
      grouped.get(key)!.push(item);
    }
    
    return Array.from(grouped.entries()).map(([key, news]) => ({
      hourBucket: new Date(key),
      news,
    }));
  }

  async createTechNews(news: InsertTechNews): Promise<TechNews> {
    const [newItem] = await db.insert(techNews).values(news).returning();
    return newItem;
  }

  async createManyTechNews(newsItems: InsertTechNews[]): Promise<TechNews[]> {
    if (newsItems.length === 0) return [];
    const result = await db.insert(techNews).values(newsItems).returning();
    return result;
  }

  async getLatestTechNewsHour(): Promise<Date | null> {
    const [latest] = await db
      .select({ hourBucket: techNews.hourBucket })
      .from(techNews)
      .orderBy(desc(techNews.hourBucket))
      .limit(1);
    return latest?.hourBucket || null;
  }

  // Friends
  async getFriends(userId: number): Promise<{ id: number; name: string | null; email: string }[]> {
    const sentFriends = await db
      .select({ id: users.id, name: users.name, email: users.email })
      .from(friendships)
      .innerJoin(users, eq(users.id, friendships.friendId))
      .where(and(eq(friendships.userId, userId), eq(friendships.status, 'accepted')));
    
    const receivedFriends = await db
      .select({ id: users.id, name: users.name, email: users.email })
      .from(friendships)
      .innerJoin(users, eq(users.id, friendships.userId))
      .where(and(eq(friendships.friendId, userId), eq(friendships.status, 'accepted')));
    
    const allFriends = [...sentFriends, ...receivedFriends];
    const uniqueFriends = allFriends.filter((f, i, arr) => arr.findIndex(x => x.id === f.id) === i);
    return uniqueFriends;
  }

  async getPendingFriendRequests(userId: number): Promise<{ id: number; requesterId: number; requesterName: string | null; requesterEmail: string; createdAt: Date }[]> {
    const requests = await db
      .select({
        id: friendships.id,
        requesterId: friendships.userId,
        requesterName: users.name,
        requesterEmail: users.email,
        createdAt: friendships.createdAt,
      })
      .from(friendships)
      .innerJoin(users, eq(users.id, friendships.userId))
      .where(and(eq(friendships.friendId, userId), eq(friendships.status, 'pending')));
    return requests;
  }

  async searchUsers(query: string, currentUserId: number): Promise<{ id: number; name: string | null; email: string }[]> {
    const { ilike, or, ne } = await import("drizzle-orm");
    const results = await db
      .select({ id: users.id, name: users.name, email: users.email })
      .from(users)
      .where(and(
        ne(users.id, currentUserId),
        or(
          ilike(users.email, `%${query}%`),
          ilike(users.name, `%${query}%`)
        )
      ))
      .limit(10);
    return results;
  }

  async sendFriendRequest(userId: number, friendId: number): Promise<void> {
    const { or } = await import("drizzle-orm");
    const existing = await db
      .select()
      .from(friendships)
      .where(or(
        and(eq(friendships.userId, userId), eq(friendships.friendId, friendId)),
        and(eq(friendships.userId, friendId), eq(friendships.friendId, userId))
      ));
    
    if (existing.length > 0) {
      throw new Error('Friend request already exists');
    }
    
    await db.insert(friendships).values({
      userId,
      friendId,
      status: 'pending',
    });
  }

  async acceptFriendRequest(requestId: number, userId: number): Promise<void> {
    await db.update(friendships)
      .set({ status: 'accepted', updatedAt: new Date() })
      .where(and(eq(friendships.id, requestId), eq(friendships.friendId, userId)));
  }

  async declineFriendRequest(requestId: number, userId: number): Promise<void> {
    await db.update(friendships)
      .set({ status: 'declined', updatedAt: new Date() })
      .where(and(eq(friendships.id, requestId), eq(friendships.friendId, userId)));
  }
}

export const storage = new DatabaseStorage();
