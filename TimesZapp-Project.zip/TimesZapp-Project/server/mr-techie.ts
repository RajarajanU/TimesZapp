import { storage } from "./storage";
import { openai } from "./ai";
import type { InsertTechNews } from "@shared/schema";

const TECH_CATEGORIES = ['AI & Machine Learning', 'Mobile Tech', 'Web Development', 'Cybersecurity', 'Cloud Computing', 'Startups', 'Hardware', 'Software', 'Blockchain', 'Gaming'];

export async function fetchTechNews(customTopic?: string): Promise<{ success: boolean; count: number; news?: any[]; error?: string }> {
  try {
    const now = new Date();
    const hourBucket = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), 0, 0, 0);
    
    // Treat empty string as no topic
    const topic = customTopic?.trim() || undefined;
    
    // For non-custom topics, check cache first
    if (!topic) {
      const existingNews = await storage.getTechNewsByHour(hourBucket);
      if (existingNews.length >= 10) {
        console.log("[Mr Techie] Already have 10+ news for this hour, returning cached");
        const newsWithDetails = existingNews.map(n => ({
          ...n,
          details: n.summary,
          sourceUrl: n.url || `https://${n.source.toLowerCase().replace(/\s+/g, '')}.com`
        }));
        return { success: true, count: existingNews.length, news: newsWithDetails };
      }
    }

    const topicContext = topic 
      ? `Focus specifically on: ${topic}. Generate news related to this topic.` 
      : 'Focus on diverse topics: AI breakthroughs, new product launches, security vulnerabilities, startup funding, major tech company news, etc.';

    console.log("[Mr Techie] Fetching tech news for:", topic || 'general tech');

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are Mr Techie, a tech news curator. Generate exactly 10 unique, current technology news items.
          
For each news item, provide:
- A compelling headline (title)
- A 2-3 sentence summary explaining the news
- A detailed description (3-5 sentences with more context, implications, and expert opinions)
- The category (one of: ${TECH_CATEGORIES.join(', ')})
- A plausible source name (like TechCrunch, The Verge, Wired, Ars Technica, etc.)
- A source URL (realistic-looking URL from the source)

${topicContext}

Respond in valid JSON format as an array of objects with keys: title, summary, details, category, source, sourceUrl`
        },
        {
          role: "user",
          content: `Generate 10 ${topic ? `news items about "${topic}"` : 'current technology news headlines and summaries'} for ${now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} at ${now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}.`
        }
      ],
      temperature: 0.9,
      max_tokens: 3000,
    });

    const content = response.choices[0]?.message?.content || "[]";
    
    let newsData: Array<{ title: string; summary: string; details?: string; category: string; source: string; sourceUrl?: string }>;
    try {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      newsData = jsonMatch ? JSON.parse(jsonMatch[0]) : [];
    } catch (e) {
      console.error("[Mr Techie] Failed to parse AI response:", e);
      return { success: false, count: 0, error: "Failed to parse news data" };
    }

    // For custom topics, return directly without saving to DB
    if (topic) {
      const newsWithIds = newsData.slice(0, 10).map((item, index) => ({
        id: `custom-${Date.now()}-${index}`,
        title: item.title,
        summary: item.summary,
        details: item.details || item.summary,
        source: item.source,
        sourceUrl: item.sourceUrl || `https://${item.source.toLowerCase().replace(/\s+/g, '')}.com`,
        category: item.category,
        hourBucket,
        isCustom: true,
      }));
      return { success: true, count: newsWithIds.length, news: newsWithIds };
    }

    const newsItems: InsertTechNews[] = newsData.slice(0, 10).map(item => ({
      title: item.title,
      summary: item.summary,
      source: item.source,
      category: item.category,
      hourBucket,
      url: item.sourceUrl || null,
    }));

    if (newsItems.length > 0) {
      await storage.createManyTechNews(newsItems);
      console.log(`[Mr Techie] Saved ${newsItems.length} news items for hour:`, hourBucket.toISOString());
    }

    return { success: true, count: newsItems.length };
  } catch (error: any) {
    console.error("[Mr Techie] Error fetching news:", error.message);
    return { success: false, count: 0, error: error.message };
  }
}

export async function getRecentNews(hours: number = 24) {
  return await storage.getRecentTechNews(hours);
}

export async function ensureNewsForCurrentHour() {
  const now = new Date();
  const currentHourBucket = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), 0, 0, 0);
  
  const existingNews = await storage.getTechNewsByHour(currentHourBucket);
  if (existingNews.length < 10) {
    console.log("[Mr Techie] No news for current hour, fetching...");
    await fetchTechNews();
  }
}
