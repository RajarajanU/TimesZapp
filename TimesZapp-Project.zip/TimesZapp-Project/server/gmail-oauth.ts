// Gmail OAuth with full email reading permissions
// Uses user-provided Google OAuth credentials for gmail.readonly scope
import { google } from 'googleapis';
import { storage } from './storage';
import { generateOAuthState, validateOAuthState } from './oauth-state';

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/userinfo.email',
];

function getOAuth2Client() {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  
  if (!clientId || !clientSecret) {
    throw new Error('Google OAuth credentials not configured');
  }
  
  // Determine redirect URI based on environment
  const replitDomain = process.env.REPLIT_DEV_DOMAIN || process.env.REPLIT_DEPLOYMENT_DOMAIN;
  const redirectUri = replitDomain 
    ? `https://${replitDomain}/api/gmail-oauth/callback`
    : 'http://localhost:5000/api/gmail-oauth/callback';
  
  return new google.auth.OAuth2(clientId, clientSecret, redirectUri);
}

export function getGmailAuthUrl(userId: number): string {
  const oauth2Client = getOAuth2Client();
  
  // Generate secure CSRF-protected state token
  const state = generateOAuthState(userId, 'gmail-full');
  
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent',
    state: state,
  });
  
  return authUrl;
}

export async function handleGmailCallback(code: string, state: string): Promise<{ userId: number; email: string }> {
  // Validate OAuth state to prevent CSRF attacks
  const stateData = validateOAuthState(state);
  if (!stateData) {
    throw new Error('Invalid or expired OAuth state. Please try connecting again.');
  }
  
  if (stateData.platform !== 'gmail-full') {
    throw new Error('Invalid OAuth platform mismatch.');
  }
  
  const userId = stateData.userId;
  
  const oauth2Client = getOAuth2Client();
  
  // Exchange code for tokens
  const { tokens } = await oauth2Client.getToken(code);
  oauth2Client.setCredentials(tokens);
  
  // Get user info
  const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
  const userInfo = await oauth2.userinfo.get();
  const email = userInfo.data.email || '';
  
  // Check if service already exists
  const existing = await storage.getService(userId, 'gmail-full');
  
  if (existing) {
    // Update existing service tokens
    await storage.updateServiceTokens(
      existing.id,
      tokens.access_token || '',
      tokens.refresh_token || null,
      tokens.expiry_date ? new Date(tokens.expiry_date) : new Date(Date.now() + 3600000)
    );
  } else {
    // Create new service entry
    await storage.createService({
      userId,
      serviceName: 'gmail-full',
      accessToken: tokens.access_token || '',
      refreshToken: tokens.refresh_token || null,
      expiresAt: tokens.expiry_date ? new Date(tokens.expiry_date) : null,
      isActive: true,
    });
  }
  
  return { userId, email };
}

async function getAuthenticatedClient(userId: number) {
  const service = await storage.getService(userId, 'gmail-full');
  
  if (!service || !service.accessToken) {
    return null;
  }
  
  const oauth2Client = getOAuth2Client();
  
  oauth2Client.setCredentials({
    access_token: service.accessToken,
    refresh_token: service.refreshToken || undefined,
    expiry_date: service.expiresAt?.getTime(),
  });
  
  // Handle token refresh
  oauth2Client.on('tokens', async (tokens) => {
    if (tokens.access_token && service.id) {
      await storage.updateServiceTokens(
        service.id,
        tokens.access_token,
        tokens.refresh_token || service.refreshToken || null,
        tokens.expiry_date ? new Date(tokens.expiry_date) : new Date(Date.now() + 3600000)
      );
    }
  });
  
  return oauth2Client;
}

export interface GmailEmail {
  id: string;
  threadId: string;
  from: string;
  fromEmail: string;
  to: string;
  subject: string;
  snippet: string;
  date: string;
  timestamp: number;
  isUnread: boolean;
  labels: string[];
}

export async function isGmailFullConnected(userId: number): Promise<boolean> {
  const service = await storage.getService(userId, 'gmail-full');
  return !!(service && service.isActive);
}

export async function getGmailFullStatus(userId: number): Promise<{
  connected: boolean;
  email?: string;
  connectedAt?: Date;
}> {
  const service = await storage.getService(userId, 'gmail-full');
  
  if (!service || !service.isActive) {
    return { connected: false };
  }
  
  return {
    connected: true,
    connectedAt: service.connectedAt || undefined,
  };
}

export async function getRecentEmailsFull(userId: number, maxResults: number = 20): Promise<GmailEmail[]> {
  const auth = await getAuthenticatedClient(userId);
  
  if (!auth) {
    console.log('[Gmail Full] User not connected:', userId);
    return [];
  }
  
  try {
    const gmail = google.gmail({ version: 'v1', auth });
    
    // Get recent messages from inbox
    const response = await gmail.users.messages.list({
      userId: 'me',
      labelIds: ['INBOX'],
      maxResults: maxResults,
    });
    
    const messageIds = response.data.messages || [];
    if (messageIds.length === 0) {
      return [];
    }
    
    // Fetch details for each message
    const emails: GmailEmail[] = [];
    
    for (const msg of messageIds) {
      try {
        const fullMsg = await gmail.users.messages.get({
          userId: 'me',
          id: msg.id!,
          format: 'metadata',
          metadataHeaders: ['From', 'To', 'Subject', 'Date'],
        });
        
        const headers = fullMsg.data.payload?.headers || [];
        const fromHeader = headers.find(h => h.name?.toLowerCase() === 'from');
        const toHeader = headers.find(h => h.name?.toLowerCase() === 'to');
        const subjectHeader = headers.find(h => h.name?.toLowerCase() === 'subject');
        const dateHeader = headers.find(h => h.name?.toLowerCase() === 'date');
        
        // Parse from header
        const fromValue = fromHeader?.value || 'Unknown';
        const fromMatch = fromValue.match(/<([^>]+)>/);
        const fromEmail = fromMatch ? fromMatch[1] : fromValue;
        const fromName = fromValue.replace(/<[^>]+>/, '').trim().replace(/"/g, '') || fromEmail;
        
        const labelIds = fullMsg.data.labelIds || [];
        const dateStr = dateHeader?.value || '';
        const timestamp = dateStr ? new Date(dateStr).getTime() : Date.now();
        
        emails.push({
          id: msg.id!,
          threadId: fullMsg.data.threadId || msg.id!,
          from: fromName,
          fromEmail: fromEmail,
          to: toHeader?.value || '',
          subject: subjectHeader?.value || '(No Subject)',
          snippet: fullMsg.data.snippet || '',
          date: dateStr,
          timestamp: timestamp,
          isUnread: labelIds.includes('UNREAD'),
          labels: labelIds,
        });
      } catch (msgErr: any) {
        console.error(`[Gmail Full] Failed to fetch message ${msg.id}:`, msgErr.message);
      }
    }
    
    // Sort by timestamp descending (newest first)
    emails.sort((a, b) => b.timestamp - a.timestamp);
    
    return emails;
  } catch (error: any) {
    console.error('[Gmail Full] Failed to fetch emails:', error.message);
    return [];
  }
}

export async function getEmailStats(userId: number): Promise<{
  totalInbox: number;
  unread: number;
  todayCount: number;
}> {
  const auth = await getAuthenticatedClient(userId);
  
  if (!auth) {
    return { totalInbox: 0, unread: 0, todayCount: 0 };
  }
  
  try {
    const gmail = google.gmail({ version: 'v1', auth });
    
    // Get INBOX label stats
    const inboxLabel = await gmail.users.labels.get({
      userId: 'me',
      id: 'INBOX',
    });
    
    // Get today's emails count
    const today = new Date();
    const todayStr = `${today.getFullYear()}/${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}`;
    
    const todayResponse = await gmail.users.messages.list({
      userId: 'me',
      q: `after:${todayStr} in:inbox`,
      maxResults: 1,
    });
    
    return {
      totalInbox: inboxLabel.data.messagesTotal || 0,
      unread: inboxLabel.data.messagesUnread || 0,
      todayCount: (todayResponse.data as any).resultSizeEstimate || 0,
    };
  } catch (error: any) {
    console.error('[Gmail Full] Failed to get stats:', error.message);
    return { totalInbox: 0, unread: 0, todayCount: 0 };
  }
}

export async function disconnectGmailFull(userId: number): Promise<void> {
  const service = await storage.getService(userId, 'gmail-full');
  if (service) {
    // We can't delete, but we can mark inactive by updating tokens
    await storage.updateServiceTokens(service.id, '', null, new Date(0));
  }
}
