export interface VoiceCloneResult {
  success: boolean;
  voiceId?: string;
  voiceName?: string;
  error?: string;
}

export async function cloneVoiceFromBuffer(
  name: string,
  audioBuffer: Buffer,
  description?: string
): Promise<VoiceCloneResult> {
  if (!process.env.ELEVENLABS_API_KEY) {
    return { success: false, error: "ElevenLabs API key not configured" };
  }

  try {
    const formData = new FormData();
    formData.append("name", name);
    formData.append("description", description || `Voice clone for ${name}`);
    
    const audioBlob = new Blob([audioBuffer], { type: "audio/mpeg" });
    formData.append("files", audioBlob, "voice_sample.mp3");

    console.log(`[ElevenLabs] Calling voices/add API...`);
    
    const response = await fetch("https://api.elevenlabs.io/v1/voices/add", {
      method: "POST",
      headers: {
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[ElevenLabs] API error ${response.status}: ${errorText}`);
      
      let errorMessage = `API Error ${response.status}`;
      try {
        const errorData = JSON.parse(errorText);
        if (errorData.detail?.message) {
          errorMessage = errorData.detail.message;
        } else if (errorData.detail?.status === "invalid_api_key") {
          errorMessage = "Invalid API key. Please check your ElevenLabs API key.";
        } else if (errorData.detail) {
          errorMessage = typeof errorData.detail === 'string' ? errorData.detail : JSON.stringify(errorData.detail);
        } else if (errorData.message) {
          errorMessage = errorData.message;
        }
      } catch (e) {
        errorMessage = errorText || `HTTP ${response.status}`;
      }
      
      throw new Error(errorMessage);
    }

    const data = await response.json();
    console.log(`[ElevenLabs] Voice cloned successfully: ${data.voice_id}`);
    
    return {
      success: true,
      voiceId: data.voice_id,
      voiceName: name,
    };
  } catch (error: any) {
    console.error("[ElevenLabs] Voice cloning error:", error);
    return {
      success: false,
      error: error.message || "Failed to clone voice",
    };
  }
}

export async function deleteVoice(voiceId: string): Promise<boolean> {
  if (!process.env.ELEVENLABS_API_KEY) {
    return false;
  }

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/voices/${voiceId}`, {
      method: "DELETE",
      headers: {
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
    });

    if (response.ok) {
      console.log(`[ElevenLabs] Voice deleted: ${voiceId}`);
      return true;
    }
    return false;
  } catch (error: any) {
    console.error("[ElevenLabs] Voice deletion error:", error);
    return false;
  }
}

const DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"; // Rachel - natural female voice

export async function textToSpeech(
  text: string,
  voiceId?: string
): Promise<Buffer | null> {
  if (!process.env.ELEVENLABS_API_KEY) {
    return null;
  }

  const useVoiceId = voiceId || DEFAULT_VOICE_ID;
  console.log(`[ElevenLabs] Using voice ID: ${useVoiceId} (requested: ${voiceId || 'none'})`);

  try {
    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${useVoiceId}`,
      {
        method: "POST",
        headers: {
          "xi-api-key": process.env.ELEVENLABS_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text,
          model_id: "eleven_turbo_v2_5",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0.0,
            use_speaker_boost: true,
          },
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (error: any) {
    console.error("[ElevenLabs] Text-to-speech error:", error);
    return null;
  }
}

export async function listVoices(): Promise<any[]> {
  if (!process.env.ELEVENLABS_API_KEY) {
    return [];
  }

  try {
    const response = await fetch("https://api.elevenlabs.io/v1/voices", {
      headers: {
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    return data.voices || [];
  } catch (error: any) {
    console.error("[ElevenLabs] List voices error:", error);
    return [];
  }
}

export function isConfigured(): boolean {
  return !!process.env.ELEVENLABS_API_KEY;
}

export async function validateApiKey(): Promise<{ valid: boolean; error?: string; subscription?: any }> {
  if (!process.env.ELEVENLABS_API_KEY) {
    return { valid: false, error: "API key not configured" };
  }

  try {
    const response = await fetch("https://api.elevenlabs.io/v1/user/subscription", {
      headers: {
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[ElevenLabs] API key validation failed (${response.status}): ${errorText}`);
      
      if (response.status === 401) {
        return { valid: false, error: "Invalid API key" };
      }
      return { valid: false, error: `API error: ${response.status}` };
    }

    const subscription = await response.json();
    console.log(`[ElevenLabs] API key valid. Plan: ${subscription.tier || 'unknown'}`);
    
    return { 
      valid: true, 
      subscription: {
        tier: subscription.tier,
        character_count: subscription.character_count,
        character_limit: subscription.character_limit,
        can_clone: subscription.can_use_instant_voice_cloning || false,
      }
    };
  } catch (error: any) {
    console.error(`[ElevenLabs] API key validation error: ${error.message}`);
    return { valid: false, error: error.message };
  }
}
