import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, DEMO_USER_ID } from "@/lib/api";
import { Mail, MessageCircle, Share2, Users, Bell } from "lucide-react";
import { motion } from "framer-motion";

export default function SocialMedia() {
  const [selectedService, setSelectedService] = useState<string | null>(null);

  const { data: services } = useQuery({
    queryKey: ["services", DEMO_USER_ID],
    queryFn: () => api.getServices(DEMO_USER_ID),
  });

  const { data: notifications } = useQuery({
    queryKey: ["notifications", DEMO_USER_ID],
    queryFn: () => api.getNotifications(DEMO_USER_ID, 50),
  });

  const serviceIcons: Record<string, React.ReactNode> = {
    Gmail: <Mail className="w-5 h-5" />,
    LinkedIn: <Users className="w-5 h-5" />,
    Twitter: <MessageCircle className="w-5 h-5" />,
    Facebook: <Users className="w-5 h-5" />,
    Instagram: <MessageCircle className="w-5 h-5" />,
  };

  const serviceColors: Record<string, string> = {
    Gmail: "bg-red-50 border-red-200 hover:bg-red-100",
    LinkedIn: "bg-blue-50 border-blue-200 hover:bg-blue-100",
    Twitter: "bg-sky-50 border-sky-200 hover:bg-sky-100",
    Facebook: "bg-blue-100 border-blue-300 hover:bg-blue-200",
    Instagram: "bg-pink-50 border-pink-200 hover:bg-pink-100",
  };

  return (
    <div className="flex-1 flex flex-col gap-6 p-6 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Social Media Hub</h1>
        <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full">
          <Bell className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">{notifications?.length || 0} new</span>
        </div>
      </div>

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Sidebar - Services List */}
        <div className="w-64 bg-white rounded-lg border border-gray-200 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Connected Services</h2>
          </div>

          <div className="p-4 space-y-2">
            {services && services.length > 0 ? (
              services.map((service: any) => (
                <motion.button
                  key={service.id}
                  whileHover={{ x: 4 }}
                  onClick={() => setSelectedService(service.serviceName)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg border transition-all ${
                    selectedService === service.serviceName
                      ? "bg-blue-50 border-blue-300 text-blue-700"
                      : serviceColors[service.serviceName] || "bg-gray-50 border-gray-200"
                  }`}
                  data-testid={`service-button-${service.serviceName}`}
                >
                  {serviceIcons[service.serviceName] || <Users className="w-5 h-5" />}
                  <span className="font-medium text-sm">{service.serviceName}</span>
                </motion.button>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-8">No services connected</p>
            )}
          </div>
        </div>

        {/* Main Content - Messages/Notifications */}
        <div className="flex-1 bg-white rounded-lg border border-gray-200 overflow-hidden flex flex-col">
          <div className="border-b border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900">
              {selectedService ? `${selectedService} Messages` : "All Messages"}
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {notifications && notifications.length > 0 ? (
              notifications
                .filter((n: any) => !selectedService || n.source.toLowerCase().includes(selectedService.toLowerCase()))
                .map((notification: any) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                    data-testid={`notification-${notification.id}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-1"></div>
                        <h4 className="font-semibold text-gray-900">{notification.title}</h4>
                      </div>
                      <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded">
                        {notification.source}
                      </span>
                    </div>

                    <p className="text-sm text-gray-700 mb-3">{notification.description}</p>

                    <div className="flex gap-2">
                      <button className="flex items-center gap-2 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-xs font-medium transition-colors"
                        data-testid={`button-view-${notification.id}`}
                      >
                        <MessageCircle className="w-4 h-4" />
                        View
                      </button>
                      <button className="flex items-center gap-2 px-3 py-2 bg-green-50 hover:bg-green-100 text-green-600 rounded-lg text-xs font-medium transition-colors"
                        data-testid={`button-share-${notification.id}`}
                      >
                        <Share2 className="w-4 h-4" />
                        Share
                      </button>
                    </div>
                  </motion.div>
                ))
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <Bell className="w-12 h-12 mb-4 opacity-20" />
                <p>No messages</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar - Profile/Details */}
        <div className="w-72 bg-white rounded-lg border border-gray-200 overflow-y-auto p-4 space-y-4">
          <div className="text-center py-4 border-b border-gray-200">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mx-auto mb-3"></div>
            <h3 className="font-semibold text-gray-900">Demo User</h3>
            <p className="text-sm text-gray-500">demo@nexus.ai</p>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 text-sm">Account Stats</h4>
            <div className="space-y-2">
              <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-600">Connected Services</span>
                <span className="font-semibold text-gray-900">{services?.length || 0}</span>
              </div>
              <div className="flex justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-600">Unread Messages</span>
                <span className="font-semibold text-gray-900">
                  {notifications?.filter((n: any) => !n.isRead).length || 0}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
