import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Mic, MicOff, Menu, Plus, User, Settings, Bell, Shield, Wifi, Search, Mail, Globe, LogOut, MessageCircle, Facebook, Instagram, Linkedin, Phone, Trash2, LayoutDashboard, Home, RefreshCw, Clock, Heart, MessageSquare, Share2, MoreHorizontal, Paperclip, X, FileText, Image as ImageIcon, AudioLines, Volume2, TrendingUp, Sparkles, AlertCircle, CheckCircle2, Play, VolumeX, Camera, FlipHorizontal, Eye, EyeOff, Cpu, Newspaper, Zap, BellRing, Calendar, Square, Sun, Moon, Monitor } from "lucide-react";
import { MinutzClockAvatar } from "@/components/MinutzClockAvatar";
import { motion, AnimatePresence } from "framer-motion";
import { useSpeechSynthesis } from "@/hooks/use-speech-synthesis";
import { useAudioCapture } from "@/hooks/use-audio-capture";
import { usePushNotifications } from "@/hooks/use-push-notifications";
import { api, getCurrentUserId, getCurrentUserEmail } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "next-themes";

type View = "home" | "chat" | "dashboard" | "services" | "messages" | "insights" | "mr-techie";
type Mode = "assistant" | "research";
type MessageType = "text" | "job-action" | "notification-list" | "chart" | "media-gallery" | "time-data";

type Attachment = {
  name: string;
  url: string;
  mime: string;
  size: number;
  uploadedAt: string;
  preview?: string;
};

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  isThinking?: boolean;
  type?: MessageType;
  data?: any;
  timestamp: number;
  attachments?: Attachment[];
};

const SOCIAL_NETWORKS = [
  { id: "gmail", name: "Gmail", icon: Mail, color: "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" },
  { id: "facebook", name: "Facebook", icon: Facebook, color: "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400" },
  { id: "instagram", name: "Instagram", icon: Instagram, color: "bg-pink-100 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400" },
  { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "bg-sky-100 text-sky-600 dark:bg-sky-900/30 dark:text-sky-400" },
  { id: "whatsapp", name: "WhatsApp", icon: Phone, color: "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" },
  { id: "twitter", name: "X (Twitter)", icon: Globe, color: "bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-200" },
];

export default function Dashboard() {
  const [input, setInput] = useState("");
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [conversationId, setConversationId] = useState<number | undefined>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [cachedLocation, setCachedLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentView, setCurrentView] = useState<View>("chat");
  const [chatMode, setChatMode] = useState<Mode>("assistant");
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [filePreviews, setFilePreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isVoiceChatOpen, setIsVoiceChatOpen] = useState(false);
  const [voiceChatState, setVoiceChatState] = useState<"idle" | "listening" | "processing" | "speaking">("idle");
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [voiceResponse, setVoiceResponse] = useState("");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVoiceMuted, setIsVoiceMuted] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceRecordingTime, setVoiceRecordingTime] = useState(0);
  const [voiceCloneStatus, setVoiceCloneStatus] = useState<{ configured: boolean; apiKeyValid?: boolean; canClone?: boolean; validationError?: string; hasClonedVoice: boolean; voiceName: string | null; voiceId: string | null }>({ configured: false, hasClonedVoice: false, voiceName: null, voiceId: null });
  const [isVoiceCloning, setIsVoiceCloning] = useState(false);
  const [voiceCloneError, setVoiceCloneError] = useState<string | null>(null);
  const [voiceRecordingBlob, setVoiceRecordingBlob] = useState<Blob | null>(null);
  const [isVoiceCloneOpen, setIsVoiceCloneOpen] = useState(false);
  const [isVoiceSettingsOpen, setIsVoiceSettingsOpen] = useState(false);
  const [elevenLabsVoices, setElevenLabsVoices] = useState<Array<{ voice_id: string; name: string; category: string; labels: any; preview_url?: string }>>([]);
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>(() => {
    return localStorage.getItem('selectedVoiceId') || 'EXAVITQu4vr4xnSDxMaL';
  });
  const [isLoadingVoices, setIsLoadingVoices] = useState(false);
  const [playingPreview, setPlayingPreview] = useState<string | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('environment');
  const [isAutoScanning, setIsAutoScanning] = useState(true);
  const [lastVisionResult, setLastVisionResult] = useState<string>('');
  const [compactMode, setCompactMode] = useState(() => localStorage.getItem('compactMode') === 'true');
  const [emailNotifications, setEmailNotifications] = useState(() => localStorage.getItem('emailNotifications') !== 'false');
  const { theme, setTheme } = useTheme();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const visionIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isAnalyzingRef = useRef(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const voiceChunksRef = useRef<Blob[]>([]);
  const voiceRecordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const voiceChatOpenRef = useRef(false);
  const handleVoiceChatMessageRef = useRef<((message: string) => void) | null>(null);
  const isProcessingVoiceRef = useRef(false);
  
  const { 
    speak, 
    isSpeaking, 
    cancel, 
    voiceStyle, 
    setVoiceStyle, 
    voiceGender, 
    setVoiceGender, 
    autoSpeak, 
    setAutoSpeak,
    voiceMode,
    setVoiceMode,
    customVoiceName,
    customPitch,
    customRate,
    setCustomVoice,
    setCustomPitch,
    setCustomRate,
    testCustomVoice,
    testVoice,
    testGender,
    availableVoices,
    voiceStyleOptions, 
    isSupported: ttsSupported,
    hasClonedVoice,
    setHasClonedVoice
  } = useSpeechSynthesis();
  
  const {
    isRecording: isAudioRecording,
    isProcessing: isAudioProcessing,
    transcript: audioTranscript,
    startRecording: startAudioRecording,
    stopRecording: stopAudioRecording,
    stopListening,
    listenOnce,
    listenForStop,
    resetTranscript: resetAudioTranscript,
    isSupported: audioSupported,
  } = useAudioCapture({
    silenceTimeout: 1500,
  });

  const userId = getCurrentUserId() || 1;
  const userEmail = getCurrentUserEmail() || "user@timezapp.ai";

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userEmail");
    window.dispatchEvent(new Event("storage"));
    window.location.reload();
  };

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
          setCachedLocation(loc);
        },
        () => {
          console.log("[Dashboard] GPS unavailable");
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  }, []);

  const { data: conversations, refetch: refetchConversations } = useQuery({
    queryKey: ["conversations", userId],
    queryFn: () => api.getConversations(userId),
    refetchInterval: 60000,
  });

  const { data: notifications, refetch: refetchNotifications } = useQuery({
    queryKey: ["notifications", userId],
    queryFn: () => api.getNotifications(userId, 50),
    refetchInterval: 30000,
  });

  const { data: services, refetch: refetchServices } = useQuery({
    queryKey: ["services", userId],
    queryFn: () => api.getServices(userId),
  });

  const { data: gmailStats, refetch: refetchGmailStats } = useQuery({
    queryKey: ["gmailStats"],
    queryFn: () => api.getGmailStats(),
    refetchInterval: 60000,
    retry: false,
  });

  const { data: gmailLabels } = useQuery({
    queryKey: ["gmailLabels"],
    queryFn: () => api.getGmailLabels(),
    refetchInterval: 120000,
    retry: false,
  });

  const { data: gmailStatus } = useQuery({
    queryKey: ["gmailStatus"],
    queryFn: () => api.getGmailStatus(),
    refetchInterval: 60000,
    retry: false,
  });

  // Gmail Full OAuth - for reading actual emails
  const { data: gmailOAuthStatus, refetch: refetchGmailOAuthStatus } = useQuery({
    queryKey: ["gmailOAuthStatus"],
    queryFn: () => api.getGmailOAuthStatus(),
    refetchInterval: 60000,
    retry: false,
  });

  const { data: gmailEmails, refetch: refetchGmailEmails } = useQuery({
    queryKey: ["gmailEmails"],
    queryFn: () => api.getGmailEmails(20),
    refetchInterval: 60000,
    retry: false,
    enabled: !!gmailOAuthStatus?.connected,
  });

  const [isConnectingGmail, setIsConnectingGmail] = useState(false);

  const handleConnectGmailFull = async () => {
    setIsConnectingGmail(true);
    try {
      const { authUrl } = await api.getGmailOAuthUrl();
      window.location.href = authUrl;
    } catch (error: any) {
      console.error('Failed to start Gmail OAuth:', error);
      setIsConnectingGmail(false);
    }
  };

  const { data: reminders, refetch: refetchReminders } = useQuery({
    queryKey: ["reminders", userId],
    queryFn: () => api.getReminders(userId),
    refetchInterval: 60000,
  });

  const { data: dueReminders, refetch: refetchDueReminders } = useQuery({
    queryKey: ["dueReminders", userId],
    queryFn: () => api.getDueReminders(userId),
    refetchInterval: 30000,
  });

  const [activeReminderAlert, setActiveReminderAlert] = useState<any | null>(null);

  useEffect(() => {
    if (dueReminders && dueReminders.length > 0 && !activeReminderAlert) {
      const nextReminder = dueReminders[0];
      setActiveReminderAlert(nextReminder);
    }
  }, [dueReminders, activeReminderAlert]);

  const handleDismissReminder = async (reminderId: number, complete: boolean = false) => {
    try {
      if (complete) {
        await api.completeReminder(reminderId);
      } else {
        await api.markReminderNotified(reminderId);
      }
      setActiveReminderAlert(null);
      refetchDueReminders();
      refetchReminders();
    } catch (error) {
      console.error("Failed to dismiss reminder:", error);
    }
  };

  const { data: trends, isLoading: trendsLoading, refetch: refetchTrends } = useQuery({
    queryKey: ["trends", userId],
    queryFn: () => api.getTrends(userId),
    refetchInterval: 300000,
    retry: false,
    enabled: currentView === "insights",
  });

  const { data: techNews, isLoading: techNewsLoading, refetch: refetchTechNews } = useQuery({
    queryKey: ["tech-news"],
    queryFn: () => api.getCurrentTechNews(),
    refetchInterval: 3600000,
    retry: 1,
    enabled: currentView === "mr-techie",
  });

  const { data: friends, refetch: refetchFriends } = useQuery({
    queryKey: ["friends"],
    queryFn: () => api.getFriends(),
    retry: 1,
    enabled: currentView === "dashboard",
  });

  const { data: friendRequests, refetch: refetchFriendRequests } = useQuery({
    queryKey: ["friendRequests"],
    queryFn: () => api.getFriendRequests(),
    retry: 1,
    enabled: currentView === "dashboard",
  });

  const [friendSearchQuery, setFriendSearchQuery] = useState('');
  const [friendSearchResults, setFriendSearchResults] = useState<any[]>([]);
  const [isSearchingFriends, setIsSearchingFriends] = useState(false);

  const handleFriendSearch = async (query: string) => {
    setFriendSearchQuery(query);
    if (query.length < 2) {
      setFriendSearchResults([]);
      return;
    }
    setIsSearchingFriends(true);
    try {
      const results = await api.searchUsers(query);
      setFriendSearchResults(results);
    } catch (error) {
      console.error('Friend search failed:', error);
    } finally {
      setIsSearchingFriends(false);
    }
  };

  const handleSendFriendRequest = async (friendId: number) => {
    try {
      await api.sendFriendRequest(friendId);
      setFriendSearchResults(prev => prev.filter(u => u.id !== friendId));
    } catch (error: any) {
      console.error('Failed to send friend request:', error);
    }
  };

  const handleAcceptFriendRequest = async (requestId: number) => {
    try {
      await api.acceptFriendRequest(requestId);
      refetchFriendRequests();
      refetchFriends();
    } catch (error) {
      console.error('Failed to accept friend request:', error);
    }
  };

  const handleDeclineFriendRequest = async (requestId: number) => {
    try {
      await api.declineFriendRequest(requestId);
      refetchFriendRequests();
    } catch (error) {
      console.error('Failed to decline friend request:', error);
    }
  };

  const { isSupported: notificationsSupported, permission: notificationPermission, requestPermission, sendNotification } = usePushNotifications();
  const [techNewsNotificationsEnabled, setTechNewsNotificationsEnabled] = useState(false);
  const lastNotificationHourRef = useRef<number | null>(null);
  const [techNewsSearchTopic, setTechNewsSearchTopic] = useState('');
  const [isSearchingTechNews, setIsSearchingTechNews] = useState(false);
  const [customTechNews, setCustomTechNews] = useState<any[] | null>(null);
  const [expandedNewsId, setExpandedNewsId] = useState<string | number | null>(null);

  useEffect(() => {
    if (!techNewsNotificationsEnabled || notificationPermission !== 'granted') return;

    const checkAndNotify = async () => {
      const currentHour = new Date().getHours();
      
      if (lastNotificationHourRef.current === currentHour) return;
      
      try {
        const newsData = await api.getCurrentTechNews();
        if (newsData?.news && newsData.news.length > 0) {
          const topNews = newsData.news.slice(0, 3);
          const body = topNews.map((n: any, i: number) => `${i + 1}. ${n.title}`).join('\n');
          
          sendNotification('Mr Techie - Tech News Update', {
            body: body,
            tag: 'tech-news-hourly',
            requireInteraction: false,
          });
          
          lastNotificationHourRef.current = currentHour;
        }
      } catch (error) {
        console.error('Failed to fetch tech news for notification:', error);
      }
    };

    checkAndNotify();
    
    const interval = setInterval(checkAndNotify, 60000);
    
    return () => clearInterval(interval);
  }, [techNewsNotificationsEnabled, notificationPermission, sendNotification]);

  // Load ElevenLabs voices when voice settings open
  useEffect(() => {
    if (isVoiceSettingsOpen && elevenLabsVoices.length === 0) {
      setIsLoadingVoices(true);
      api.getVoiceList()
        .then((data) => {
          setElevenLabsVoices(data.voices || []);
        })
        .catch((err) => {
          console.error('Failed to load voices:', err);
        })
        .finally(() => {
          setIsLoadingVoices(false);
        });
    }
  }, [isVoiceSettingsOpen, elevenLabsVoices.length]);

  const handleSelectVoice = (voiceId: string) => {
    setSelectedVoiceId(voiceId);
    localStorage.setItem('selectedVoiceId', voiceId);
  };

  const handlePlayPreview = (voiceId: string, previewUrl?: string) => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
    }
    
    if (playingPreview === voiceId) {
      setPlayingPreview(null);
      return;
    }
    
    if (previewUrl) {
      const audio = new Audio(previewUrl);
      previewAudioRef.current = audio;
      audio.onended = () => setPlayingPreview(null);
      audio.onerror = () => setPlayingPreview(null);
      audio.play();
      setPlayingPreview(voiceId);
    }
  };

  const handleEnableTechNewsNotifications = async () => {
    if (notificationPermission !== 'granted') {
      const granted = await requestPermission();
      if (!granted) {
        alert('Please allow notifications to receive tech news updates');
        return;
      }
    }
    setTechNewsNotificationsEnabled(true);
    sendNotification('Mr Techie Notifications Enabled', {
      body: 'You will now receive hourly tech news updates!',
    });
  };

  const handleSearchTechNews = async () => {
    const topic = techNewsSearchTopic.trim();
    if (!topic) {
      setCustomTechNews(null);
      return;
    }
    setIsSearchingTechNews(true);
    try {
      const result = await api.fetchNewTechNews(topic);
      if (result.news && result.news.length > 0) {
        setCustomTechNews(result.news);
      } else {
        setCustomTechNews([]);
      }
    } catch (error) {
      console.error('Failed to search tech news:', error);
      setCustomTechNews([]);
    } finally {
      setIsSearchingTechNews(false);
    }
  };

  const handleClearTechNewsSearch = () => {
    setTechNewsSearchTopic('');
    setCustomTechNews(null);
  };

  const handleRefreshGmail = () => {
    refetchGmailStats();
  };

  const handleLoadConversation = async (convId: number) => {
    try {
      const conversationMessages = await api.getMessages(convId);
      setConversationId(convId);
      setMessages(conversationMessages.map((msg: any) => ({
        id: msg.id.toString(),
        role: msg.role,
        content: msg.content,
        timestamp: new Date(msg.timestamp).getTime(),
        type: msg.metadata?.type,
        data: msg.metadata?.data,
      })));
      setCurrentView("chat");
    } catch (error) {
      console.error("Failed to load conversation:", error);
    }
  };

  const handleConnectService = async (networkId: string) => {
    try {
      // For OAuth-based networks, redirect to auth flow
      if (networkId === "linkedin") {
        const { authUrl } = await api.getLinkedInAuthUrl();
        window.location.href = authUrl;
        return;
      }
      if (networkId === "facebook") {
        const { authUrl } = await api.getFacebookAuthUrl();
        window.location.href = authUrl;
        return;
      }
      if (networkId === "instagram") {
        const { authUrl } = await api.getInstagramAuthUrl();
        window.location.href = authUrl;
        return;
      }
      // For other networks (gmail uses Replit integration, others are placeholders)
      await api.addService(userId, networkId);
      refetchServices?.();
    } catch (error: any) {
      console.error("Failed to connect service:", error);
      alert(error.message || "Failed to connect. The API may not be configured.");
    }
  };

  const handleDisconnectService = async (serviceId: number) => {
    try {
      await api.deleteService(serviceId);
      refetchServices?.();
    } catch (error) {
      console.error("Failed to disconnect service:", error);
    }
  };

  const isServiceConnected = (networkId: string) => {
    return services?.some((s: any) => s.serviceName.toLowerCase() === networkId.toLowerCase());
  };

  const getServiceByNetworkId = (networkId: string) => {
    return services?.find((s: any) => s.serviceName.toLowerCase() === networkId.toLowerCase());
  };

  useEffect(() => {
    if (audioTranscript && !isVoiceChatOpen) {
      setInput(audioTranscript);
    }
  }, [audioTranscript, isVoiceChatOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    api.getVoiceStatus().then(status => {
      setVoiceCloneStatus(status);
      if (status.hasClonedVoice) {
        setHasClonedVoice(true);
      }
    });
  }, []);

  useEffect(() => {
    if (isSettingsOpen || isVoiceCloneOpen) {
      api.getVoiceStatus().then(setVoiceCloneStatus);
    }
  }, [isSettingsOpen, isVoiceCloneOpen]);

  useEffect(() => {
    return () => {
      if (voiceRecordingTimerRef.current) {
        clearInterval(voiceRecordingTimerRef.current);
      }
    };
  }, []);

  // Camera vision handling
  useEffect(() => {
    if (isCameraActive) {
      startCamera(cameraFacing);
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isCameraActive, cameraFacing]);

  // Continuous vision scanning
  useEffect(() => {
    if (isCameraActive && isAutoScanning && !isVoiceMuted) {
      visionIntervalRef.current = setInterval(() => {
        if (!isAnalyzingRef.current && voiceChatState === 'listening') {
          performAutoScan();
        }
      }, 5000); // Scan every 5 seconds
    }
    return () => {
      if (visionIntervalRef.current) {
        clearInterval(visionIntervalRef.current);
        visionIntervalRef.current = null;
      }
    };
  }, [isCameraActive, isAutoScanning, isVoiceMuted, voiceChatState]);

  const startCamera = async (facing: 'user' | 'environment') => {
    try {
      // Stop existing stream first
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (error) {
      console.error('[Camera] Failed to start:', error);
      // Try fallback to any camera if facing mode fails
      try {
        const fallbackStream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: { ideal: 1280 }, height: { ideal: 720 } } 
        });
        setCameraStream(fallbackStream);
        if (videoRef.current) {
          videoRef.current.srcObject = fallbackStream;
          await videoRef.current.play();
        }
      } catch (fallbackError) {
        console.error('[Camera] Fallback failed:', fallbackError);
        setIsCameraActive(false);
      }
    }
  };

  const switchCamera = () => {
    const newFacing = cameraFacing === 'user' ? 'environment' : 'user';
    setCameraFacing(newFacing);
  };

  const stopCamera = () => {
    if (visionIntervalRef.current) {
      clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const performAutoScan = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    if (isAnalyzingRef.current) return;
    
    const video = videoRef.current;
    if (video.readyState < 2 || video.videoWidth === 0) return;
    
    isAnalyzingRef.current = true;
    
    try {
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      ctx.drawImage(video, 0, 0);
      const imageData = canvas.toDataURL('image/jpeg', 0.6);
      
      const response = await api.analyzeImage(imageData, true);
      
      if (!response || response === lastVisionResult) return;
      
      const lowerResponse = response.toLowerCase();
      if (lowerResponse.includes('nothing notable') || 
          lowerResponse.includes('cannot see') ||
          lowerResponse.includes("couldn't analyze")) {
        return;
      }
      
      setLastVisionResult(response);
      
      const hasInterestingContent = 
        lowerResponse.includes('person') || 
        lowerResponse.includes('people') ||
        lowerResponse.includes('face') ||
        lowerResponse.includes('object') ||
        lowerResponse.includes('landmark') ||
        lowerResponse.includes('building') ||
        lowerResponse.includes('text') ||
        lowerResponse.includes('sign') ||
        lowerResponse.includes('product') ||
        lowerResponse.includes('animal');
      
      if (hasInterestingContent) {
        setVoiceResponse(response);
        speak(response, { 
          force: true, 
          onStart: () => setVoiceChatState("speaking"),
          onEnd: () => {
            startVoiceChatListening();
          }
        });
      }
    } catch (error) {
      console.error('[Vision] Auto-scan failed:', error);
    } finally {
      isAnalyzingRef.current = false;
    }
  };

  const [isCapturing, setIsCapturing] = useState(false);
  
  const captureAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current || isCapturing) return;
    
    const video = videoRef.current;
    
    if (video.readyState < 2 || video.videoWidth === 0) {
      console.warn('[Vision] Video not ready yet');
      return;
    }
    
    setIsCapturing(true);
    
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      setIsCapturing(false);
      return;
    }
    
    ctx.drawImage(video, 0, 0);
    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    
    setVoiceChatState("processing");
    try {
      const response = await api.analyzeImage(imageData);
      setVoiceResponse(response);
      speak(response, { 
        force: true, 
        onStart: () => setVoiceChatState("speaking"),
        onEnd: () => {
          startVoiceChatListening();
        }
      });
    } catch (error) {
      console.error('[Vision] Analysis failed:', error);
      const errorMsg = "I wasn't able to analyze that image. Please try again.";
      setVoiceResponse(errorMsg);
      speak(errorMsg, { 
        force: true, 
        onStart: () => setVoiceChatState("speaking"),
        onEnd: () => {
          setVoiceChatState("listening");
        }
      });
    } finally {
      setIsCapturing(false);
    }
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      voiceChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          voiceChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(voiceChunksRef.current, { type: 'audio/webm' });
        setVoiceRecordingBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecordingVoice(true);
      setVoiceRecordingTime(0);
      setVoiceCloneError(null);
      
      voiceRecordingTimerRef.current = setInterval(() => {
        setVoiceRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error: any) {
      setVoiceCloneError("Could not access microphone. Please allow microphone permission.");
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && isRecordingVoice) {
      mediaRecorderRef.current.stop();
      setIsRecordingVoice(false);
      if (voiceRecordingTimerRef.current) {
        clearInterval(voiceRecordingTimerRef.current);
      }
    }
  };

  const submitVoiceClone = async () => {
    if (!voiceRecordingBlob) return;
    
    setIsVoiceCloning(true);
    setVoiceCloneError(null);
    
    try {
      const result = await api.cloneVoice(voiceRecordingBlob, "My Voice");
      setVoiceCloneStatus({
        configured: true,
        hasClonedVoice: true,
        voiceName: result.voiceName,
        voiceId: result.voiceId,
      });
      setHasClonedVoice(true);
      setVoiceMode('cloned');
      setVoiceRecordingBlob(null);
      setVoiceRecordingTime(0);
    } catch (error: any) {
      setVoiceCloneError(error.message || "Failed to clone voice");
    } finally {
      setIsVoiceCloning(false);
    }
  };

  const deleteVoiceClone = async () => {
    try {
      await api.deleteClonedVoice();
      setVoiceCloneStatus({
        ...voiceCloneStatus,
        hasClonedVoice: false,
        voiceName: null,
        voiceId: null,
      });
      setHasClonedVoice(false);
      setVoiceMode('default');
    } catch (error: any) {
      setVoiceCloneError(error.message || "Failed to delete voice");
    }
  };

  const cancelVoiceRecording = () => {
    setVoiceRecordingBlob(null);
    setVoiceRecordingTime(0);
    if (isRecordingVoice) {
      stopVoiceRecording();
    }
  };

  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const validFiles = files.filter(file => {
      const allowedTypes = [
        "image/jpeg", "image/png", "image/gif", "image/webp",
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "text/plain"
      ];
      return allowedTypes.includes(file.type) && file.size <= 10 * 1024 * 1024;
    });

    if (validFiles.length !== files.length) {
      alert("Some files were skipped. Only images, PDFs, and documents under 10MB are allowed.");
    }

    setSelectedFiles(prev => [...prev, ...validFiles].slice(0, 5));
    
    validFiles.forEach(file => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreviews(prev => [...prev, e.target?.result as string]);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreviews(prev => [...prev, ""]);
      }
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setFilePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const uploadFiles = async (): Promise<Attachment[]> => {
    if (selectedFiles.length === 0) return [];
    
    setIsUploading(true);
    try {
      const formData = new FormData();
      selectedFiles.forEach(file => {
        formData.append("files", file);
      });

      const token = localStorage.getItem("token");
      const response = await fetch("/api/upload", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const data = await response.json();
      return data.attachments;
    } catch (error) {
      console.error("Upload error:", error);
      return [];
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  // Voice chat listening loop
  const startVoiceChatListening = useCallback(async () => {
    if (!voiceChatOpenRef.current || isVoiceMuted) return;
    
    setVoiceChatState("listening");
    
    try {
      const result = await listenOnce();
      
      if (!voiceChatOpenRef.current) return; // Closed during listening
      
      if (result.transcript) {
        if (result.isStopCommand) {
          console.log('[VoiceChat] Stop command detected, ignoring');
          // Just restart listening
          startVoiceChatListening();
        } else {
          // Process the message
          handleVoiceChatMessageRef.current?.(result.transcript);
        }
      } else {
        // No transcript, restart listening
        startVoiceChatListening();
      }
    } catch (e) {
      console.error('[VoiceChat] Listen error:', e);
      // Restart listening on error
      if (voiceChatOpenRef.current && !isVoiceMuted) {
        setTimeout(() => startVoiceChatListening(), 500);
      }
    }
  }, [listenOnce, isVoiceMuted]);

  const startVoiceChat = () => {
    resetAudioTranscript();
    setIsVoiceChatOpen(true);
    voiceChatOpenRef.current = true;
    setVoiceTranscript("");
    setVoiceResponse("");
    setIsVoiceMuted(false);
    setVoiceChatState("listening");
    setTimeout(() => startVoiceChatListening(), 100);
  };

  const closeVoiceChat = () => {
    setIsVoiceChatOpen(false);
    voiceChatOpenRef.current = false;
    isProcessingVoiceRef.current = false;
    setVoiceChatState("idle");
    setVoiceTranscript("");
    setVoiceResponse("");
    stopAudioRecording();
    cancel();
    resetAudioTranscript();
  };

  // Reference to stop listener promise resolve function for cancellation
  const stopListenerResolveRef = useRef<(() => void) | null>(null);
  
  const handleVoiceChatMessage = useCallback(async (message: string) => {
    if (!message.trim()) return;
    
    if (isProcessingVoiceRef.current) {
      console.log('[VoiceChat] Already processing, ignoring new message');
      return;
    }
    
    isProcessingVoiceRef.current = true;
    cancel();
    stopListening(); // Stop any existing listening
    
    setVoiceChatState("processing");
    setVoiceTranscript(message);
    resetAudioTranscript();
    setInput('');
    
    const startTime = Date.now();
    
    // Save user message immediately
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: message,
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMessage]);
    
    try {
      // Use non-streaming for reliability - wait for full response then speak
      const response = await api.fastVoiceChat(message);
      
      console.log(`[VoiceChat] AI response in ${Date.now() - startTime}ms`);
      
      const aiResponse = response.content;
      setVoiceResponse(aiResponse);
      
      // Start listening for stop commands while speaking
      let stopDetected = false;
      const stopPromise = listenForStop().then(stopped => {
        if (stopped) {
          console.log('[VoiceChat] Stop command detected - canceling speech');
          stopDetected = true;
          cancel();
        }
        return stopped;
      });
      
      // Speak the response
      await new Promise<void>((resolve) => {
        speak(aiResponse, {
          force: true,
          onStart: () => {
            setVoiceChatState("speaking");
          },
          onEnd: () => {
            resolve();
          }
        });
      });
      
      // Stop the stop listener since speech ended
      stopListening();
      
      // Save AI message
      const aiMessage: Message = {
        id: Date.now().toString() + '-ai',
        role: "assistant",
        content: aiResponse,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, aiMessage]);
      
      // Reset state and start listening again
      isProcessingVoiceRef.current = false;
      if (!isVoiceMuted && voiceChatOpenRef.current) {
        setVoiceTranscript("");
        // Start listening for next input
        startVoiceChatListening();
      } else {
        setVoiceChatState("idle");
        setVoiceTranscript("");
      }
      
    } catch (error: any) {
      console.error("Voice chat error:", error?.message || error);
      isProcessingVoiceRef.current = false;
      resetAudioTranscript();
      stopListening();
      
      if (error?.message?.includes('timeout') || error?.name === 'AbortError') {
        setVoiceResponse("Sorry, that took too long. Please try again.");
        await new Promise<void>((resolve) => {
          speak("Sorry, that took too long. Please try again.", {
            force: true,
            onEnd: resolve
          });
        });
      }
      
      if (!isVoiceMuted && voiceChatOpenRef.current) {
        setVoiceTranscript("");
        startVoiceChatListening();
      } else {
        setVoiceChatState("idle");
        setVoiceTranscript("");
      }
    }
  }, [resetAudioTranscript, speak, isVoiceMuted, cancel, stopListening, listenForStop, startVoiceChatListening]);

  useEffect(() => {
    handleVoiceChatMessageRef.current = handleVoiceChatMessage;
  }, [handleVoiceChatMessage]);

  // Watchdog for stuck states - simplified
  useEffect(() => {
    if (voiceChatState === "processing" || voiceChatState === "speaking") {
      const watchdogTimeout = setTimeout(() => {
        console.warn('[VoiceChat] Watchdog: stuck state detected, recovering');
        isProcessingVoiceRef.current = false;
        cancel();
        stopListening();
        resetAudioTranscript();
        if (voiceChatOpenRef.current && !isVoiceMuted) {
          setVoiceTranscript("");
          startVoiceChatListening();
        } else {
          setVoiceChatState("idle");
          setVoiceTranscript("");
        }
      }, 30000);
      
      return () => clearTimeout(watchdogTimeout);
    }
  }, [voiceChatState, isVoiceMuted, cancel, resetAudioTranscript, stopListening, startVoiceChatListening]);

  const handleSend = async (overrideMessage?: string) => {
    const messageContent = overrideMessage || input.trim();
    if ((!messageContent && selectedFiles.length === 0) || isLoading) return;

    const attachments = await uploadFiles();
    
    setInput("");
    setSelectedFiles([]);
    setFilePreviews([]);
    setIsLoading(true);

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageContent || (attachments.length > 0 ? `Shared ${attachments.length} file(s)` : ""),
      timestamp: Date.now(),
      attachments: attachments.length > 0 ? attachments : undefined,
    };

    setMessages(prev => [...prev, userMessage, {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: "",
      isThinking: true,
      timestamp: Date.now() + 1,
    }]);

    try {
      let batteryInfo: { level: number; charging: boolean } | null = null;
      if ('getBattery' in navigator) {
        try {
          const battery = await (navigator as any).getBattery();
          batteryInfo = { level: Math.round(battery.level * 100), charging: battery.charging };
        } catch (e) {}
      }
      
      let locationInfo = cachedLocation;
      
      if (!locationInfo && 'geolocation' in navigator) {
        try {
          locationInfo = await new Promise<{ latitude: number; longitude: number } | null>((resolve) => {
            const timeoutId = setTimeout(() => resolve(null), 5000);
            
            navigator.geolocation.getCurrentPosition(
              (pos) => {
                clearTimeout(timeoutId);
                const loc = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
                setCachedLocation(loc);
                resolve(loc);
              },
              () => {
                clearTimeout(timeoutId);
                resolve(null);
              },
              { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
            );
          });
        } catch (e) {
          locationInfo = null;
        }
      }
      
      const response = await api.sendMessage({
        userId: userId,
        conversationId,
        message: messageContent,
        attachments: attachments.length > 0 ? attachments : undefined,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        deviceTime: new Date().toISOString(),
        battery: batteryInfo,
        location: locationInfo,
      });

      setConversationId(response.conversationId);
      setMessages(prev => prev.filter(m => !m.isThinking));
      
      const aiMessage: Message = {
        id: response.message.id.toString(),
        role: "assistant",
        content: response.message.content,
        timestamp: new Date(response.message.timestamp).getTime(),
        type: response.message.metadata?.type,
        data: response.message.metadata?.data,
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error: any) {
      console.error("[Dashboard] Failed to send message:", error);
      const errorMsg = error?.message || "Network error";
      setMessages(prev => prev.filter(m => !m.isThinking));
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: "assistant",
        content: `Error: ${errorMsg}. Please make sure you're connected to the internet.`,
        timestamp: Date.now(),
      }]);
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div className="flex h-dvh overflow-hidden bg-background text-foreground font-sans" style={{ height: '100dvh', minHeight: '-webkit-fill-available' }}>
      
      {/* Reminder Alert */}
      <AnimatePresence>
        {activeReminderAlert && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            className="fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] w-[90%] max-w-md"
            data-testid="reminder-alert"
          >
            <div className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-xl shadow-2xl p-4 text-white">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-white/20 rounded-lg">
                  <Bell className="w-6 h-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-lg truncate" data-testid="reminder-title">
                    {activeReminderAlert.title}
                  </h3>
                  {activeReminderAlert.description && (
                    <p className="text-white/90 text-sm mt-1 line-clamp-2" data-testid="reminder-description">
                      {activeReminderAlert.description}
                    </p>
                  )}
                  <p className="text-white/70 text-xs mt-2">
                    Scheduled for {new Date(activeReminderAlert.remindAt).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => handleDismissReminder(activeReminderAlert.id, true)}
                  className="flex-1 px-4 py-2 bg-white text-orange-600 rounded-lg font-medium hover:bg-white/90 transition-colors"
                  data-testid="reminder-complete-button"
                >
                  <CheckCircle2 className="w-4 h-4 inline mr-1" />
                  Done
                </button>
                <button
                  onClick={() => handleDismissReminder(activeReminderAlert.id, false)}
                  className="flex-1 px-4 py-2 bg-white/20 text-white rounded-lg font-medium hover:bg-white/30 transition-colors"
                  data-testid="reminder-dismiss-button"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar Overlay */}
      <AnimatePresence mode="wait">
        {isSidebarOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 bg-black/50 z-40"
            />
            {/* Sidebar */}
            <motion.aside 
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 w-[280px] bg-zinc-50 dark:bg-zinc-900 flex flex-col border-r border-border z-50 shadow-xl"
            >
            {/* New Chat Button */}
            <div className="p-3">
              <button 
                onClick={() => {
                  setMessages([]);
                  setConversationId(undefined);
                  setCurrentView("chat");
                  cancel();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-all shadow-sm text-sm font-medium"
                data-testid="button-new-chat"
              >
                <Plus className="w-4 h-4" />
                New Chat
              </button>
            </div>

            {/* Navigation Items */}
            <div className="flex-1 overflow-y-auto px-2 space-y-1">
              <div className="text-xs font-medium text-muted-foreground px-3 py-2 uppercase tracking-wider">Menu</div>
              
              <button
                onClick={() => setCurrentView("home")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "home"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-home"
              >
                <Home className="w-4 h-4" />
                <span className="flex-1 text-left">Home Feed</span>
                {notifications && notifications.length > 0 && (
                  <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">
                    {notifications.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setCurrentView("dashboard")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "dashboard"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-dashboard"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="flex-1 text-left">My Profile</span>
              </button>

              <button
                onClick={() => setCurrentView("chat")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "chat" && !conversationId
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-chat"
              >
                <Shield className="w-4 h-4" />
                <span className="flex-1 text-left">Minutz AI</span>
              </button>

              <button
                onClick={() => setCurrentView("messages")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "messages"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-messages"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="flex-1 text-left">Messages</span>
              </button>

              <button
                onClick={() => { setCurrentView("services"); setSelectedNetwork(null); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "services"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-services"
              >
                <Wifi className="w-4 h-4" />
                <span className="flex-1 text-left">Networks</span>
              </button>

              <button
                onClick={() => setCurrentView("mr-techie")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "mr-techie"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-mr-techie"
              >
                <Cpu className="w-4 h-4" />
                <span className="flex-1 text-left">Mr Techie</span>
              </button>

              <button
                onClick={() => setCurrentView("insights")}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm ${
                  currentView === "insights"
                    ? "bg-accent text-foreground"
                    : "hover:bg-accent text-foreground/70"
                }`}
                data-testid="nav-insights"
              >
                <TrendingUp className="w-4 h-4" />
                <span className="flex-1 text-left">Insights</span>
              </button>

              {/* Chat History */}
              {conversations && conversations.length > 0 && (
                <>
                  <div className="border-t border-border my-2"></div>
                  <div className="text-xs font-medium text-muted-foreground px-3 py-2 uppercase tracking-wider">Chat History</div>
                  <div className="space-y-1">
                    {conversations.map((conv: any) => (
                      <button
                        key={conv.id}
                        onClick={() => handleLoadConversation(conv.id)}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors line-clamp-2 ${
                          conversationId === conv.id
                            ? "bg-accent text-foreground"
                            : "hover:bg-accent text-foreground/70"
                        }`}
                        data-testid={`conversation-${conv.id}`}
                        title={conv.title}
                      >
                        {conv.title}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* System Status */}
            <div className="p-3 border-t border-border space-y-2">
              <div className="text-xs text-muted-foreground flex items-center gap-2">
                <Wifi className="w-3 h-3 text-green-500" /> Connected
              </div>
              <div className="text-xs text-muted-foreground px-1 truncate">
                {userEmail}
              </div>
              <button 
                onClick={() => setIsSettingsOpen(true)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md hover:bg-accent text-foreground/70 transition-colors text-sm" 
                data-testid="button-settings"
              >
                <Settings className="w-4 h-4" />
                Settings
              </button>
              <button 
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md hover:bg-red-100 dark:hover:bg-red-900/20 text-red-600 transition-colors text-sm"
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full bg-background min-w-0 overflow-hidden">
        
        {/* Header */}
        <header className="h-14 border-b border-border flex items-center px-4 sticky top-0 z-10 bg-background/80 backdrop-blur-md">
          <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-accent rounded-md text-muted-foreground" data-testid="button-toggle-sidebar">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1 flex items-center justify-center gap-3">
            <span className="font-semibold text-lg">TimesZapp</span>
            {currentView === "chat" && (
              <div className="flex items-center gap-2 bg-accent/50 rounded-lg p-1">
                <button 
                  onClick={() => setChatMode("assistant")}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all ${chatMode === "assistant" ? 'bg-primary text-primary-foreground' : 'text-foreground/70 hover:text-foreground'}`}
                  data-testid="mode-assistant"
                >
                  Assistant
                </button>
                <button 
                  onClick={() => setChatMode("research")}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all ${chatMode === "research" ? 'bg-primary text-primary-foreground' : 'text-foreground/70 hover:text-foreground'}`}
                  data-testid="mode-research"
                >
                  Research
                </button>
              </div>
            )}
          </div>
          {isSpeaking && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-full text-xs font-medium animate-pulse">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
              Voice Active
            </div>
          )}
        </header>

        {/* Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden min-w-0">
          
          {/* HOME FEED VIEW - Timeline style like Facebook/LinkedIn */}
          {currentView === "home" && (
            <div className="flex-1 overflow-y-auto overflow-x-hidden min-w-0">
              <div className="max-w-2xl mx-auto p-4 min-w-0">
                {/* Refresh Header */}
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">Home Feed</h2>
                  <button
                    onClick={() => refetchNotifications()}
                    className="p-2 hover:bg-accent rounded-full transition-colors"
                    data-testid="button-refresh-feed"
                  >
                    <RefreshCw className="w-5 h-5 text-muted-foreground" />
                  </button>
                </div>

                {/* Connected Networks Bar */}
                {services && services.length > 0 && (
                  <div className="flex items-center gap-2 mb-4 p-3 bg-card border border-border rounded-lg overflow-x-auto scrollbar-hide">
                    <span className="text-xs text-muted-foreground shrink-0">From:</span>
                    <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
                      {services.map((s: any) => {
                        const network = SOCIAL_NETWORKS.find(n => n.id === s.serviceName.toLowerCase());
                        const IconComp = network?.icon || Globe;
                        return (
                          <span key={s.id} className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap shrink-0 ${network?.color || 'bg-zinc-100 text-zinc-600'}`}>
                            <IconComp className="w-3 h-3" />
                            {network?.name || s.serviceName}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Timeline Feed */}
                <div className="space-y-4">
                  {notifications && notifications.length > 0 ? (
                    notifications.map((n: any, index: number) => {
                      const network = SOCIAL_NETWORKS.find(net => net.id === n.source);
                      const IconComp = network?.icon || Bell;
                      return (
                        <motion.article
                          key={n.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow"
                          data-testid={`feed-item-${n.id}`}
                        >
                          {/* Post Header */}
                          <div className="flex items-center gap-3 p-4 pb-2">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${network?.color || 'bg-zinc-100 text-zinc-600'}`}>
                              <IconComp className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-sm">{n.title}</span>
                                <span className="text-xs text-muted-foreground capitalize">• {n.source}</span>
                              </div>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Clock className="w-3 h-3" />
                                {new Date(n.receivedAt).toLocaleString()}
                              </div>
                            </div>
                            <button className="p-2 hover:bg-accent rounded-full" data-testid={`button-more-${n.id}`}>
                              <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                            </button>
                          </div>

                          {/* Post Content */}
                          <div className="px-4 pb-3">
                            <p className="text-sm text-foreground" data-testid={`text-content-${n.id}`}>{n.description}</p>
                          </div>

                          {/* Post Actions */}
                          <div className="flex items-center border-t border-border px-4 py-2 gap-4">
                            <button className="flex items-center gap-2 text-muted-foreground hover:text-red-500 transition-colors text-sm py-2 px-3 hover:bg-accent rounded-lg" data-testid={`button-like-${n.id}`}>
                              <Heart className="w-4 h-4" />
                              Like
                            </button>
                            <button className="flex items-center gap-2 text-muted-foreground hover:text-blue-500 transition-colors text-sm py-2 px-3 hover:bg-accent rounded-lg" data-testid={`button-comment-${n.id}`}>
                              <MessageSquare className="w-4 h-4" />
                              Comment
                            </button>
                            <button className="flex items-center gap-2 text-muted-foreground hover:text-green-500 transition-colors text-sm py-2 px-3 hover:bg-accent rounded-lg" data-testid={`button-share-${n.id}`}>
                              <Share2 className="w-4 h-4" />
                              Share
                            </button>
                          </div>
                        </motion.article>
                      );
                    })
                  ) : (
                    <div className="text-center py-16 bg-card border border-border rounded-xl">
                      <Home className="w-16 h-16 mx-auto mb-4 opacity-20" />
                      <h3 className="text-lg font-medium mb-2">Your Feed is Empty</h3>
                      <p className="text-muted-foreground mb-4 text-sm">Connect your social networks to see updates here</p>
                      <button 
                        onClick={() => setCurrentView("services")}
                        className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90"
                        data-testid="button-connect-networks-home"
                      >
                        Connect Networks
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* MY PROFILE VIEW - User's own posts and content */}
          {currentView === "dashboard" && (
            <div className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-3xl mx-auto">
                {/* Profile Header */}
                <div className="bg-card border border-border rounded-xl overflow-hidden mb-6">
                  <div className="h-24 bg-gradient-to-r from-primary/20 via-primary/10 to-transparent"></div>
                  <div className="px-6 pb-6 -mt-8">
                    <div className="flex items-end gap-4">
                      <div className="w-20 h-20 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold border-4 border-background">
                        {userEmail?.charAt(0).toUpperCase() || 'U'}
                      </div>
                      <div className="flex-1 pb-2">
                        <h2 className="text-xl font-bold">{userEmail?.split('@')[0] || 'User'}</h2>
                        <p className="text-sm text-muted-foreground">{userEmail}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Friends Section */}
                <div className="bg-card border border-border rounded-xl p-4 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <User className="w-5 h-5 text-primary" />
                      Friends ({friends?.length || 0})
                    </h3>
                  </div>
                  
                  {/* Find Friends */}
                  <div className="mb-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Find Friends</p>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search by name or email..."
                        value={friendSearchQuery}
                        onChange={(e) => handleFriendSearch(e.target.value)}
                        className="w-full px-3 py-2 bg-muted border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        data-testid="input-friend-search"
                      />
                      {isSearchingFriends && (
                        <div className="absolute right-3 top-2.5">
                          <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    {friendSearchResults.length > 0 && (
                      <div className="mt-2 space-y-2">
                        {friendSearchResults.map((user) => (
                          <div key={user.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold">
                                {(user.name || user.email).charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{user.name || user.email.split('@')[0]}</p>
                                <p className="text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                            <button 
                              onClick={() => handleSendFriendRequest(user.id)}
                              className="px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:opacity-90"
                              data-testid={`button-add-friend-${user.id}`}
                            >
                              Add Friend
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  {/* Friend Requests */}
                  {friendRequests && friendRequests.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Friend Requests ({friendRequests.length})</p>
                      <div className="space-y-2">
                        {friendRequests.map((request: any) => (
                          <div key={request.id} className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                                {(request.requesterName || request.requesterEmail).charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{request.requesterName || request.requesterEmail.split('@')[0]}</p>
                                <p className="text-xs text-muted-foreground">{request.requesterEmail}</p>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => handleAcceptFriendRequest(request.id)}
                                className="px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:opacity-90" 
                                data-testid={`button-accept-friend-${request.id}`}
                              >
                                Accept
                              </button>
                              <button 
                                onClick={() => handleDeclineFriendRequest(request.id)}
                                className="px-3 py-1.5 bg-muted hover:bg-accent rounded-lg text-xs font-medium" 
                                data-testid={`button-decline-friend-${request.id}`}
                              >
                                Decline
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* My Friends */}
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">My Friends</p>
                    {friends && friends.length > 0 ? (
                      <div className="flex gap-3 overflow-x-auto pb-2">
                        {friends.map((friend: any) => (
                          <div key={friend.id} className="flex flex-col items-center gap-1 flex-shrink-0">
                            <div className="relative">
                              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold">
                                {(friend.name || friend.email).charAt(0).toUpperCase()}
                              </div>
                              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                            </div>
                            <span className="text-xs text-muted-foreground">{friend.name || friend.email.split('@')[0]}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">No friends yet. Search above to find and add friends!</p>
                    )}
                  </div>
                </div>

                {/* Activity Feed - Real-time posts and emails */}
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="p-4 border-b border-border">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold flex items-center gap-2">
                          <Home className="w-5 h-5 text-primary" />
                          Activity Feed
                        </h3>
                        <p className="text-xs text-muted-foreground">Real-time updates from your networks</p>
                      </div>
                      {!gmailOAuthStatus?.connected && (
                        <button
                          onClick={handleConnectGmailFull}
                          disabled={isConnectingGmail}
                          className="flex items-center gap-2 px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white rounded-lg text-xs font-medium transition-colors disabled:opacity-50"
                          data-testid="button-sync-gmail"
                        >
                          <Mail className="w-4 h-4" />
                          {isConnectingGmail ? 'Connecting...' : 'Sync Gmail'}
                        </button>
                      )}
                    </div>
                  </div>
                  
                  <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
                    {/* Emails from Gmail OAuth */}
                    {gmailOAuthStatus?.connected && gmailEmails?.emails?.map((email: any, index: number) => (
                      <div key={email.id || index} className="p-4 hover:bg-accent/50 transition-colors" data-testid={`feed-email-${index}`}>
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0">
                            <Mail className="w-5 h-5 text-red-600 dark:text-red-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">{email.from || 'Unknown Sender'}</span>
                              {email.isUnread && (
                                <span className="px-1.5 py-0.5 bg-blue-500 text-white text-[10px] rounded-full font-medium">NEW</span>
                              )}
                              <span className="text-xs text-muted-foreground">via Gmail</span>
                            </div>
                            <h4 className="font-medium text-sm mb-1 truncate">{email.subject || '(No Subject)'}</h4>
                            <p className="text-sm text-muted-foreground line-clamp-2">{email.snippet || 'No preview available'}</p>
                            <div className="flex items-center gap-4 mt-3">
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {email.date ? new Date(email.date).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Just now'}
                              </span>
                              <div className="flex gap-2 ml-auto">
                                <button 
                                  onClick={() => window.open(`mailto:${email.fromEmail || email.from}?subject=Re: ${email.subject || ''}`, '_blank')}
                                  className="flex items-center gap-1 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg text-xs font-medium transition-colors"
                                  data-testid={`button-reply-email-${index}`}
                                >
                                  <MessageCircle className="w-3 h-3" />
                                  Reply
                                </button>
                                <button 
                                  onClick={() => window.open(`mailto:?subject=Fwd: ${email.subject || ''}&body=${encodeURIComponent(`---------- Forwarded message ----------\nFrom: ${email.from || ''}\nSubject: ${email.subject || ''}\n\n${email.snippet || ''}`)}`, '_blank')}
                                  className="flex items-center gap-1 px-3 py-1.5 bg-muted hover:bg-accent rounded-lg text-xs font-medium transition-colors"
                                  data-testid={`button-forward-email-${index}`}
                                >
                                  <Share2 className="w-3 h-3" />
                                  Forward
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {/* Empty State - Not connected or no emails */}
                    {!gmailOAuthStatus?.connected && (
                      <div className="p-8 text-center">
                        <Mail className="w-12 h-12 mx-auto mb-3 text-red-500 opacity-50" />
                        <p className="text-muted-foreground text-sm mb-3">Connect your Gmail to see your daily emails here</p>
                        <button 
                          onClick={handleConnectGmailFull}
                          disabled={isConnectingGmail}
                          className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                          data-testid="button-connect-gmail-feed"
                        >
                          {isConnectingGmail ? 'Connecting...' : 'Connect Gmail'}
                        </button>
                      </div>
                    )}
                    
                    {gmailOAuthStatus?.connected && (!gmailEmails?.emails || gmailEmails.emails.length === 0) && (
                      <div className="p-8 text-center">
                        <Mail className="w-12 h-12 mx-auto mb-3 text-green-500 opacity-50" />
                        <p className="text-muted-foreground text-sm">Gmail connected! Loading your emails...</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Chat View */}
          {currentView === "chat" && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth space-y-6">
                <div className="max-w-3xl mx-auto w-full">
                  {messages.length === 0 && (
                    <div className="text-center py-20">
                      {chatMode === "research" ? (
                        <div className="inline-flex p-4 bg-primary/10 rounded-full mb-4">
                          <Search className="w-8 h-8 text-primary" />
                        </div>
                      ) : (
                        <div className="flex justify-center mb-6">
                          <svg viewBox="0 0 200 200" className="w-24 h-24">
                            {/* Clock face */}
                            <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="4" />
                            
                            {/* Tick marks */}
                            {[...Array(12)].map((_, i) => {
                              const angle = (i * 30 - 90) * (Math.PI / 180);
                              const x1 = 100 + 72 * Math.cos(angle);
                              const y1 = 100 + 72 * Math.sin(angle);
                              const x2 = 100 + 82 * Math.cos(angle);
                              const y2 = 100 + 82 * Math.sin(angle);
                              return (
                                <line
                                  key={i}
                                  x1={x1}
                                  y1={y1}
                                  x2={x2}
                                  y2={y2}
                                  stroke="currentColor"
                                  strokeWidth={i % 3 === 0 ? "4" : "2"}
                                  strokeLinecap="round"
                                />
                              );
                            })}
                            
                            {/* Hour hand (pointing to 10) */}
                            <line x1="100" y1="100" x2="65" y2="65" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
                            
                            {/* Minute hand (pointing to 2) */}
                            <line x1="100" y1="100" x2="140" y2="60" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                            
                            {/* Center dot */}
                            <circle cx="100" cy="100" r="6" fill="currentColor" />
                          </svg>
                        </div>
                      )}
                      <h2 className="text-2xl font-semibold mb-2">{chatMode === "research" ? "Research & Discovery" : "Minutz AI"}</h2>
                      <p className="text-muted-foreground">{chatMode === "research" ? "Search, analyze, and discover information" : "Ask me anything - I can help with any topic!"}</p>
                    </div>
                  )}

                  {messages.map((msg) => (
                    <motion.div 
                      key={msg.id} 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex gap-4 mb-6 ${msg.role === 'assistant' ? '' : 'flex-row-reverse'}`} 
                      data-testid={`message-${msg.role}-${msg.id}`}
                    >
                      <div className={`shrink-0 ${msg.role === 'assistant' ? '' : 'w-8 h-8 rounded-full flex items-center justify-center shadow-sm bg-secondary text-secondary-foreground'}`}>
                        {msg.role === 'assistant' ? (
                          chatMode === "research" ? (
                            <div className="w-8 h-8 rounded-full flex items-center justify-center shadow-sm border border-foreground bg-background">
                              <Search className="w-4 h-4" />
                            </div>
                          ) : (
                            <svg viewBox="0 0 200 200" className="w-8 h-8">
                              <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="6" />
                              {[0, 3, 6, 9].map((i) => {
                                const angle = (i * 30 - 90) * (Math.PI / 180);
                                const x1 = 100 + 65 * Math.cos(angle);
                                const y1 = 100 + 65 * Math.sin(angle);
                                const x2 = 100 + 80 * Math.cos(angle);
                                const y2 = 100 + 80 * Math.sin(angle);
                                return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="currentColor" strokeWidth="6" strokeLinecap="round" />;
                              })}
                              <line x1="100" y1="100" x2="70" y2="70" stroke="currentColor" strokeWidth="8" strokeLinecap="round" />
                              <line x1="100" y1="100" x2="135" y2="65" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
                              <circle cx="100" cy="100" r="8" fill="currentColor" />
                            </svg>
                          )
                        ) : (
                          <User className="w-4 h-4" />
                        )}
                      </div>

                      <div className={`flex flex-col max-w-2xl ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        {msg.isThinking ? (
                          <div className="px-4 py-3 bg-accent/50 rounded-2xl flex gap-1 items-center">
                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
                          </div>
                        ) : (
                          <>
                            {/* Message Attachments */}
                            {msg.attachments && msg.attachments.length > 0 && (
                              <div className="flex flex-wrap gap-2 mb-2">
                                {msg.attachments.map((att, idx) => (
                                  att.mime.startsWith("image/") ? (
                                    <a 
                                      key={idx}
                                      href={att.url} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="block"
                                      data-testid={`attachment-image-${msg.id}-${idx}`}
                                    >
                                      <img 
                                        src={att.url}
                                        alt={att.name}
                                        className="max-w-[200px] max-h-[200px] rounded-lg border border-border object-cover hover:opacity-90 transition-opacity"
                                      />
                                    </a>
                                  ) : (
                                    <a 
                                      key={idx}
                                      href={att.url} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="flex items-center gap-2 px-3 py-2 bg-accent rounded-lg border border-border hover:bg-accent/80 transition-colors"
                                      data-testid={`attachment-file-${msg.id}-${idx}`}
                                    >
                                      <FileText className="w-4 h-4 text-muted-foreground" />
                                      <div>
                                        <p className="text-xs font-medium">{att.name}</p>
                                        <p className="text-xs text-muted-foreground">{formatFileSize(att.size)}</p>
                                      </div>
                                    </a>
                                  )
                                ))}
                              </div>
                            )}
                            {/* Message Content */}
                            {msg.content && (
                              <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                                msg.role === 'user' 
                                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                                  : 'bg-card border border-border rounded-tl-none'
                              }`} data-testid={`text-content-${msg.id}`}>
                                {msg.content}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Input Area */}
              <div className="p-4 border-t border-border bg-background">
                <div className="max-w-3xl mx-auto">
                  {/* File Preview */}
                  {selectedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-3 p-3 bg-accent/30 rounded-xl border border-border">
                      {selectedFiles.map((file, index) => (
                        <div key={index} className="relative group">
                          {file.type.startsWith("image/") && filePreviews[index] ? (
                            <div className="relative">
                              <img 
                                src={filePreviews[index]} 
                                alt={file.name}
                                className="w-16 h-16 object-cover rounded-lg border border-border"
                              />
                              <button
                                onClick={() => removeFile(index)}
                                className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                data-testid={`remove-file-${index}`}
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="relative flex items-center gap-2 px-3 py-2 bg-background rounded-lg border border-border">
                              <FileText className="w-4 h-4 text-muted-foreground" />
                              <div className="max-w-[100px]">
                                <p className="text-xs font-medium truncate">{file.name}</p>
                                <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                              </div>
                              <button
                                onClick={() => removeFile(index)}
                                className="p-1 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-full"
                                data-testid={`remove-file-${index}`}
                              >
                                <X className="w-3 h-3 text-red-500" />
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <div className={`relative flex items-center gap-1 md:gap-2 p-1.5 md:p-2 rounded-2xl border transition-all duration-200 ${isAudioRecording ? 'border-red-500 ring-4 ring-red-500/10' : 'border-input focus-within:border-primary focus-within:ring-4 focus-within:ring-primary/5 shadow-sm'}`}>
                    
                    {/* Hidden file input */}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      multiple
                      accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                      className="hidden"
                      data-testid="file-input"
                    />

                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading || selectedFiles.length >= 5}
                      className="p-2 md:p-3 rounded-xl transition-all duration-200 shrink-0 bg-secondary hover:bg-secondary/80 text-secondary-foreground disabled:opacity-50"
                      title="Attach files (images, documents)"
                      data-testid="button-attach"
                    >
                      <Paperclip className="w-4 h-4 md:w-5 md:h-5" />
                    </button>

                    <button 
                      onClick={isAudioRecording ? stopAudioRecording : startAudioRecording}
                      className={`p-2 md:p-3 rounded-xl transition-all duration-200 shrink-0 ${
                        isAudioRecording 
                          ? 'bg-red-500 text-white shadow-md animate-pulse' 
                          : 'bg-secondary hover:bg-secondary/80 text-secondary-foreground'
                      }`}
                      title={isAudioRecording ? "Stop Listening" : "Start Voice Command"}
                      data-testid="button-voice"
                    >
                      {isAudioRecording ? <MicOff className="w-4 h-4 md:w-5 md:h-5" /> : <Mic className="w-4 h-4 md:w-5 md:h-5" />}
                    </button>

                    <input
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                      placeholder={isAudioRecording ? "Listening with Whisper..." : (chatMode === "research" ? "Search anything..." : "Ask me anything...")}
                      className="flex-1 bg-transparent border-none outline-none text-sm md:text-base px-1 md:px-2 min-w-0"
                      disabled={isAudioRecording || isLoading}
                      data-testid="input-message"
                    />
                    
                    {/* Show Send button when there's input text or files, otherwise show Voice Chat button */}
                    {(input.trim() || selectedFiles.length > 0) ? (
                      <button 
                        onClick={() => handleSend()}
                        disabled={isAudioRecording || isLoading || isUploading}
                        className="p-2 md:p-3 bg-primary text-primary-foreground rounded-xl hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm shrink-0"
                        data-testid="button-send"
                      >
                        {isUploading ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Send className="w-4 h-4" />
                        )}
                      </button>
                    ) : (
                      <button 
                        onClick={startVoiceChat}
                        className="p-2 md:p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-all shadow-sm shrink-0"
                        title="Talk with AI"
                        data-testid="button-voice-chat"
                      >
                        <AudioLines className="w-4 h-4 md:w-5 md:h-5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Messages View */}
          {currentView === "messages" && (
            <div className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-3xl mx-auto">
                <h2 className="text-2xl font-semibold mb-2">Messages</h2>
                <p className="text-muted-foreground mb-6">Chat with friends across all your connected networks</p>
                
                <div className="text-center py-16 bg-card border border-border rounded-lg">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <h3 className="text-lg font-medium mb-2">Unified Messaging Coming Soon</h3>
                  <p className="text-muted-foreground">Send and receive messages from all your connected networks in one place</p>
                </div>
              </div>
            </div>
          )}

          {/* NETWORKS VIEW - Compact icon sidebar with details panel */}
          {currentView === "services" && (
            <div className="flex-1 flex overflow-hidden min-w-0">
              {/* Left Sidebar - Icon-only Network List */}
              <div className="w-20 shrink-0 border-r border-border bg-zinc-50 dark:bg-zinc-900 flex flex-col overflow-hidden">
                <div className="p-3 border-b border-border text-center">
                  <h3 className="font-semibold text-xs">Networks</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-2 flex flex-col items-center gap-2">
                  {SOCIAL_NETWORKS.map((network) => {
                    const connected = isServiceConnected(network.id);
                    const IconComp = network.icon;
                    const isSelected = selectedNetwork === network.id;
                    
                    return (
                      <button
                        key={network.id}
                        onClick={() => setSelectedNetwork(network.id)}
                        className={`relative p-3 rounded-xl transition-all ${
                          isSelected 
                            ? 'bg-accent ring-2 ring-primary/50 scale-110' 
                            : 'hover:bg-accent/50 hover:scale-105'
                        }`}
                        data-testid={`network-btn-${network.id}`}
                        title={network.name}
                      >
                        <div className={`p-2 rounded-lg ${network.color}`}>
                          <IconComp className="w-5 h-5" />
                        </div>
                        {connected && (
                          <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-background"></div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right Panel - Network Details */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-6 min-w-0">
                {selectedNetwork ? (
                  (() => {
                    const network = SOCIAL_NETWORKS.find(n => n.id === selectedNetwork);
                    const connected = isServiceConnected(selectedNetwork);
                    const service = getServiceByNetworkId(selectedNetwork);
                    const IconComp = network?.icon || Globe;

                    return (
                      <div className="max-w-2xl">
                        {/* Network Header */}
                        <div className="flex flex-wrap items-center gap-3 md:gap-4 mb-6">
                          <div className={`p-3 md:p-4 rounded-xl shrink-0 ${network?.color || 'bg-zinc-100'}`}>
                            <IconComp className="w-6 h-6 md:w-8 md:h-8" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h2 className="text-xl md:text-2xl font-bold truncate">{network?.name}</h2>
                            <p className={`text-sm ${connected ? 'text-green-600 dark:text-green-400' : 'text-muted-foreground'}`}>
                              {connected ? 'Connected' : 'Not connected'}
                            </p>
                          </div>
                          {connected ? (
                            <button
                              onClick={() => service && handleDisconnectService(service.id)}
                              className="px-3 py-1.5 md:px-4 md:py-2 bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 rounded-lg text-xs md:text-sm font-medium hover:opacity-80 flex items-center gap-1.5 md:gap-2 shrink-0"
                              data-testid={`button-disconnect-${selectedNetwork}`}
                            >
                              <Trash2 className="w-3.5 h-3.5 md:w-4 md:h-4" />
                              Disconnect
                            </button>
                          ) : (
                            <button
                              onClick={() => handleConnectService(selectedNetwork)}
                              className="px-3 py-1.5 md:px-4 md:py-2 bg-primary text-primary-foreground rounded-lg text-xs md:text-sm font-medium hover:opacity-90 shrink-0"
                              data-testid={`button-connect-${selectedNetwork}`}
                            >
                              Connect
                            </button>
                          )}
                        </div>

                        {/* Network Stats/Info */}
                        {connected ? (
                          <div className="space-y-6">
                            {/* Gmail-specific stats */}
                            {selectedNetwork === 'gmail' && gmailStatus?.connected && gmailStats && (
                              <>
                                {/* Since Connected Badge */}
                                {gmailStats.connectedAt && (
                                  <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-full text-xs font-medium">
                                    <Clock className="w-3 h-3" />
                                    Connected since {new Date(gmailStats.connectedAt).toLocaleDateString()}
                                    {gmailStats.isFiltered && ' (showing new emails only)'}
                                  </div>
                                )}
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="bg-card border border-border rounded-lg p-4 text-center">
                                    <div className="text-2xl font-bold text-red-500">{gmailStats.totalMessages}</div>
                                    <div className="text-xs text-muted-foreground">
                                      {gmailStats.isFiltered ? 'New Emails' : 'Total Emails'}
                                    </div>
                                  </div>
                                  <div className="bg-card border border-red-200 dark:border-red-800 rounded-lg p-4 text-center">
                                    <div className="text-2xl font-bold text-red-500">{gmailStats.unreadMessages}</div>
                                    <div className="text-xs text-muted-foreground">Unread</div>
                                  </div>
                                </div>

                                {gmailLabels && gmailLabels.length > 0 && (
                                  <div className="bg-card border border-border rounded-xl p-4">
                                    <h4 className="font-medium mb-3">Labels</h4>
                                    <div className="flex flex-wrap gap-2">
                                      {gmailLabels.map((label: any) => (
                                        <span key={label.id} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-full text-xs font-medium">
                                          {label.name}
                                          {label.messagesUnread > 0 && (
                                            <span className="bg-red-500 text-white px-1.5 py-0.5 rounded-full text-xs">{label.messagesUnread}</span>
                                          )}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </>
                            )}

                            {/* Generic connected info for other networks */}
                            {selectedNetwork !== 'gmail' && (
                              <div className="bg-card border border-border rounded-xl p-6 text-center">
                                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                  <IconComp className="w-8 h-8 text-green-600 dark:text-green-400" />
                                </div>
                                <h3 className="font-semibold mb-2">{network?.name} Connected</h3>
                                <p className="text-sm text-muted-foreground">
                                  Your {network?.name} account is linked. Updates will appear in your Home Feed.
                                </p>
                                <p className="text-xs text-muted-foreground mt-4">
                                  Note: Full integration requires additional API setup for this platform.
                                </p>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="bg-card border border-border rounded-xl p-8 text-center">
                            <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${network?.color || 'bg-zinc-100'}`}>
                              <IconComp className="w-10 h-10" />
                            </div>
                            <h3 className="text-lg font-semibold mb-2">Connect {network?.name}</h3>
                            <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">
                              Link your {network?.name} account to see updates, notifications, and messages in your unified feed.
                            </p>
                            <button
                              onClick={() => handleConnectService(selectedNetwork)}
                              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90"
                              data-testid={`button-connect-main-${selectedNetwork}`}
                            >
                              Connect {network?.name}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })()
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <Wifi className="w-16 h-16 mx-auto mb-4 opacity-20" />
                      <h3 className="text-lg font-medium mb-2">Select a Network</h3>
                      <p className="text-muted-foreground text-sm">Choose a network from the left to view details and manage connection</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* MR TECHIE VIEW - Autonomous Tech News Agent */}
          {currentView === "mr-techie" && (
            <div className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-semibold flex items-center gap-2">
                      <Cpu className="w-6 h-6 text-blue-500" />
                      Mr Techie
                    </h2>
                    <p className="text-muted-foreground text-sm">Your autonomous tech news agent - Search any topic or get top 10 insights</p>
                  </div>
                  <button
                    onClick={() => { handleClearTechNewsSearch(); refetchTechNews(); }}
                    disabled={techNewsLoading || isSearchingTechNews}
                    className="p-2 hover:bg-accent rounded-full transition-colors disabled:opacity-50"
                    data-testid="button-refresh-tech-news"
                  >
                    <RefreshCw className={`w-5 h-5 text-muted-foreground ${(techNewsLoading || isSearchingTechNews) ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {/* Custom Topic Search */}
                <div className="mb-4 p-4 bg-card border border-border rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Search className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Search Custom Topic</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={techNewsSearchTopic}
                      onChange={(e) => setTechNewsSearchTopic(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearchTechNews()}
                      placeholder="e.g., AI in healthcare, Electric vehicles, Quantum computing..."
                      className="flex-1 px-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                      data-testid="input-tech-news-search"
                    />
                    <button
                      onClick={handleSearchTechNews}
                      disabled={isSearchingTechNews || !techNewsSearchTopic.trim()}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 disabled:opacity-50"
                      data-testid="button-search-tech-news"
                    >
                      {isSearchingTechNews ? 'Searching...' : 'Search'}
                    </button>
                    {customTechNews && (
                      <button
                        onClick={handleClearTechNewsSearch}
                        className="px-3 py-2 bg-muted hover:bg-accent rounded-lg text-sm"
                        data-testid="button-clear-tech-search"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  {customTechNews && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Showing results for: <span className="font-medium text-foreground">"{techNewsSearchTopic}"</span>
                    </p>
                  )}
                </div>

                {/* Notification Toggle */}
                {notificationsSupported && !customTechNews && (
                  <div className="mb-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 border border-purple-200 dark:border-purple-800 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${techNewsNotificationsEnabled ? 'bg-green-100 dark:bg-green-900/30' : 'bg-zinc-100 dark:bg-zinc-800'}`}>
                          <BellRing className={`w-5 h-5 ${techNewsNotificationsEnabled ? 'text-green-600 dark:text-green-400' : 'text-muted-foreground'}`} />
                        </div>
                        <div>
                          <h4 className="font-medium text-sm">Hourly Notifications</h4>
                          <p className="text-xs text-muted-foreground">Get browser alerts with top 3 tech news every hour</p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          if (techNewsNotificationsEnabled) {
                            setTechNewsNotificationsEnabled(false);
                          } else {
                            handleEnableTechNewsNotifications();
                          }
                        }}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                          techNewsNotificationsEnabled 
                            ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-900/50' 
                            : 'bg-primary text-primary-foreground hover:opacity-90'
                        }`}
                        data-testid="button-toggle-notifications"
                      >
                        {techNewsNotificationsEnabled ? 'Enabled' : 'Enable'}
                      </button>
                    </div>
                    {notificationPermission === 'denied' && (
                      <p className="text-xs text-red-500 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Notifications are blocked. Please enable them in your browser settings.
                      </p>
                    )}
                  </div>
                )}

                {!customTechNews && techNews?.hourBucket && (
                  <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-blue-500" />
                      <span className="font-medium">Last updated:</span>
                      <span className="text-muted-foreground">
                        {new Date(techNews.hourBucket).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(techNews.hourBucket).toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                )}

                {(techNewsLoading || isSearchingTechNews) ? (
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="p-4 bg-card border border-border rounded-xl animate-pulse">
                        <div className="h-5 bg-muted rounded w-3/4 mb-3"></div>
                        <div className="h-4 bg-muted rounded w-full mb-2"></div>
                        <div className="h-4 bg-muted rounded w-2/3"></div>
                      </div>
                    ))}
                  </div>
                ) : (customTechNews || techNews?.news) && (customTechNews || techNews?.news).length > 0 ? (
                  <div className="space-y-4">
                    {(customTechNews || techNews?.news || []).map((item: any, index: number) => {
                      const isExpanded = expandedNewsId === item.id;
                      return (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className={`p-4 bg-card border rounded-xl transition-all cursor-pointer ${isExpanded ? 'border-blue-500 shadow-lg' : 'border-border hover:border-blue-500/50'}`}
                          onClick={() => setExpandedNewsId(isExpanded ? null : item.id)}
                          data-testid={`tech-news-${index}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                              {index + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
                              <p className="text-sm text-muted-foreground mb-2">{item.summary}</p>
                              
                              {/* Expanded Details */}
                              <AnimatePresence>
                                {isExpanded && (
                                  <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="overflow-hidden"
                                  >
                                    <div className="pt-3 pb-2 border-t border-border mt-3">
                                      <p className="text-sm text-foreground mb-4">
                                        {item.details || item.summary}
                                      </p>
                                      <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                                        <Globe className="w-4 h-4 text-muted-foreground" />
                                        <span className="text-xs text-muted-foreground">Source:</span>
                                        <a 
                                          href={item.sourceUrl || item.url || '#'} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          onClick={(e) => e.stopPropagation()}
                                          className="text-xs text-blue-500 hover:underline font-medium"
                                        >
                                          {item.source}
                                        </a>
                                      </div>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                              
                              <div className="flex flex-wrap items-center gap-2 text-xs mt-2">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                                  <Zap className="w-3 h-3" />
                                  {item.category}
                                </span>
                                <span className="inline-flex items-center gap-1 text-muted-foreground">
                                  <Newspaper className="w-3 h-3" />
                                  {item.source}
                                </span>
                                <span className="ml-auto text-muted-foreground">
                                  {isExpanded ? 'Click to collapse' : 'Click to expand'}
                                </span>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Cpu className="w-16 h-16 mx-auto mb-4 opacity-20" />
                    <h3 className="text-lg font-medium mb-2">No Tech News Yet</h3>
                    <p className="text-muted-foreground text-sm mb-4">Mr Techie is gathering the latest technology insights for you</p>
                    <button
                      onClick={() => refetchTechNews()}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90"
                      data-testid="button-fetch-tech-news"
                    >
                      Fetch Latest News
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* INSIGHTS VIEW - AI-powered trends, analysis, and proactive suggestions */}
          {currentView === "insights" && (
            <div className="flex-1 overflow-y-auto p-4 md:p-8">
              <div className="max-w-3xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-semibold flex items-center gap-2">
                      <Sparkles className="w-6 h-6 text-purple-500" />
                      AI Insights
                    </h2>
                    <p className="text-muted-foreground text-sm">Trends, patterns, and intelligent analysis from your networks</p>
                  </div>
                  <button
                    onClick={() => refetchTrends()}
                    disabled={trendsLoading}
                    className="p-2 hover:bg-accent rounded-full transition-colors disabled:opacity-50"
                    data-testid="button-refresh-insights"
                  >
                    <RefreshCw className={`w-5 h-5 text-muted-foreground ${trendsLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {/* Connected Networks Status */}
                {trends?.connectedNetworks && (
                  <div className="mb-6 p-4 bg-card border border-border rounded-xl">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className="text-sm font-medium">Analyzing data from:</span>
                      {trends.connectedNetworks.map((network: string) => {
                        const net = SOCIAL_NETWORKS.find(n => n.id === network);
                        const IconComp = net?.icon || Globe;
                        const isAvailable = !trends.unavailableNetworks?.includes(network);
                        return (
                          <span key={network} className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${isAvailable ? net?.color : 'bg-zinc-100 text-zinc-400 dark:bg-zinc-800'}`}>
                            <IconComp className="w-3 h-3" />
                            {net?.name || network}
                            {isAvailable ? (
                              <CheckCircle2 className="w-3 h-3 text-green-500" />
                            ) : (
                              <AlertCircle className="w-3 h-3 text-amber-500" />
                            )}
                          </span>
                        );
                      })}
                    </div>
                    {trends.note && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {trends.note}
                      </p>
                    )}
                  </div>
                )}

                {/* Trending Topics */}
                {trends?.topics && trends.topics.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-500" />
                      Trending Topics
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {trends.topics.slice(0, 6).map((topic: { keyword: string; count: number }, index: number) => (
                        <motion.div
                          key={topic.keyword}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className="p-3 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors cursor-pointer"
                          data-testid={`topic-${index}`}
                        >
                          <div className="font-medium text-sm truncate">{topic.keyword}</div>
                          <div className="text-xs text-muted-foreground">{topic.count} mentions</div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Trends Analysis */}
                {trends?.trends && trends.trends.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-500" />
                      Latest Trends
                    </h3>
                    {trends.trends.map((trend: any, index: number) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-4 bg-card border border-border rounded-xl"
                        data-testid={`trend-${index}`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${
                            trend.sentiment === 'positive' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' :
                            trend.sentiment === 'negative' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' :
                            'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
                          }`}>
                            <TrendingUp className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold truncate">{trend.topic}</h4>
                            <p className="text-sm text-muted-foreground mt-1">{trend.summary}</p>
                            <div className="flex flex-wrap items-center gap-2 mt-2">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                                trend.sentiment === 'positive' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                                trend.sentiment === 'negative' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' :
                                'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300'
                              }`}>
                                {trend.sentiment || 'neutral'}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {trend.itemCount || 0} items analyzed
                              </span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                ) : trendsLoading ? (
                  <div className="text-center py-16 bg-card border border-border rounded-xl">
                    <div className="w-12 h-12 mx-auto mb-4 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                    <h3 className="text-lg font-medium">Analyzing your networks...</h3>
                    <p className="text-muted-foreground text-sm">This may take a moment</p>
                  </div>
                ) : (
                  <div className="text-center py-16 bg-card border border-border rounded-xl">
                    <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-20" />
                    <h3 className="text-lg font-medium mb-2">No trends detected yet</h3>
                    <p className="text-muted-foreground mb-4 text-sm">Connect more networks or wait for more activity to see trends</p>
                    <button 
                      onClick={() => setCurrentView("services")}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90"
                      data-testid="button-connect-networks-insights"
                    >
                      Connect Networks
                    </button>
                  </div>
                )}

                {/* Quick Actions */}
                <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button
                    onClick={() => {
                      setCurrentView("chat");
                      setInput("Give me a summary of what I missed today");
                    }}
                    className="p-4 bg-card border border-border rounded-xl hover:border-primary/50 transition-colors text-left"
                    data-testid="button-ask-digest"
                  >
                    <h4 className="font-medium flex items-center gap-2">
                      <MessageCircle className="w-4 h-4 text-blue-500" />
                      Ask for a Daily Digest
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1">Get an AI summary of important updates</p>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentView("chat");
                      setInput("What's trending across my social networks?");
                    }}
                    className="p-4 bg-card border border-border rounded-xl hover:border-primary/50 transition-colors text-left"
                    data-testid="button-ask-trends"
                  >
                    <h4 className="font-medium flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-purple-500" />
                      Analyze Trends
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1">Deep dive into what's popular</p>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Voice Chat Full Screen Overlay */}
      <AnimatePresence>
        {isVoiceChatOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-900 flex flex-col items-center justify-center p-4"
            data-testid="voice-chat-overlay"
          >
            {/* Voice Settings Button - Top Right */}
            <button
              onClick={() => setIsVoiceSettingsOpen(true)}
              className="absolute top-4 right-4 md:top-6 md:right-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all z-10"
              data-testid="button-voice-settings"
            >
              <Settings className="w-6 h-6" />
            </button>

            {/* Minutz AI Main Content */}
            <div className="flex flex-col items-center justify-center flex-1 w-full max-w-lg relative pb-24">
              
              {/* Minutz Clock Avatar */}
              <motion.div 
                className="relative mb-6 w-48 h-48 md:w-56 md:h-56"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <MinutzClockAvatar 
                  state={isVoiceMuted ? "idle" : isAudioProcessing ? "processing" : voiceChatState}
                  isMuted={isVoiceMuted}
                  className="w-full h-full"
                />
              </motion.div>
              

              {/* Camera Preview - Jarvis Style */}
              {isCameraActive && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute top-4 left-4"
                >
                  {/* Outer hex frame glow */}
                  <div className="relative">
                    <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/50 via-teal-500/50 to-cyan-500/50 rounded-lg blur-sm animate-pulse" />
                    <div className="relative w-40 h-32 md:w-56 md:h-44 rounded-lg overflow-hidden border-2 border-cyan-500/70 bg-black/50">
                      {/* Corner brackets */}
                      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400 z-10" />
                      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400 z-10" />
                      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400 z-10" />
                      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400 z-10" />
                      
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Scan line overlay */}
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent pointer-events-none" />
                      
                      {/* Auto-scan indicator */}
                      {isAutoScanning && (
                        <motion.div
                          className="absolute inset-0 pointer-events-none"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: [0, 0.3, 0] }}
                          transition={{ duration: 5, repeat: Infinity }}
                        >
                          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
                        </motion.div>
                      )}
                      
                      {/* Capture flash */}
                      {isCapturing && (
                        <motion.div
                          initial={{ opacity: 0.8 }}
                          animate={{ opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="absolute inset-0 bg-cyan-400"
                        />
                      )}
                      
                      {/* Top controls */}
                      <div className="absolute top-1 left-1 right-1 flex items-center justify-between z-10">
                        {/* Auto-scan toggle */}
                        <motion.button
                          onClick={() => setIsAutoScanning(!isAutoScanning)}
                          className={`p-1.5 rounded-full transition-all ${
                            isAutoScanning 
                              ? 'bg-cyan-500/80 text-white' 
                              : 'bg-zinc-800/80 text-zinc-400 hover:bg-zinc-700/80'
                          }`}
                          whileTap={{ scale: 0.9 }}
                          data-testid="button-toggle-autoscan"
                        >
                          {isAutoScanning ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        </motion.button>
                        
                        {/* Status indicator */}
                        <div className="flex items-center gap-1 bg-black/50 px-1.5 py-0.5 rounded">
                          <div className={`w-1.5 h-1.5 rounded-full ${
                            isCapturing ? 'bg-amber-400' : isAutoScanning ? 'bg-cyan-400' : 'bg-green-400'
                          } animate-pulse`} />
                          <span className="text-[9px] uppercase tracking-wider text-cyan-300/80 font-mono">
                            {isCapturing ? 'SCAN' : isAutoScanning ? 'AUTO' : 'LIVE'}
                          </span>
                        </div>
                        
                        {/* Switch camera */}
                        <motion.button
                          onClick={switchCamera}
                          className="p-1.5 rounded-full bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700/80 transition-all"
                          whileTap={{ scale: 0.9 }}
                          data-testid="button-switch-camera"
                        >
                          <FlipHorizontal className="w-3 h-3" />
                        </motion.button>
                      </div>
                      
                      {/* Camera mode indicator */}
                      <div className="absolute bottom-1 left-1 px-1.5 py-0.5 bg-black/50 rounded text-[9px] uppercase tracking-wider text-cyan-300/80 font-mono z-10">
                        {cameraFacing === 'user' ? 'FRONT' : 'BACK'}
                      </div>
                      
                      {/* Analyze button */}
                      <motion.button
                        onClick={captureAndAnalyze}
                        disabled={isCapturing}
                        className={`absolute bottom-1 right-1 p-2 rounded-full transition-all border z-10 ${
                          isCapturing 
                            ? 'bg-amber-500/50 border-amber-500/50 text-amber-200' 
                            : 'bg-cyan-500/80 border-cyan-400 text-white hover:bg-cyan-500 hover:shadow-lg hover:shadow-cyan-500/50'
                        }`}
                        whileTap={{ scale: 0.9 }}
                        data-testid="button-capture-analyze"
                      >
                        {isCapturing ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          >
                            <Sparkles className="w-4 h-4" />
                          </motion.div>
                        ) : (
                          <Sparkles className="w-4 h-4" />
                        )}
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              )}
              <canvas ref={canvasRef} className="hidden" />

            </div>

            {/* Bottom Controls - Fixed at bottom */}
            <div className="absolute bottom-6 left-0 right-0 flex items-center justify-center px-6">
              {/* Close Button - Bottom Left */}
              <motion.button
                onClick={closeVoiceChat}
                className="absolute left-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all"
                whileTap={{ scale: 0.95 }}
                data-testid="button-close-voice-chat"
              >
                <X className="w-5 h-5" />
              </motion.button>

              {/* Mute Button - Center (voice commands control the AI) */}
              <motion.button
                onClick={() => {
                  if (isVoiceMuted) {
                    setIsVoiceMuted(false);
                    resetAudioTranscript();
                    startVoiceChatListening();
                  } else {
                    setIsVoiceMuted(true);
                    stopListening();
                    setVoiceChatState("idle");
                  }
                }}
                className={`p-4 rounded-full transition-all border ${
                  isVoiceMuted 
                    ? "bg-zinc-800 border-zinc-600 text-zinc-400 hover:bg-zinc-700" 
                    : "bg-red-500/20 border-red-500/50 text-red-400 hover:bg-red-500/30"
                }`}
                whileTap={{ scale: 0.95 }}
                data-testid="button-mute-voice"
              >
                {isVoiceMuted ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              </motion.button>

              {/* Camera Vision Button - Bottom Right */}
              <motion.button
                onClick={() => setIsCameraActive(!isCameraActive)}
                className={`absolute right-6 p-3 rounded-full transition-all border ${
                  isCameraActive 
                    ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-400" 
                    : "bg-zinc-800/50 border-zinc-600/50 text-zinc-400 hover:bg-zinc-700/50 hover:border-cyan-500/30 hover:text-cyan-400"
                }`}
                whileTap={{ scale: 0.95 }}
                data-testid="button-camera-vision"
              >
                <Camera className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Voice Settings Modal for Voice Chat */}
            <AnimatePresence>
              {isVoiceSettingsOpen && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 z-60 bg-black/70 flex items-center justify-center p-4"
                  onClick={(e) => e.target === e.currentTarget && setIsVoiceSettingsOpen(false)}
                >
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-zinc-800 border border-zinc-700 rounded-2xl w-full max-w-sm max-h-[80vh] overflow-y-auto shadow-xl"
                  >
                    <div className="flex items-center justify-between p-4 border-b border-zinc-700">
                      <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Volume2 className="w-5 h-5" />
                        Voice Settings
                      </h2>
                      <button
                        onClick={() => setIsVoiceSettingsOpen(false)}
                        className="p-2 hover:bg-zinc-700 rounded-full transition-colors text-white"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="p-4 space-y-4">
                      {/* Auto-speak toggle */}
                      <div className="flex items-center justify-between py-3 border-b border-zinc-700">
                        <div>
                          <p className="font-medium text-white">Auto-speak responses</p>
                          <p className="text-sm text-zinc-400">AI will speak replies</p>
                        </div>
                        <button
                          onClick={() => setAutoSpeak(!autoSpeak)}
                          className={`relative w-12 h-6 rounded-full transition-colors ${
                            autoSpeak ? 'bg-orange-500' : 'bg-zinc-600'
                          }`}
                        >
                          <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                            autoSpeak ? 'translate-x-6' : 'translate-x-0.5'
                          }`} />
                        </button>
                      </div>

                      {/* Voice Selection - Scrollable List */}
                      <div className="py-3 border-b border-zinc-700">
                        <p className="font-medium text-white mb-3">Choose Voice</p>
                        {isLoadingVoices ? (
                          <div className="flex items-center justify-center py-8">
                            <div className="animate-spin rounded-full h-6 w-6 border-2 border-orange-500 border-t-transparent" />
                          </div>
                        ) : elevenLabsVoices.length > 0 ? (
                          <div className="max-h-64 overflow-y-auto space-y-2 pr-1 scrollbar-thin scrollbar-thumb-zinc-600 scrollbar-track-transparent">
                            {elevenLabsVoices.map((voice) => (
                              <div
                                key={voice.voice_id}
                                onClick={() => handleSelectVoice(voice.voice_id)}
                                className={`flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer ${
                                  selectedVoiceId === voice.voice_id
                                    ? 'border-orange-500 bg-orange-500/20' 
                                    : 'border-zinc-600 hover:border-orange-500/50'
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                    voice.labels?.gender === 'male' 
                                      ? 'bg-blue-900/50 text-blue-400'
                                      : voice.labels?.gender === 'female'
                                      ? 'bg-pink-900/50 text-pink-400'
                                      : 'bg-purple-900/50 text-purple-400'
                                  }`}>
                                    <User className="w-5 h-5" />
                                  </div>
                                  <div>
                                    <p className="font-medium text-sm text-white">{voice.name}</p>
                                    <p className="text-xs text-zinc-400 capitalize">
                                      {voice.labels?.accent || voice.labels?.description || voice.category}
                                    </p>
                                  </div>
                                </div>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handlePlayPreview(voice.voice_id, voice.preview_url);
                                  }}
                                  className={`p-2 rounded-full transition-colors ${
                                    playingPreview === voice.voice_id
                                      ? 'bg-orange-500/30 text-orange-400'
                                      : 'hover:bg-zinc-700 text-zinc-400'
                                  }`}
                                  title={playingPreview === voice.voice_id ? "Stop preview" : "Play preview"}
                                >
                                  {playingPreview === voice.voice_id ? (
                                    <Volume2 className="w-4 h-4" />
                                  ) : (
                                    <Play className="w-4 h-4" />
                                  )}
                                </button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-sm text-zinc-400 text-center py-4">No voices available</p>
                        )}
                      </div>

                      {/* Voice Speed */}
                      <div className="py-3">
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium text-white">Speed</p>
                          <span className="text-sm text-zinc-400">{customRate.toFixed(1)}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.5"
                          max="2"
                          step="0.1"
                          value={customRate}
                          onChange={(e) => setCustomRate(parseFloat(e.target.value))}
                          className="w-full h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                        />
                        <div className="flex justify-between text-xs text-zinc-500 mt-1">
                          <span>Slower</span>
                          <span>Faster</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={(e) => e.target === e.currentTarget && setIsSettingsOpen(false)}
            data-testid="settings-modal-overlay"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-background border border-border rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto shadow-xl"
              data-testid="settings-modal"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border sticky top-0 bg-background z-10">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Settings
                </h2>
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="p-2 hover:bg-accent rounded-full transition-colors"
                  data-testid="button-close-settings"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <div className="p-4 space-y-6">
                {/* AI & Voice Section */}
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <AudioLines className="w-4 h-4" />
                    AI & Voice
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-card border border-border rounded-lg">
                      <div>
                        <p className="font-medium text-sm">Voice Chat Mode</p>
                        <p className="text-xs text-muted-foreground">Talk to Minutz using voice</p>
                      </div>
                      <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer">
                        <div className="absolute right-0.5 top-0.5 w-5 h-5 bg-white rounded-full shadow" />
                      </div>
                    </div>
                    <div 
                      onClick={() => setAutoSpeak(!autoSpeak)}
                      className="flex items-center justify-between p-3 bg-card border border-border rounded-lg cursor-pointer"
                    >
                      <div>
                        <p className="font-medium text-sm">Auto-speak Responses</p>
                        <p className="text-xs text-muted-foreground">AI reads responses aloud</p>
                      </div>
                      <div className={`w-10 h-6 rounded-full relative transition-colors ${autoSpeak ? 'bg-primary' : 'bg-muted'}`}>
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${autoSpeak ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </div>
                    <button
                      onClick={() => { setIsSettingsOpen(false); setIsVoiceCloneOpen(true); }}
                      className="w-full flex items-center justify-between p-3 bg-card border border-border rounded-lg hover:bg-accent transition-colors"
                      data-testid="button-open-voice-clone"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                          <Mic className="w-5 h-5 text-white" />
                        </div>
                        <div className="text-left">
                          <p className="font-medium text-sm">Clone Your Voice</p>
                          <p className="text-xs text-muted-foreground">{voiceCloneStatus.hasClonedVoice ? 'Your voice is cloned' : 'Create a personal AI voice'}</p>
                        </div>
                      </div>
                      {voiceCloneStatus.hasClonedVoice && (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Notifications Section */}
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Bell className="w-4 h-4" />
                    Notifications
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-card border border-border rounded-lg">
                      <div>
                        <p className="font-medium text-sm">Push Notifications</p>
                        <p className="text-xs text-muted-foreground">Browser alerts for updates</p>
                      </div>
                      <div className={`w-10 h-6 rounded-full relative cursor-pointer ${notificationPermission === 'granted' ? 'bg-primary' : 'bg-muted'}`}>
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${notificationPermission === 'granted' ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-card border border-border rounded-lg">
                      <div>
                        <p className="font-medium text-sm">Mr Techie Hourly Updates</p>
                        <p className="text-xs text-muted-foreground">Get tech news every hour</p>
                      </div>
                      <div 
                        onClick={() => techNewsNotificationsEnabled ? setTechNewsNotificationsEnabled(false) : handleEnableTechNewsNotifications()}
                        className={`w-10 h-6 rounded-full relative cursor-pointer ${techNewsNotificationsEnabled ? 'bg-primary' : 'bg-muted'}`}
                      >
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${techNewsNotificationsEnabled ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </div>
                    <div 
                      onClick={() => {
                        const newVal = !emailNotifications;
                        setEmailNotifications(newVal);
                        localStorage.setItem('emailNotifications', String(newVal));
                      }}
                      className="flex items-center justify-between p-3 bg-card border border-border rounded-lg cursor-pointer"
                    >
                      <div>
                        <p className="font-medium text-sm">Email Notifications</p>
                        <p className="text-xs text-muted-foreground">Get notified of new emails</p>
                      </div>
                      <div className={`w-10 h-6 rounded-full relative transition-colors ${emailNotifications ? 'bg-primary' : 'bg-muted'}`}>
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${emailNotifications ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Appearance Section */}
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Appearance
                  </h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-card border border-border rounded-lg">
                      <p className="font-medium text-sm mb-3">Theme</p>
                      <div className="grid grid-cols-3 gap-2">
                        <button 
                          onClick={() => setTheme('light')}
                          className={`p-3 rounded-lg text-center text-xs font-medium transition-all ${theme === 'light' ? 'bg-white border-2 border-primary text-black' : 'bg-card border border-border hover:bg-accent'}`}
                        >
                          <Sun className="w-6 h-6 mx-auto mb-1 text-yellow-500" />
                          Light
                        </button>
                        <button 
                          onClick={() => setTheme('dark')}
                          className={`p-3 rounded-lg text-center text-xs font-medium transition-all ${theme === 'dark' ? 'bg-zinc-900 border-2 border-primary text-white' : 'bg-card border border-border hover:bg-accent'}`}
                        >
                          <Moon className="w-6 h-6 mx-auto mb-1 text-blue-400" />
                          Dark
                        </button>
                        <button 
                          onClick={() => setTheme('system')}
                          className={`p-3 rounded-lg text-center text-xs font-medium transition-all ${theme === 'system' ? 'bg-muted border-2 border-primary' : 'bg-card border border-border hover:bg-accent'}`}
                        >
                          <Monitor className="w-6 h-6 mx-auto mb-1" />
                          System
                        </button>
                      </div>
                    </div>
                    <div 
                      onClick={() => {
                        const newVal = !compactMode;
                        setCompactMode(newVal);
                        localStorage.setItem('compactMode', String(newVal));
                      }}
                      className="flex items-center justify-between p-3 bg-card border border-border rounded-lg cursor-pointer"
                    >
                      <div>
                        <p className="font-medium text-sm">Compact Mode</p>
                        <p className="text-xs text-muted-foreground">Reduce spacing in lists</p>
                      </div>
                      <div className={`w-10 h-6 rounded-full relative transition-colors ${compactMode ? 'bg-primary' : 'bg-muted'}`}>
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${compactMode ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Connected Services Section */}
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Wifi className="w-4 h-4" />
                    Connected Services
                  </h3>
                  <div className="space-y-2">
                    {services && services.length > 0 ? (
                      services.map((s: any) => {
                        const network = SOCIAL_NETWORKS.find(n => n.id === s.serviceName.toLowerCase());
                        const IconComp = network?.icon || Globe;
                        return (
                          <div key={s.id} className="flex items-center justify-between p-3 bg-card border border-border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${network?.color || 'bg-zinc-100'}`}>
                                <IconComp className="w-4 h-4" />
                              </div>
                              <span className="font-medium text-sm">{network?.name || s.serviceName}</span>
                            </div>
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">No services connected</p>
                    )}
                    <button
                      onClick={() => { setIsSettingsOpen(false); setCurrentView("services"); }}
                      className="w-full p-3 border-2 border-dashed border-border rounded-lg text-sm text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                      data-testid="button-manage-services"
                    >
                      + Manage Connected Services
                    </button>
                  </div>
                </div>

                {/* Account Section */}
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Account
                  </h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-card border border-border rounded-lg">
                      <p className="font-medium text-sm">Email</p>
                      <p className="text-sm text-muted-foreground">{userEmail}</p>
                    </div>
                    <div className="p-3 bg-card border border-border rounded-lg">
                      <p className="font-medium text-sm">Member Since</p>
                      <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString([], { year: 'numeric', month: 'long' })}</p>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center justify-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400 font-medium text-sm hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
                      data-testid="button-logout-settings"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                </div>

                {/* About Section */}
                <div className="text-center py-4 border-t border-border">
                  <p className="text-sm font-medium">TimesZapp</p>
                  <p className="text-xs text-muted-foreground">Powered by Minutz AI</p>
                  <p className="text-xs text-muted-foreground mt-1">Version 1.0.0</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Voice Cloning Modal */}
      <AnimatePresence>
        {isVoiceCloneOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => !isRecordingVoice && !isVoiceCloning && setIsVoiceCloneOpen(false)}
          >
            <motion.div
              onClick={(e) => e.stopPropagation()}
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-background border border-border rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-xl"
              data-testid="voice-clone-modal"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <AudioLines className="w-5 h-5 text-primary" />
                  {voiceCloneStatus.hasClonedVoice ? 'My Cloned Voice' : 'Clone Your Voice'}
                </h2>
                <button
                  onClick={() => !isRecordingVoice && !isVoiceCloning && setIsVoiceCloneOpen(false)}
                  className="p-2 hover:bg-accent rounded-full transition-colors"
                  data-testid="button-close-voice-clone"
                  disabled={isRecordingVoice || isVoiceCloning}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
                {!voiceCloneStatus.configured ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mx-auto mb-4">
                      <AlertCircle className="w-8 h-8 text-amber-600 dark:text-amber-400" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Setup Required</h3>
                    <p className="text-muted-foreground mb-4">
                      Voice cloning requires an ElevenLabs API key. Get one free at elevenlabs.io
                    </p>
                    <a
                      href="https://elevenlabs.io"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity"
                    >
                      Get API Key
                      <Globe className="w-4 h-4" />
                    </a>
                  </div>
                ) : voiceCloneStatus.validationError ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center mx-auto mb-4">
                      <AlertCircle className="w-8 h-8 text-red-500" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">API Key Issue</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {voiceCloneStatus.validationError}
                    </p>
                    <p className="text-xs text-muted-foreground mb-6">
                      Voice cloning requires a valid ElevenLabs API key. Please check your key in the Secrets tab.
                    </p>
                    <a
                      href="https://elevenlabs.io/app/settings/api-keys"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity"
                    >
                      Get New API Key
                      <Globe className="w-4 h-4" />
                    </a>
                  </div>
                ) : voiceCloneStatus.apiKeyValid && voiceCloneStatus.canClone === false ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-900/20 flex items-center justify-center mx-auto mb-4">
                      <AlertCircle className="w-8 h-8 text-amber-500" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Upgrade Required</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Voice cloning is a premium feature that requires an ElevenLabs paid subscription.
                    </p>
                    <p className="text-xs text-muted-foreground mb-6">
                      Your current plan is free. Upgrade to Starter ($5/mo), Creator ($22/mo), or higher to unlock voice cloning.
                    </p>
                    <a
                      href="https://elevenlabs.io/app/subscription"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity"
                    >
                      View Plans
                      <Globe className="w-4 h-4" />
                    </a>
                  </div>
                ) : voiceCloneStatus.hasClonedVoice ? (
                  <div className="text-center py-6">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                      <AudioLines className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold mb-1">{voiceCloneStatus.voiceName}</h3>
                    <p className="text-muted-foreground mb-6">Your cloned voice is active</p>
                    
                    <div className="space-y-3">
                      <button
                        onClick={() => {
                          speak("Hello! This is how I sound with your cloned voice.");
                        }}
                        className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                        data-testid="button-test-cloned-voice"
                      >
                        <Play className="w-5 h-5" />
                        Test My Voice
                      </button>
                      <button
                        onClick={deleteVoiceClone}
                        className="w-full py-3 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg font-medium hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center justify-center gap-2"
                        data-testid="button-delete-voice-clone"
                      >
                        <Trash2 className="w-5 h-5" />
                        Delete Voice Clone
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Instructions */}
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <Mic className="w-8 h-8 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">Read the paragraph below</h3>
                      <p className="text-sm text-muted-foreground">
                        Press record and read the text clearly. The longer and clearer, the better!
                      </p>
                    </div>

                    {/* Sample paragraph to read */}
                    <div className="p-4 bg-zinc-50 dark:bg-zinc-800/50 rounded-xl border border-border">
                      <p className="text-sm leading-relaxed">
                        "The quick brown fox jumps over the lazy dog. Every morning, I wake up with a sense of purpose and determination. Technology has transformed the way we communicate, work, and live our daily lives. From the mountains to the oceans, our planet offers countless wonders to explore. Music has the power to evoke emotions, bring people together, and create lasting memories. In times of challenge, we discover our true strength and resilience. The future belongs to those who believe in the beauty of their dreams."
                      </p>
                    </div>

                    {voiceCloneError && (
                      <div className="p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-sm flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {voiceCloneError}
                      </div>
                    )}

                    {/* Recording controls */}
                    {!voiceRecordingBlob && !isRecordingVoice && (
                      <button
                        onClick={startVoiceRecording}
                        className="w-full py-4 bg-primary text-primary-foreground rounded-xl font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-3 text-lg"
                        data-testid="button-start-voice-recording"
                      >
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                          <Mic className="w-5 h-5" />
                        </div>
                        Start Recording
                      </button>
                    )}

                    {isRecordingVoice && (
                      <div className="space-y-4">
                        <div className="flex flex-col items-center justify-center p-6 bg-red-50 dark:bg-red-900/20 rounded-xl">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse" />
                            <span className="text-red-600 dark:text-red-400 font-medium">Recording...</span>
                          </div>
                          <span className="font-mono text-3xl font-bold text-red-600 dark:text-red-400">
                            {formatRecordingTime(voiceRecordingTime)}
                          </span>
                          <p className="text-xs text-red-500 dark:text-red-400 mt-2">
                            {voiceRecordingTime < 30 ? 'Keep reading for better results!' : 'Looking good! Keep going or stop when ready.'}
                          </p>
                        </div>
                        <button
                          onClick={stopVoiceRecording}
                          className="w-full py-4 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 transition-colors flex items-center justify-center gap-3 text-lg"
                          data-testid="button-stop-voice-recording"
                        >
                          <MicOff className="w-6 h-6" />
                          Stop Recording
                        </button>
                      </div>
                    )}

                    {voiceRecordingBlob && !isRecordingVoice && (
                      <div className="space-y-4">
                        <div className="p-4 bg-zinc-100 dark:bg-zinc-800 rounded-xl">
                          <div className="flex items-center gap-3 mb-3">
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                            <span className="font-medium">Recording complete ({formatRecordingTime(voiceRecordingTime)})</span>
                          </div>
                          <audio 
                            controls 
                            src={URL.createObjectURL(voiceRecordingBlob)} 
                            className="w-full h-12"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            onClick={cancelVoiceRecording}
                            className="py-3 border border-border rounded-xl font-medium hover:bg-accent transition-colors"
                            data-testid="button-cancel-voice-recording"
                          >
                            Try Again
                          </button>
                          <button
                            onClick={submitVoiceClone}
                            disabled={isVoiceCloning}
                            className="py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
                            data-testid="button-submit-voice-clone"
                          >
                            {isVoiceCloning ? (
                              <>
                                <RefreshCw className="w-5 h-5 animate-spin" />
                                Cloning...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-5 h-5" />
                                Clone Voice
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
