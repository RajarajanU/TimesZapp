import { motion } from "framer-motion";
import { Activity, Smile, Brain, Wifi } from "lucide-react";

export function StatusMonitor() {
  return (
    <div className="glass-panel rounded-xl p-4 space-y-6 w-full h-full">
      <h3 className="font-display text-primary tracking-wider text-sm uppercase border-b border-white/10 pb-2 mb-4">
        Biometric & System Link
      </h3>

      {/* Facial Analysis Simulation */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-2"><Smile className="w-3 h-3" /> EMOTION SCAN</span>
          <span className="text-primary">CALM</span>
        </div>
        <div className="relative h-24 bg-black/50 rounded-lg overflow-hidden border border-white/5">
           {/* Simulated Grid Overlay */}
           <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 gap-1 opacity-20">
             {Array.from({ length: 24 }).map((_, i) => (
               <div key={i} className="border border-primary/30"></div>
             ))}
           </div>
           {/* Scanning Line */}
           <div className="scan-line absolute top-0 w-full"></div>
           
           {/* Face markers simulation */}
           <motion.div 
             className="absolute top-1/2 left-1/2 w-12 h-12 border border-primary rounded-sm -translate-x-1/2 -translate-y-1/2"
             animate={{ 
               borderColor: ["rgba(34, 211, 238, 0.3)", "rgba(34, 211, 238, 1)", "rgba(34, 211, 238, 0.3)"],
             }}
             transition={{ duration: 2, repeat: Infinity }}
           >
             <div className="absolute -top-1 -left-1 w-2 h-2 border-t border-l border-primary"></div>
             <div className="absolute -top-1 -right-1 w-2 h-2 border-t border-r border-primary"></div>
             <div className="absolute -bottom-1 -left-1 w-2 h-2 border-b border-l border-primary"></div>
             <div className="absolute -bottom-1 -right-1 w-2 h-2 border-b border-r border-primary"></div>
           </motion.div>
        </div>
      </div>

      {/* Audio Spectrum Simulation */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-2"><Activity className="w-3 h-3" /> VOICE SPECTRUM</span>
          <span className="text-primary">ACTIVE</span>
        </div>
        <div className="flex items-end justify-between h-12 gap-1">
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="w-full bg-primary/50 rounded-t-sm"
              animate={{
                height: [
                  `${Math.random() * 30 + 10}%`,
                  `${Math.random() * 80 + 20}%`,
                  `${Math.random() * 30 + 10}%`
                ]
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                repeatType: "mirror",
                delay: i * 0.05
              }}
            />
          ))}
        </div>
      </div>

      {/* System Load */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-2"><Brain className="w-3 h-3" /> NEURAL LOAD</span>
          <span className="font-mono text-secondary">42 TB/s</span>
        </div>
        <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-secondary"
            animate={{ width: ["30%", "60%", "45%", "70%"] }}
            transition={{ duration: 4, repeat: Infinity }}
          />
        </div>
      </div>
      
      <div className="pt-4 flex items-center justify-between text-[10px] font-mono text-muted-foreground border-t border-white/10">
         <span className="flex items-center gap-1"><Wifi className="w-3 h-3 text-green-500" /> ONLINE</span>
         <span>LATENCY: 2ms</span>
      </div>

    </div>
  );
}
