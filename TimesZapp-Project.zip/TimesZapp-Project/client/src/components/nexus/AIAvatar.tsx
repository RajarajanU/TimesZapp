import { motion } from "framer-motion";
import aiCoreImage from "@assets/generated_images/futuristic_abstract_ai_core_visualization_with_glowing_neural_networks.png";

export function AIAvatar({ state = "idle" }: { state?: "idle" | "listening" | "processing" | "speaking" }) {
  return (
    <div className="relative w-64 h-64 flex items-center justify-center">
      {/* Core Image Backdrop with Pulse */}
      <motion.div
        className="absolute inset-0 rounded-full opacity-50 mix-blend-screen"
        animate={{
          scale: [1, 1.05, 1],
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <img src={aiCoreImage} alt="AI Core" className="w-full h-full object-cover rounded-full blur-sm" />
      </motion.div>

      {/* Central Orb */}
      <motion.div
        className="relative z-10 w-32 h-32 rounded-full bg-black flex items-center justify-center border border-primary/30 box-shadow-lg"
        style={{ boxShadow: "0 0 30px theme('colors.primary')" }}
        animate={
          state === "processing"
            ? { rotate: 360, scale: [1, 1.1, 1] }
            : state === "listening"
            ? { scale: [1, 1.05, 1] }
            : { rotate: 0 }
        }
        transition={{
          rotate: { duration: 2, repeat: Infinity, ease: "linear" },
          scale: { duration: 1, repeat: Infinity, ease: "easeInOut" },
        }}
      >
        <div className="absolute inset-0 rounded-full border-2 border-primary/50 border-t-transparent animate-spin" />
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 backdrop-blur-md flex items-center justify-center">
             <div className="w-16 h-16 rounded-full bg-primary/10 shadow-[0_0_20px_theme('colors.primary')]"></div>
        </div>
      </motion.div>

      {/* Orbital Rings */}
      {[1, 2, 3].map((i) => (
        <motion.div
          key={i}
          className="absolute border border-primary/20 rounded-full"
          style={{
            width: `${100 + i * 40}%`,
            height: `${100 + i * 40}%`,
          }}
          animate={{
            rotate: i % 2 === 0 ? 360 : -360,
            scale: [1, 1.02, 1],
          }}
          transition={{
            rotate: { duration: 10 + i * 5, repeat: Infinity, ease: "linear" },
            scale: { duration: 3, repeat: Infinity, ease: "easeInOut", delay: i },
          }}
        />
      ))}

      {/* Status Text */}
      <motion.div 
        className="absolute -bottom-12 font-mono text-primary text-sm tracking-[0.2em]"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        {state.toUpperCase()}
      </motion.div>
    </div>
  );
}
