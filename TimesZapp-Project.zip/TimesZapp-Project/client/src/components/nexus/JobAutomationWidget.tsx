import { motion } from "framer-motion";
import { Briefcase, CheckCircle, Loader2, Building } from "lucide-react";
import { useState, useEffect } from "react";

export function JobAutomationWidget({ isActive }: { isActive: boolean }) {
  const [steps, setSteps] = useState([
    { id: 1, text: "Analyzing Resume", status: "pending" },
    { id: 2, text: "Matching Skills", status: "pending" },
    { id: 3, text: "Generating Cover Letter", status: "pending" },
    { id: 4, text: "Submitting Application", status: "pending" },
  ]);

  useEffect(() => {
    if (isActive) {
      setSteps(s => s.map(step => ({ ...step, status: "pending" })));
      
      let currentStep = 0;
      const interval = setInterval(() => {
        if (currentStep >= 4) {
           clearInterval(interval);
           return;
        }
        
        setSteps(prev => prev.map((s, idx) => {
          if (idx === currentStep) return { ...s, status: "active" };
          if (idx < currentStep) return { ...s, status: "complete" };
          return s;
        }));
        
        currentStep++;
      }, 1500);

      return () => clearInterval(interval);
    }
  }, [isActive]);

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="glass-panel rounded-xl p-4 border-l-4 border-l-secondary"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-secondary/20 rounded-lg text-secondary">
          <Building className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-foreground">Applying to Senior Frontend Engineer</h3>
          <p className="text-xs text-muted-foreground">Google Inc. • Remote</p>
        </div>
      </div>

      <div className="space-y-3">
        {steps.map((step) => (
          <div key={step.id} className="flex items-center gap-3">
            <div className="w-5 flex justify-center">
               {step.status === "complete" && <CheckCircle className="w-4 h-4 text-green-500" />}
               {step.status === "active" && <Loader2 className="w-4 h-4 text-secondary animate-spin" />}
               {step.status === "pending" && <div className="w-2 h-2 rounded-full bg-white/10" />}
            </div>
            <span className={`text-xs font-mono ${
              step.status === "active" ? "text-secondary neon-text-secondary" : 
              step.status === "complete" ? "text-muted-foreground line-through" : "text-muted-foreground"
            }`}>
              {step.text}...
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
