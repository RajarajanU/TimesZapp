import { Send, Mic, Paperclip } from "lucide-react";
import { useState } from "react";

export function CommandBar({ onCommand }: { onCommand: (cmd: string) => void }) {
  const [input, setInput] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onCommand(input);
      setInput("");
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto relative">
      <div className="absolute -inset-0.5 bg-gradient-to-r from-primary via-secondary to-primary rounded-xl opacity-30 blur transition duration-1000 group-hover:opacity-100 animate-pulse"></div>
      <form onSubmit={handleSubmit} className="relative flex items-center glass-panel rounded-xl px-4 py-3">
        <button type="button" className="p-2 text-primary/70 hover:text-primary transition-colors">
          <Paperclip className="w-5 h-5" />
        </button>
        
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Command Nexus AI..."
          className="flex-1 bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground font-sans text-lg px-4"
        />
        
        <button type="button" className="p-2 text-primary/70 hover:text-primary transition-colors mr-2">
          <Mic className="w-5 h-5" />
        </button>
        
        <button 
          type="submit" 
          className="p-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition-colors border border-primary/30"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
}
