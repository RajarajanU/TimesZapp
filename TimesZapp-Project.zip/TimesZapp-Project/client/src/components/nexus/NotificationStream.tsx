import { motion, AnimatePresence } from "framer-motion";
import { Mail, MessageSquare, Briefcase, Bell } from "lucide-react";

interface Notification {
  id: string;
  type: "mail" | "message" | "job" | "system";
  title: string;
  desc: string;
  time: string;
}

export function NotificationStream({ items }: { items: Notification[] }) {
  return (
    <div className="glass-panel rounded-xl p-4 h-full overflow-hidden flex flex-col">
      <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-2">
        <h3 className="font-display text-primary tracking-wider text-sm uppercase">
          Data Stream
        </h3>
        <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded font-mono">LIVE</span>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent">
        <AnimatePresence mode="popLayout">
          {items.map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              layout
              className="bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg p-3 cursor-pointer group transition-colors"
            >
              <div className="flex items-start gap-3">
                <div className={`mt-1 p-1.5 rounded-md ${
                  item.type === 'mail' ? 'bg-blue-500/20 text-blue-400' :
                  item.type === 'job' ? 'bg-purple-500/20 text-purple-400' :
                  item.type === 'message' ? 'bg-green-500/20 text-green-400' :
                  'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {item.type === 'mail' && <Mail className="w-4 h-4" />}
                  {item.type === 'message' && <MessageSquare className="w-4 h-4" />}
                  {item.type === 'job' && <Briefcase className="w-4 h-4" />}
                  {item.type === 'system' && <Bell className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h4 className="text-sm font-medium text-foreground truncate group-hover:text-primary transition-colors">
                      {item.title}
                    </h4>
                    <span className="text-[10px] font-mono text-muted-foreground">{item.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{item.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
