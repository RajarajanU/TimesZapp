import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";

interface MinutzClockAvatarProps {
  state: "idle" | "listening" | "processing" | "speaking";
  isMuted?: boolean;
  className?: string;
}

export function MinutzClockAvatar({ state, isMuted = false, className = "" }: MinutzClockAvatarProps) {
  const [time, setTime] = useState(new Date());
  const [blinkState, setBlinkState] = useState(false);
  const [mouthOpen, setMouthOpen] = useState(0);
  const mouthAnimationRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  
  useEffect(() => {
    const blinkTimer = setInterval(() => {
      setBlinkState(true);
      setTimeout(() => setBlinkState(false), 150);
    }, 3000 + Math.random() * 2000);
    return () => clearInterval(blinkTimer);
  }, []);
  
  useEffect(() => {
    if (state === "speaking") {
      mouthAnimationRef.current = setInterval(() => {
        setMouthOpen(prev => prev === 0 ? 1 : prev === 1 ? 0.5 : 0);
      }, 100);
    } else {
      if (mouthAnimationRef.current) {
        clearInterval(mouthAnimationRef.current);
        mouthAnimationRef.current = null;
      }
      setMouthOpen(0);
    }
    return () => {
      if (mouthAnimationRef.current) {
        clearInterval(mouthAnimationRef.current);
      }
    };
  }, [state]);
  
  const hours = time.getHours() % 12;
  const minutes = time.getMinutes();
  
  // Calculate clock hand positions - hands point from center outward
  const hourAngle = (hours * 30) + (minutes * 0.5) - 90; // -90 to start from 12 o'clock
  const minuteAngle = (minutes * 6) - 90;
  
  // Calculate hand end points
  const hourHandLength = 35;
  const minuteHandLength = 50;
  
  const hourX = 100 + hourHandLength * Math.cos(hourAngle * Math.PI / 180);
  const hourY = 100 + hourHandLength * Math.sin(hourAngle * Math.PI / 180);
  
  const minuteX = 100 + minuteHandLength * Math.cos(minuteAngle * Math.PI / 180);
  const minuteY = 100 + minuteHandLength * Math.sin(minuteAngle * Math.PI / 180);
  
  const eyeScaleY = blinkState ? 0.1 : 1;
  const pupilOffsetX = state === "listening" ? 3 : state === "processing" ? -2 : 0;

  return (
    <div className={`relative ${className}`}>
      <motion.div
        className="relative"
        animate={{
          scale: state === "speaking" ? [1, 1.03, 1] : 1,
        }}
        transition={{
          duration: 0.3,
          repeat: state === "speaking" ? Infinity : 0,
        }}
      >
        <svg 
          viewBox="0 0 200 200" 
          className="w-full h-full"
        >
          <defs>
            <radialGradient id="clockFaceGradient" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFB347" />
              <stop offset="100%" stopColor="#FF8C00" />
            </radialGradient>
            <filter id="cartoonShadow">
              <feDropShadow dx="2" dy="4" stdDeviation="2" floodColor="#000" floodOpacity="0.3"/>
            </filter>
          </defs>
          
          {/* Main clock face - orange/yellow */}
          <circle 
            cx="100" 
            cy="100" 
            r="90" 
            fill="url(#clockFaceGradient)" 
            stroke="#222" 
            strokeWidth="4"
            filter="url(#cartoonShadow)"
          />
          
          {/* Clock tick marks */}
          {[...Array(12)].map((_, i) => {
            const angle = (i * 30 - 90) * (Math.PI / 180);
            const x1 = 100 + 72 * Math.cos(angle);
            const y1 = 100 + 72 * Math.sin(angle);
            const x2 = 100 + 82 * Math.cos(angle);
            const y2 = 100 + 82 * Math.sin(angle);
            return (
              <line
                key={i}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke="#222"
                strokeWidth={i % 3 === 0 ? "3" : "2"}
                strokeLinecap="round"
              />
            );
          })}
          
          {/* Left eye */}
          <g>
            <ellipse
              cx="65"
              cy="80"
              rx="18"
              ry="22"
              fill="white"
              stroke="#222"
              strokeWidth="2"
            />
            <path d="M50 63 L54 56 M56 60 L58 53 M62 59 L65 52" stroke="#222" strokeWidth="2" strokeLinecap="round" />
            <motion.ellipse
              cx={65 + pupilOffsetX}
              cy="83"
              rx="9"
              ry="12"
              fill="#222"
              animate={{ 
                scaleY: eyeScaleY,
                cx: state === "processing" ? [62, 68, 62] : 65 + pupilOffsetX
              }}
              transition={{
                scaleY: { duration: 0.1 },
                cx: { duration: 0.8, repeat: state === "processing" ? Infinity : 0 }
              }}
              style={{ transformOrigin: "65px 83px" }}
            />
            <circle cx={61 + pupilOffsetX} cy="78" r="3" fill="white" opacity="0.9" />
          </g>
          
          {/* Right eye */}
          <g>
            <ellipse
              cx="135"
              cy="80"
              rx="18"
              ry="22"
              fill="white"
              stroke="#222"
              strokeWidth="2"
            />
            <path d="M150 63 L146 56 M144 60 L142 53 M138 59 L135 52" stroke="#222" strokeWidth="2" strokeLinecap="round" />
            <motion.ellipse
              cx={135 + pupilOffsetX}
              cy="83"
              rx="9"
              ry="12"
              fill="#222"
              animate={{ 
                scaleY: eyeScaleY,
                cx: state === "processing" ? [132, 138, 132] : 135 + pupilOffsetX
              }}
              transition={{
                scaleY: { duration: 0.1 },
                cx: { duration: 0.8, repeat: state === "processing" ? Infinity : 0 }
              }}
              style={{ transformOrigin: "135px 83px" }}
            />
            <circle cx={131 + pupilOffsetX} cy="78" r="3" fill="white" opacity="0.9" />
          </g>
          
          {/* Hour hand - drawn on TOP of eyes */}
          <line
            x1="100"
            y1="100"
            x2={hourX}
            y2={hourY}
            stroke="#222"
            strokeWidth="6"
            strokeLinecap="round"
          />
          
          {/* Minute hand - drawn on TOP of eyes */}
          <line
            x1="100"
            y1="100"
            x2={minuteX}
            y2={minuteY}
            stroke="#222"
            strokeWidth="4"
            strokeLinecap="round"
          />
          
          {/* Center dot */}
          <circle cx="100" cy="100" r="6" fill="#222" />
          
          {/* Mouth */}
          <motion.path
            d={
              mouthOpen === 1
                ? "M 70 145 Q 100 175 130 145"
                : mouthOpen === 0.5
                ? "M 75 145 Q 100 160 125 145"
                : state === "listening"
                ? "M 80 145 Q 100 155 120 145"
                : "M 85 145 Q 100 152 115 145"
            }
            fill="none"
            stroke="#222"
            strokeWidth="4"
            strokeLinecap="round"
          />
          
          {/* Open mouth interior when speaking */}
          {state === "speaking" && mouthOpen > 0 && (
            <motion.ellipse
              cx="100"
              cy={150 + mouthOpen * 5}
              rx={15 + mouthOpen * 8}
              ry={5 + mouthOpen * 10}
              fill="#8B0000"
              stroke="#222"
              strokeWidth="2"
            />
          )}
        </svg>
      </motion.div>
    </div>
  );
}
