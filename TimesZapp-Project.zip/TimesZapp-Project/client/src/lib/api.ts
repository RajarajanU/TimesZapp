// Use relative paths that work both locally and on Replit
const API_BASE = typeof window !== "undefined" && window.location.origin 
  ? `${window.location.origin}/api`
  : "/api";

export const DEMO_USER_ID = 1;

export function getCurrentUserId(): number | null {
  const token = localStorage.getItem("token");
  if (!token) return null;
  try {
    const decoded = JSON.parse(atob(token));
    return decoded.userId;
  } catch {
    return null;
  }
}

export function getCurrentUserEmail(): string | null {
  return localStorage.getItem("userEmail");
}

export interface Attachment {
  name: string;
  url: string;
  mime: string;
  size: number;
  uploadedAt: string;
}

export interface ChatRequest {
  userId: number;
  conversationId?: number;
  message: string;
  attachments?: Attachment[];
  timezone?: string;
  deviceTime?: string;
  battery?: { level: number; charging: boolean } | null;
  location?: { latitude: number; longitude: number } | null;
}

export interface ChatResponse {
  conversationId: number;
  message: {
    id: number;
    content: string;
    role: string;
    metadata?: any;
    timestamp: string;
  };
  intent?: string;
}

export interface Notification {
  id: number;
  source: string;
  type: string;
  title: string;
  description: string | null;
  isRead: boolean;
  receivedAt: string;
}

async function fetchWithTimeout(url: string, options: RequestInit, timeout = 60000): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

export const api = {
  async fastVoiceChat(message: string, userName?: string): Promise<{ content: string }> {
    const response = await fetchWithTimeout(`${API_BASE}/voice/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, userName }),
    }, 12000);
    
    if (!response.ok) {
      throw new Error(`Voice chat failed: ${response.status}`);
    }
    
    return response.json();
  },

  streamVoiceChat(message: string, userName?: string, callbacks?: {
    onChunk?: (chunk: string) => void;
    onComplete?: (fullResponse: string) => void;
    onError?: (error: string) => void;
  }): () => void {
    const url = new URL(`${window.location.origin}/api/voice/stream`);
    url.searchParams.set('message', message);
    if (userName) url.searchParams.set('userName', userName);
    
    const eventSource = new EventSource(url.toString());
    let fullResponse = '';
    
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'chunk') {
          fullResponse += data.chunk;
          callbacks?.onChunk?.(data.chunk);
        } else if (data.type === 'done') {
          callbacks?.onComplete?.(data.content || fullResponse);
          eventSource.close();
        } else if (data.type === 'error') {
          callbacks?.onError?.(data.error);
          eventSource.close();
        }
      } catch (e) {
        console.error('[StreamVoice] Parse error:', e);
      }
    };
    
    eventSource.onerror = () => {
      if (fullResponse) {
        callbacks?.onComplete?.(fullResponse);
      } else {
        callbacks?.onError?.('Stream connection failed');
      }
      eventSource.close();
    };
    
    // Return cleanup function
    return () => {
      eventSource.close();
    };
  },

  async sendMessage(request: ChatRequest): Promise<ChatResponse> {
    console.log("Sending chat request:", request);
    
    try {
      const response = await fetchWithTimeout(`${API_BASE}/chat`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify(request),
      });
      
      console.log("Chat response status:", response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Chat API error:", errorText);
        throw new Error(`Failed to send message: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Chat response data:", data);
      return data;
    } catch (error) {
      console.error("Chat request failed:", error);
      throw error;
    }
  },

  async getConversations(userId: number) {
    const response = await fetch(`${API_BASE}/conversations/${userId}`);
    if (!response.ok) {
      throw new Error("Failed to fetch conversations");
    }
    return response.json();
  },

  async getMessages(conversationId: number) {
    const response = await fetch(`${API_BASE}/conversations/${conversationId}/messages`);
    if (!response.ok) {
      throw new Error("Failed to fetch messages");
    }
    return response.json();
  },

  async getNotifications(userId: number, limit?: number) {
    const url = `${API_BASE}/notifications/${userId}${limit ? `?limit=${limit}` : ""}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Failed to fetch notifications");
    }
    return response.json();
  },

  async markNotificationAsRead(id: number) {
    const response = await fetch(`${API_BASE}/notifications/${id}/read`, {
      method: "PATCH",
    });
    if (!response.ok) {
      throw new Error("Failed to mark notification as read");
    }
    return response.json();
  },

  async getInsights(userId: number, limit?: number) {
    const url = `${API_BASE}/insights/${userId}${limit ? `?limit=${limit}` : ""}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Failed to fetch insights");
    }
    return response.json();
  },

  async getTrends(userId: number) {
    const response = await fetch(`${API_BASE}/insights/${userId}/trends`);
    if (!response.ok) {
      throw new Error("Failed to fetch trends");
    }
    return response.json();
  },

  async getDigest(userId: number) {
    const response = await fetch(`${API_BASE}/insights/${userId}/digest`);
    if (!response.ok) {
      throw new Error("Failed to fetch digest");
    }
    return response.json();
  },

  async getTime() {
    const response = await fetch(`${API_BASE}/system/time`);
    if (!response.ok) {
      throw new Error("Failed to get time");
    }
    return response.json();
  },

  async getReminders(userId: number, includeCompleted?: boolean) {
    const url = `${API_BASE}/reminders/${userId}${includeCompleted ? '?includeCompleted=true' : ''}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Failed to fetch reminders");
    }
    return response.json();
  },

  async getDueReminders(userId: number) {
    const response = await fetch(`${API_BASE}/reminders/${userId}/due`);
    if (!response.ok) {
      throw new Error("Failed to fetch due reminders");
    }
    return response.json();
  },

  async createReminder(data: { userId: number; title: string; description?: string; remindAt: string; priority?: string; recurrence?: string }) {
    const response = await fetch(`${API_BASE}/reminders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      throw new Error("Failed to create reminder");
    }
    return response.json();
  },

  async completeReminder(id: number) {
    const response = await fetch(`${API_BASE}/reminders/${id}/complete`, {
      method: "PATCH",
    });
    if (!response.ok) {
      throw new Error("Failed to complete reminder");
    }
    return response.json();
  },

  async markReminderNotified(id: number) {
    const response = await fetch(`${API_BASE}/reminders/${id}/notified`, {
      method: "PATCH",
    });
    if (!response.ok) {
      throw new Error("Failed to mark reminder as notified");
    }
    return response.json();
  },

  async deleteReminder(id: number) {
    const response = await fetch(`${API_BASE}/reminders/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) {
      throw new Error("Failed to delete reminder");
    }
    return response.json();
  },

  async getTechNews(hours: number = 24) {
    const response = await fetch(`${API_BASE}/tech-news?hours=${hours}`);
    if (!response.ok) {
      throw new Error("Failed to fetch tech news");
    }
    return response.json();
  },

  async getCurrentTechNews() {
    const response = await fetch(`${API_BASE}/tech-news/current`);
    if (!response.ok) {
      throw new Error("Failed to fetch current tech news");
    }
    return response.json();
  },

  async fetchNewTechNews(topic?: string) {
    const response = await fetch(`${API_BASE}/tech-news/fetch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic }),
    });
    if (!response.ok) {
      throw new Error("Failed to fetch new tech news");
    }
    return response.json();
  },

  async getOrCreateUser(email: string, name?: string) {
    try {
      const response = await fetch(`${API_BASE}/users/${encodeURIComponent(email)}`);
      if (response.ok) {
        return response.json();
      }
    } catch (e) {
      console.log("User not found, creating new user");
    }

    const response = await fetch(`${API_BASE}/users`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, name }),
    });
    if (!response.ok) {
      throw new Error("Failed to create user");
    }
    return response.json();
  },

  async getServices(userId: number) {
    const response = await fetch(`${API_BASE}/services/${userId}`);
    if (!response.ok) {
      throw new Error("Failed to fetch services");
    }
    return response.json();
  },

  async addService(userId: number, serviceName: string) {
    try {
      console.log("[api.addService] Sending to:", `${API_BASE}/services`);
      const response = await fetch(`${API_BASE}/services`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, serviceName }),
      });
      console.log("[api.addService] Response status:", response.status);
      if (!response.ok) {
        const error = await response.text();
        console.error("[api.addService] Error response:", error);
        throw new Error(`Server error (${response.status}): ${error}`);
      }
      const data = await response.json();
      console.log("[api.addService] Success:", data);
      return data;
    } catch (error) {
      console.error("[api.addService] Fetch error:", error);
      throw error;
    }
  },

  async toggleService(id: number, isActive: boolean) {
    const response = await fetch(`${API_BASE}/services/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive }),
    });
    if (!response.ok) {
      throw new Error("Failed to update service");
    }
    return response.json();
  },

  async deleteService(id: number) {
    const response = await fetch(`${API_BASE}/services/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) {
      throw new Error("Failed to delete service");
    }
    return response.json();
  },

  // Gmail Integration (requires authentication)
  async getGmailStatus() {
    const token = localStorage.getItem("token");
    if (!token) {
      return { connected: false, error: "Not authenticated" };
    }
    const response = await fetch(`${API_BASE}/gmail/status`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      if (response.status === 401) {
        return { connected: false, error: "Authentication required" };
      }
      throw new Error("Failed to check Gmail status");
    }
    return response.json();
  },

  async getGmailStats() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail/stats`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      throw new Error("Failed to get Gmail stats");
    }
    return response.json();
  },

  async getGmailLabels() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail/labels`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      throw new Error("Failed to fetch Gmail labels");
    }
    return response.json();
  },

  async getGmailUnreadCount() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail/unread-count`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      throw new Error("Failed to get unread count");
    }
    return response.json();
  },

  // Gmail Full OAuth Integration (with email reading capability)
  async getGmailOAuthUrl() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail-oauth/auth-url`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      throw new Error("Failed to get Gmail auth URL");
    }
    return response.json();
  },

  async getGmailOAuthStatus() {
    const token = localStorage.getItem("token");
    if (!token) return { connected: false };
    const response = await fetch(`${API_BASE}/gmail-oauth/status`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      return { connected: false };
    }
    return response.json();
  },

  async getGmailEmails(limit: number = 20) {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail-oauth/emails?limit=${limit}`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      return { emails: [] };
    }
    return response.json();
  },

  async getGmailOAuthStats() {
    const token = localStorage.getItem("token");
    if (!token) return { totalInbox: 0, unread: 0, todayCount: 0 };
    const response = await fetch(`${API_BASE}/gmail-oauth/stats`, {
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    if (!response.ok) {
      return { totalInbox: 0, unread: 0, todayCount: 0 };
    }
    return response.json();
  },

  async disconnectGmailOAuth() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/gmail-oauth/disconnect`, {
      method: "POST",
      headers: { 
        "Authorization": `Bearer ${token}` 
      },
    });
    return response.json();
  },

  async signup(email: string, name: string, password: string) {
    const response = await fetch(`${API_BASE}/auth/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, name, password }),
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || "Signup failed");
    }
    const data = await response.json();
    localStorage.setItem("token", data.token);
    return data;
  },

  async login(email: string, password: string) {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || "Login failed");
    }
    const data = await response.json();
    localStorage.setItem("token", data.token);
    return data;
  },

  isLoggedIn() {
    return !!localStorage.getItem("token");
  },

  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("userEmail");
  },

  // Integration Status
  async getIntegrationsStatus() {
    const response = await fetch(`${API_BASE}/integrations/status`);
    if (!response.ok) {
      throw new Error("Failed to get integrations status");
    }
    return response.json();
  },

  // LinkedIn Integration
  async getLinkedInStatus() {
    const token = localStorage.getItem("token");
    if (!token) {
      return { connected: false, configured: false };
    }
    const response = await fetch(`${API_BASE}/linkedin/status`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      return { connected: false, configured: false };
    }
    return response.json();
  },

  async getLinkedInAuthUrl() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/linkedin/auth-url`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Failed to get LinkedIn auth URL");
    }
    return response.json();
  },

  async getLinkedInStats() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/linkedin/stats`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      throw new Error("Failed to get LinkedIn stats");
    }
    return response.json();
  },

  // Facebook Integration
  async getFacebookStatus() {
    const token = localStorage.getItem("token");
    if (!token) {
      return { connected: false, configured: false };
    }
    const response = await fetch(`${API_BASE}/facebook/status`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      return { connected: false, configured: false };
    }
    return response.json();
  },

  async getFacebookAuthUrl() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/facebook/auth-url`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Failed to get Facebook auth URL");
    }
    return response.json();
  },

  async getFacebookStats() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/facebook/stats`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      throw new Error("Failed to get Facebook stats");
    }
    return response.json();
  },

  // Instagram Integration
  async getInstagramStatus() {
    const token = localStorage.getItem("token");
    if (!token) {
      return { connected: false, configured: false };
    }
    const response = await fetch(`${API_BASE}/instagram/status`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      return { connected: false, configured: false };
    }
    return response.json();
  },

  async getInstagramAuthUrl() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/instagram/auth-url`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Failed to get Instagram auth URL");
    }
    return response.json();
  },

  async getInstagramStats() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/instagram/stats`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      throw new Error("Failed to get Instagram stats");
    }
    return response.json();
  },

  async getInstagramMedia() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    const response = await fetch(`${API_BASE}/instagram/media`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      throw new Error("Failed to get Instagram media");
    }
    return response.json();
  },

  // Voice Cloning (ElevenLabs)
  async getVoiceList(): Promise<{ voices: Array<{ voice_id: string; name: string; category: string; labels: any; preview_url?: string }> }> {
    const response = await fetch(`${API_BASE}/voice/list`);
    if (!response.ok) {
      return { voices: [] };
    }
    return response.json();
  },

  async getVoiceStatus() {
    const token = localStorage.getItem("token");
    if (!token) {
      return { configured: false, hasClonedVoice: false, voiceName: null, voiceId: null };
    }
    const response = await fetch(`${API_BASE}/voice/status`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) {
      return { configured: false, hasClonedVoice: false, voiceName: null, voiceId: null };
    }
    return response.json();
  },

  async cloneVoice(audioBlob: Blob, name?: string) {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const formData = new FormData();
    formData.append("audio", audioBlob, "voice_sample.webm");
    if (name) {
      formData.append("name", name);
    }
    
    const response = await fetch(`${API_BASE}/voice/clone`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: formData,
    });
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Failed to clone voice");
    }
    return data;
  },

  async deleteClonedVoice() {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/voice/clone`, {
      method: "DELETE",
      headers: { "Authorization": `Bearer ${token}` },
    });
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Failed to delete voice");
    }
    return data;
  },

  async textToSpeech(text: string, voiceId?: string): Promise<Blob | null> {
    const token = localStorage.getItem("token");
    if (!token) return null;
    
    // Use passed voiceId or get from localStorage
    const selectedVoice = voiceId || localStorage.getItem('selectedVoiceId') || undefined;
    
    const response = await fetch(`${API_BASE}/voice/tts`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text, voiceId: selectedVoice }),
    });
    
    if (!response.ok) {
      return null;
    }
    
    return response.blob();
  },

  async analyzeImage(imageData: string, silent: boolean = false): Promise<string> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetchWithTimeout(`${API_BASE}/vision/analyze`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ image: imageData, silent }),
    }, 30000);
    
    if (!response.ok) {
      throw new Error("Failed to analyze image");
    }
    
    const data = await response.json();
    return data.description;
  },

  // Friends API
  async getFriends(): Promise<{ id: number; name: string | null; email: string }[]> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) throw new Error("Failed to get friends");
    return response.json();
  },

  async getFriendRequests(): Promise<{ id: number; requesterId: number; requesterName: string | null; requesterEmail: string; createdAt: string }[]> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends/requests`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) throw new Error("Failed to get friend requests");
    return response.json();
  },

  async searchUsers(query: string): Promise<{ id: number; name: string | null; email: string }[]> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends/search?q=${encodeURIComponent(query)}`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) throw new Error("Failed to search users");
    return response.json();
  },

  async sendFriendRequest(friendId: number): Promise<void> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends/request`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ friendId }),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Failed to send friend request");
    }
  },

  async acceptFriendRequest(requestId: number): Promise<void> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends/accept/${requestId}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) throw new Error("Failed to accept friend request");
  },

  async declineFriendRequest(requestId: number): Promise<void> {
    const token = localStorage.getItem("token");
    if (!token) throw new Error("Not authenticated");
    
    const response = await fetch(`${API_BASE}/friends/decline/${requestId}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
    });
    if (!response.ok) throw new Error("Failed to decline friend request");
  },
};
