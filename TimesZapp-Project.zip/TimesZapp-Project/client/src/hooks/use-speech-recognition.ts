import { useState, useCallback, useRef, useEffect } from 'react';

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
  isFinal: boolean;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  abort(): void;
  onstart: (event: Event) => void;
  onend: (event: Event) => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: Event & { error: string }) => void;
}

declare global {
  interface Window {
    SpeechRecognition: {
      new (): SpeechRecognition;
    };
    webkitSpeechRecognition: {
      new (): SpeechRecognition;
    };
  }
}

interface SpeechRecognitionOptions {
  continuous?: boolean;
  onAutoEnd?: (transcript: string) => void;
  alwaysOn?: boolean;
  autoEndDelay?: number; // Delay in ms before calling onAutoEnd (default 1500ms)
}

export function useSpeechRecognition(options?: SpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(true);
  const [isAlwaysOnActive, setIsAlwaysOnActive] = useState(false);
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const lastFinalTranscriptRef = useRef<string>('');
  const onAutoEndRef = useRef(options?.onAutoEnd);
  const alwaysOnRef = useRef(false);
  const shouldRestartRef = useRef(false);
  const isManualStopRef = useRef(false);
  const autoEndTimerRef = useRef<NodeJS.Timeout | null>(null);
  const autoEndDelayRef = useRef(options?.autoEndDelay ?? 1500);
  const accumulatedTranscriptRef = useRef<string>('');
  
  useEffect(() => {
    onAutoEndRef.current = options?.onAutoEnd;
  }, [options?.onAutoEnd]);

  useEffect(() => {
    autoEndDelayRef.current = options?.autoEndDelay ?? 1500;
  }, [options?.autoEndDelay]);

  const restartRecognition = useCallback(() => {
    if (recognitionRef.current && alwaysOnRef.current && !isManualStopRef.current) {
      setTimeout(() => {
        if (alwaysOnRef.current && !isManualStopRef.current) {
          try {
            recognitionRef.current?.start();
            console.log('[Speech] Auto-restarting recognition (always-on mode)');
          } catch (e) {
            console.log('[Speech] Could not restart, will retry...');
            setTimeout(() => restartRecognition(), 500);
          }
        }
      }, 100);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onstart = () => {
        setIsListening(true);
        isManualStopRef.current = false;
        console.log('[Speech] Recognition started (continuous mode)');
      };
      
      recognitionInstance.onend = () => {
        setIsListening(false);
        console.log('[Speech] Recognition ended, alwaysOn:', alwaysOnRef.current, 'manualStop:', isManualStopRef.current);
        
        if (alwaysOnRef.current && !isManualStopRef.current) {
          restartRecognition();
        }
      };
      
      recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        const latestResultIndex = event.results.length - 1;
        const result = event.results[latestResultIndex];
        if (result) {
          const text = result[0].transcript;
          if (result.isFinal) {
            // Accumulate final transcripts for complete message
            if (accumulatedTranscriptRef.current) {
              accumulatedTranscriptRef.current += ' ' + text;
            } else {
              accumulatedTranscriptRef.current = text;
            }
            setFinalTranscript(accumulatedTranscriptRef.current);
            setInterimTranscript('');
            lastFinalTranscriptRef.current = accumulatedTranscriptRef.current;
            console.log('[Speech] Final transcript:', accumulatedTranscriptRef.current);
            
            // Clear any existing timer and set new one
            // This gives user time to continue speaking
            if (autoEndTimerRef.current) {
              clearTimeout(autoEndTimerRef.current);
            }
            
            if (onAutoEndRef.current) {
              const transcriptToSend = accumulatedTranscriptRef.current;
              autoEndTimerRef.current = setTimeout(() => {
                console.log('[Speech] Auto-end triggered after delay, sending:', transcriptToSend);
                if (onAutoEndRef.current) {
                  onAutoEndRef.current(transcriptToSend);
                }
                accumulatedTranscriptRef.current = '';
              }, autoEndDelayRef.current);
            }
          } else {
            setInterimTranscript(text);
            // User is still speaking, cancel any pending auto-end
            if (autoEndTimerRef.current) {
              clearTimeout(autoEndTimerRef.current);
              autoEndTimerRef.current = null;
            }
          }
        }
      };

      recognitionInstance.onerror = (event: Event & { error: string }) => {
        console.error('[Speech] Recognition error:', event.error);
        
        if (event.error === 'not-allowed') {
          setIsSupported(false);
          alwaysOnRef.current = false;
        } else if (event.error === 'no-speech' || event.error === 'aborted') {
          if (alwaysOnRef.current && !isManualStopRef.current) {
            restartRecognition();
          }
        }
        
        setIsListening(false);
      };

      recognitionRef.current = recognitionInstance;
    } else {
      setIsSupported(false);
    }

    return () => {
      alwaysOnRef.current = false;
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, [restartRecognition]);

  const startListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        isManualStopRef.current = false;
        setInterimTranscript('');
        setFinalTranscript('');
        lastFinalTranscriptRef.current = '';
        recognitionRef.current.start();
      } catch (e) {
        console.error("[Speech] Start error:", e);
      }
    }
  }, []);

  const stopListening = useCallback(() => {
    isManualStopRef.current = true;
    alwaysOnRef.current = false;
    setIsAlwaysOnActive(false);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
  }, []);

  const startAlwaysOn = useCallback(() => {
    if (recognitionRef.current) {
      try {
        isManualStopRef.current = false;
        alwaysOnRef.current = true;
        setIsAlwaysOnActive(true);
        setInterimTranscript('');
        setFinalTranscript('');
        lastFinalTranscriptRef.current = '';
        recognitionRef.current.start();
        console.log('[Speech] Always-on mode started');
      } catch (e) {
        console.error("[Speech] Start always-on error:", e);
        // Retry after a short delay
        setTimeout(() => {
          if (alwaysOnRef.current) {
            try {
              recognitionRef.current?.start();
            } catch (e2) {}
          }
        }, 200);
      }
    }
  }, []);

  const stopAlwaysOn = useCallback(() => {
    console.log('[Speech] Stopping always-on mode');
    isManualStopRef.current = true;
    alwaysOnRef.current = false;
    setIsAlwaysOnActive(false);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
  }, []);

  const pauseAlwaysOn = useCallback(() => {
    // Temporarily pause without disabling always-on mode
    isManualStopRef.current = true;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
  }, []);

  const resumeAlwaysOn = useCallback(() => {
    if (alwaysOnRef.current) {
      isManualStopRef.current = false;
      setInterimTranscript('');
      setFinalTranscript('');
      lastFinalTranscriptRef.current = '';
      accumulatedTranscriptRef.current = '';
      if (autoEndTimerRef.current) {
        clearTimeout(autoEndTimerRef.current);
        autoEndTimerRef.current = null;
      }
      try {
        recognitionRef.current?.start();
      } catch (e) {
        setTimeout(() => {
          try {
            recognitionRef.current?.start();
          } catch (e2) {}
        }, 200);
      }
    }
  }, []);

  const resetTranscript = useCallback(() => {
    setInterimTranscript('');
    setFinalTranscript('');
    lastFinalTranscriptRef.current = '';
    accumulatedTranscriptRef.current = '';
    if (autoEndTimerRef.current) {
      clearTimeout(autoEndTimerRef.current);
      autoEndTimerRef.current = null;
    }
  }, []);

  const displayTranscript = finalTranscript || interimTranscript;

  return { 
    isListening, 
    transcript: displayTranscript.trim(),
    fullTranscript: (finalTranscript || interimTranscript).trim(),
    finalTranscript: finalTranscript.trim(),
    startListening, 
    stopListening,
    startAlwaysOn,
    stopAlwaysOn,
    pauseAlwaysOn,
    resumeAlwaysOn,
    isAlwaysOnActive,
    resetTranscript,
    isSupported
  };
}
