import { useState, useCallback, useRef, useEffect } from 'react';

interface AudioCaptureOptions {
  onTranscript?: (transcript: string) => void;
  silenceTimeout?: number;
}

interface ListenResult {
  transcript: string;
  isStopCommand: boolean;
}

const STOP_WORDS = ['stop', 'pause', 'quiet', 'silence', 'shut up', 'be quiet', 'enough', 'okay stop', 'ok stop'];

function checkForStopCommand(text: string): boolean {
  const lower = text.toLowerCase().trim();
  return STOP_WORDS.some(word => lower.includes(word));
}

export function useAudioCapture(options?: AudioCaptureOptions) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(true);
  
  const recognitionRef = useRef<any>(null);
  const resolveRef = useRef<((result: ListenResult) => void) | null>(null);
  const silenceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const onTranscriptRef = useRef(options?.onTranscript);
  const isStartingRef = useRef(false);
  
  const silenceTimeout = options?.silenceTimeout ?? 2000;

  useEffect(() => {
    onTranscriptRef.current = options?.onTranscript;
  }, [options?.onTranscript]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.log('[Audio] Speech Recognition not supported');
      setIsSupported(false);
    }
    
    return () => {
      stopListening();
    };
  }, []);

  const stopListening = useCallback(() => {
    isStartingRef.current = false;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (e) {}
      recognitionRef.current = null;
    }
    setIsRecording(false);
    resolveRef.current = null;
  }, []);

  // Promise-based listen function - returns transcript when user stops speaking
  const listenOnce = useCallback((): Promise<ListenResult> => {
    return new Promise((resolve, reject) => {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        reject(new Error('Speech Recognition not supported'));
        return;
      }

      // Prevent double-start
      if (isStartingRef.current) {
        console.log('[Audio] Already starting, ignoring');
        resolve({ transcript: '', isStopCommand: false });
        return;
      }

      // Clean up any existing recognition
      stopListening();
      isStartingRef.current = true;

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;
      
      recognitionRef.current = recognition;
      resolveRef.current = resolve;
      setIsRecording(true);

      let finalText = '';

      recognition.onresult = (event: any) => {
        const result = event.results[0];
        if (result) {
          finalText = result[0].transcript.trim();
          
          if (result.isFinal) {
            console.log('[Audio] Final phrase:', finalText);
            
            // Clear any existing timer
            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
            }
            
            // Wait for silence before resolving
            silenceTimerRef.current = setTimeout(() => {
              const isStop = checkForStopCommand(finalText);
              console.log('[Audio] Resolving with:', finalText, 'isStop:', isStop);
              setTranscript(finalText);
              stopListening();
              resolve({ transcript: finalText, isStopCommand: isStop });
            }, silenceTimeout);
          }
        }
      };

      recognition.onerror = (event: any) => {
        console.log('[Audio] Recognition error:', event.error);
        if (event.error === 'no-speech') {
          // No speech detected, restart listening
          try {
            recognition.stop();
          } catch (e) {}
          return;
        }
        if (event.error === 'aborted') {
          return;
        }
        if (event.error === 'not-allowed') {
          setIsSupported(false);
          reject(new Error('Microphone access denied'));
          return;
        }
        // For other errors, try to continue
      };

      recognition.onend = () => {
        console.log('[Audio] Recognition ended');
        isStartingRef.current = false;
        // If we have a final result waiting, don't restart
        if (silenceTimerRef.current) {
          return;
        }
        // If still recording and no result yet, restart
        if (recognitionRef.current && resolveRef.current) {
          setTimeout(() => {
            if (recognitionRef.current && resolveRef.current && !isStartingRef.current) {
              isStartingRef.current = true;
              try {
                recognitionRef.current.start();
                console.log('[Audio] Restarted listening');
              } catch (e) {
                console.log('[Audio] Could not restart:', e);
                isStartingRef.current = false;
              }
            }
          }, 150);
        }
      };

      try {
        recognition.start();
        console.log('[Audio] Started listening');
      } catch (e: any) {
        console.error('[Audio] Failed to start:', e);
        isStartingRef.current = false;
        if (e?.message?.includes('already started')) {
          // Recognition already running, wait and retry
          setTimeout(() => {
            stopListening();
            resolve({ transcript: '', isStopCommand: false });
          }, 200);
        } else {
          reject(e);
        }
      }
    });
  }, [silenceTimeout, stopListening]);

  // Lightweight stop-word-only listener - resolves true when stop word heard
  const listenForStop = useCallback((): Promise<boolean> => {
    return new Promise((resolve) => {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        resolve(false);
        return;
      }

      // Prevent double-start
      if (isStartingRef.current) {
        console.log('[Audio] Already starting, skip stop listener');
        resolve(false);
        return;
      }

      // Clean up any existing recognition first
      stopListening();
      isStartingRef.current = true;

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;
      
      recognitionRef.current = recognition;
      setIsRecording(true);

      let resolved = false;

      recognition.onresult = (event: any) => {
        const result = event.results[0];
        if (result) {
          const text = result[0].transcript.trim();
          if (checkForStopCommand(text)) {
            console.log('[Audio] Stop command detected:', text);
            resolved = true;
            stopListening();
            resolve(true);
          }
        }
      };

      recognition.onerror = (event: any) => {
        console.log('[Audio] Stop listener error:', event.error);
        isStartingRef.current = false;
        if (event.error === 'no-speech' || event.error === 'aborted') {
          return;
        }
      };

      recognition.onend = () => {
        isStartingRef.current = false;
        if (resolved) return;
        // Restart to keep listening for stop commands
        if (recognitionRef.current) {
          setTimeout(() => {
            if (recognitionRef.current && !resolved && !isStartingRef.current) {
              isStartingRef.current = true;
              try {
                recognitionRef.current.start();
              } catch (e) {
                isStartingRef.current = false;
              }
            }
          }, 150);
        }
      };

      try {
        recognition.start();
        console.log('[Audio] Started stop listener');
      } catch (e: any) {
        console.error('[Audio] Failed to start stop listener:', e);
        isStartingRef.current = false;
        resolve(false);
      }
    });
  }, [stopListening]);

  const resetTranscript = useCallback(() => {
    setTranscript('');
  }, []);

  // Legacy API for compatibility
  const startRecording = useCallback(() => {
    listenOnce().then(result => {
      if (onTranscriptRef.current && result.transcript) {
        onTranscriptRef.current(result.transcript);
      }
    }).catch(e => {
      console.error('[Audio] Listen error:', e);
    });
  }, [listenOnce]);

  const stopRecording = useCallback(() => {
    stopListening();
  }, [stopListening]);

  return {
    isRecording,
    isProcessing,
    transcript,
    startRecording,
    stopRecording,
    stopListening,
    listenOnce,
    listenForStop,
    resetTranscript,
    isSupported,
  };
}
