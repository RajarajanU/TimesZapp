import { useState, useCallback, useEffect, useRef } from 'react';
import { api } from '@/lib/api';

export type VoiceStyle = 'professional' | 'friendly' | 'energetic' | 'calm';
export type VoiceGender = 'male' | 'female';
export type VoiceMode = 'default' | 'custom' | 'cloned';

interface VoiceStyleOption {
  id: VoiceStyle;
  label: string;
  description: string;
  pitchModifier: number;
  rateModifier: number;
}

const VOICE_STYLE_OPTIONS: VoiceStyleOption[] = [
  { 
    id: 'professional', 
    label: 'Professional', 
    description: 'Clear and authoritative',
    pitchModifier: -0.05,
    rateModifier: -0.05
  },
  { 
    id: 'friendly', 
    label: 'Friendly', 
    description: 'Warm and approachable',
    pitchModifier: 0.05,
    rateModifier: 0.05
  },
  { 
    id: 'energetic', 
    label: 'Energetic', 
    description: 'Upbeat and enthusiastic',
    pitchModifier: 0.15,
    rateModifier: 0.15
  },
  { 
    id: 'calm', 
    label: 'Calm', 
    description: 'Soothing and relaxed',
    pitchModifier: -0.02,
    rateModifier: -0.12
  },
];

const MALE_VOICE_KEYWORDS = [
  'male',
  'guy',
  'man',
  'david',
  'george',
  'daniel',
  'alex',
  'oliver',
  'arthur',
  'tom',
  'fred',
  'james',
  'john',
  'william',
  'rishi',
  'aaron',
  'en-gb-x-rjs',
  'en-us-x-sfg',
  'en-au-x-aub'
];

const FEMALE_VOICE_KEYWORDS = [
  'female',
  'woman',
  'girl',
  'samantha',
  'zira',
  'hazel',
  'karen',
  'victoria',
  'serena',
  'kate',
  'fiona',
  'moira',
  'susan',
  'lisa',
  'allison',
  'amelie',
  'en-gb-x-gba',
  'en-us-x-sfg#female',
  'en-au-x-aua'
];

const BASE_PITCH = { male: 0.5, female: 1.2 };
const BASE_RATE = 1.0;

function getStoredVoiceStyle(): VoiceStyle {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('voiceStyle');
    if (stored && VOICE_STYLE_OPTIONS.some(v => v.id === stored)) {
      return stored as VoiceStyle;
    }
  }
  return 'friendly';
}

function getStoredVoiceGender(): VoiceGender {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('voiceGender');
    if (stored === 'male' || stored === 'female') {
      return stored;
    }
  }
  return 'female';
}

function getStoredAutoSpeak(): boolean {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('autoSpeak');
    if (stored === null) return true;
    return stored === 'true';
  }
  return true;
}

function getStoredVoiceMode(): VoiceMode {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('voiceMode');
    if (stored === 'custom' || stored === 'cloned') return stored as VoiceMode;
  }
  return 'default';
}

function getStoredCustomVoiceName(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('customVoiceName');
  }
  return null;
}

function getStoredCustomPitch(): number {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('customVoicePitch');
    if (stored) return parseFloat(stored);
  }
  return 1.0;
}

function getStoredCustomRate(): number {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('customVoiceRate');
    if (stored) return parseFloat(stored);
  }
  return 1.0;
}

function findVoiceByGender(voices: SpeechSynthesisVoice[], gender: VoiceGender): SpeechSynthesisVoice | null {
  const keywords = gender === 'male' ? MALE_VOICE_KEYWORDS : FEMALE_VOICE_KEYWORDS;
  
  for (const keyword of keywords) {
    const match = voices.find(v => 
      v.name.toLowerCase().includes(keyword.toLowerCase()) ||
      v.voiceURI.toLowerCase().includes(keyword.toLowerCase())
    );
    if (match) return match;
  }
  
  const englishVoices = voices.filter(v => v.lang.startsWith('en'));
  if (englishVoices.length > 0) {
    return englishVoices[0];
  }
  
  return voices[0] || null;
}

export function useSpeechSynthesis() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceStyle, setVoiceStyleState] = useState<VoiceStyle>(getStoredVoiceStyle);
  const [voiceGender, setVoiceGenderState] = useState<VoiceGender>(getStoredVoiceGender);
  const [autoSpeak, setAutoSpeakState] = useState(getStoredAutoSpeak);
  const [voiceMode, setVoiceModeState] = useState<VoiceMode>(getStoredVoiceMode);
  const [customVoiceName, setCustomVoiceNameState] = useState<string | null>(getStoredCustomVoiceName);
  const [customPitch, setCustomPitchState] = useState<number>(getStoredCustomPitch);
  const [customRate, setCustomRateState] = useState<number>(getStoredCustomRate);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isSupported, setIsSupported] = useState(true);
  const [hasClonedVoice, setHasClonedVoice] = useState(false);
  const elevenLabsAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!('speechSynthesis' in window)) {
      setIsSupported(false);
      return;
    }

    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        setAvailableVoices(voices);
        console.log('[TTS] Available voices:', voices.map(v => `${v.name} (${v.lang})`).join(', '));
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  useEffect(() => {
    api.getVoiceStatus().then(status => {
      setHasClonedVoice(status.hasClonedVoice);
      if (status.hasClonedVoice) {
        setVoiceModeState('cloned');
        localStorage.setItem('voiceMode', 'cloned');
      }
    }).catch(() => {});
  }, []);

  const setVoiceStyle = useCallback((style: VoiceStyle) => {
    setVoiceStyleState(style);
    localStorage.setItem('voiceStyle', style);
  }, []);

  const setVoiceGender = useCallback((gender: VoiceGender) => {
    setVoiceGenderState(gender);
    localStorage.setItem('voiceGender', gender);
  }, []);

  const setAutoSpeak = useCallback((enabled: boolean) => {
    setAutoSpeakState(enabled);
    localStorage.setItem('autoSpeak', String(enabled));
  }, []);

  const setVoiceMode = useCallback((mode: VoiceMode) => {
    setVoiceModeState(mode);
    localStorage.setItem('voiceMode', mode);
  }, []);

  const setCustomVoice = useCallback((voiceName: string, pitch: number, rate: number) => {
    setCustomVoiceNameState(voiceName);
    setCustomPitchState(pitch);
    setCustomRateState(rate);
    localStorage.setItem('customVoiceName', voiceName);
    localStorage.setItem('customVoicePitch', String(pitch));
    localStorage.setItem('customVoiceRate', String(rate));
  }, []);

  const setCustomPitch = useCallback((pitch: number) => {
    setCustomPitchState(pitch);
    localStorage.setItem('customVoicePitch', String(pitch));
  }, []);

  const setCustomRate = useCallback((rate: number) => {
    setCustomRateState(rate);
    localStorage.setItem('customVoiceRate', String(rate));
  }, []);

  const getVoiceSettings = useCallback((style: VoiceStyle, gender: VoiceGender) => {
    const styleOption = VOICE_STYLE_OPTIONS.find(v => v.id === style) || VOICE_STYLE_OPTIONS[0];
    const pitch = Math.max(0.1, Math.min(2, BASE_PITCH[gender] + styleOption.pitchModifier));
    const rate = Math.max(0.5, Math.min(2, BASE_RATE + styleOption.rateModifier));
    return { pitch, rate };
  }, []);

  const removeEmojis = useCallback((str: string) => {
    return Array.from(str).filter(char => {
      const code = char.codePointAt(0) || 0;
      if (code >= 0x1F300 && code <= 0x1F9FF) return false;
      if (code >= 0x2600 && code <= 0x26FF) return false;
      if (code >= 0x2700 && code <= 0x27BF) return false;
      if (code >= 0x1F000 && code <= 0x1F02F) return false;
      if (code >= 0x1F0A0 && code <= 0x1F0FF) return false;
      if (code >= 0x1FA00 && code <= 0x1FAFF) return false;
      if (code >= 0x2300 && code <= 0x23FF) return false;
      if (code >= 0xFE00 && code <= 0xFE0F) return false;
      if (code === 0x200D) return false;
      if (code === 0x20E3) return false;
      if (code >= 0xE0020 && code <= 0xE007F) return false;
      if (code >= 0x2B50 && code <= 0x2B55) return false;
      if (code >= 0x231A && code <= 0x231B) return false;
      if (code >= 0x23E9 && code <= 0x23F3) return false;
      if (code >= 0x25AA && code <= 0x25FE) return false;
      if (code >= 0x2934 && code <= 0x2935) return false;
      if (code >= 0x2B05 && code <= 0x2B07) return false;
      if (code >= 0x2B1B && code <= 0x2B1C) return false;
      if (code >= 0x3030 && code <= 0x303D) return false;
      if (code >= 0x3297 && code <= 0x3299) return false;
      return true;
    }).join('');
  }, []);

  const speakWithElevenLabs = useCallback(async (text: string, onEnd?: () => void, onStart?: () => void) => {
    try {
      console.log('[TTS] Fetching ElevenLabs audio...');
      
      const audioBlob = await api.textToSpeech(text);
      if (!audioBlob) {
        console.warn('[TTS] ElevenLabs TTS failed, falling back to browser TTS');
        return false;
      }
      
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      elevenLabsAudioRef.current = audio;
      
      audio.onplay = () => {
        console.log('[TTS] Audio started playing');
        setIsSpeaking(true);
        onStart?.();
      };
      
      audio.onended = () => {
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
        elevenLabsAudioRef.current = null;
        onEnd?.();
      };
      
      audio.onerror = () => {
        console.error('[TTS] ElevenLabs audio playback error');
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
        elevenLabsAudioRef.current = null;
        onEnd?.();
      };
      
      await audio.play();
      return true;
    } catch (error) {
      console.error('[TTS] ElevenLabs TTS error:', error);
      setIsSpeaking(false);
      onEnd?.();
      return false;
    }
  }, []);

  const speak = useCallback(async (text: string, options?: { force?: boolean; onEnd?: () => void; onStart?: () => void }) => {
    const { force = false, onEnd, onStart } = options || {};
    let onEndCalled = false;
    let speechTimeout: NodeJS.Timeout | null = null;
    
    const safeOnEnd = () => {
      if (onEndCalled) return;
      onEndCalled = true;
      if (speechTimeout) {
        clearTimeout(speechTimeout);
        speechTimeout = null;
      }
      setIsSpeaking(false);
      onEnd?.();
    };

    if (!force && !autoSpeak) {
      safeOnEnd();
      return;
    }
    
    const cleanText = removeEmojis(text)
      .replace(/[*_~`#]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    
    if (!cleanText) {
      safeOnEnd();
      return;
    }

    // Give plenty of time for audio playback - 120ms per character with 10 second minimum
    const estimatedDuration = Math.max(10000, cleanText.length * 120);
    speechTimeout = setTimeout(() => {
      console.warn('[TTS] Speech timeout after', estimatedDuration, 'ms, forcing onEnd');
      if (elevenLabsAudioRef.current) {
        elevenLabsAudioRef.current.pause();
        elevenLabsAudioRef.current = null;
      }
      if ('speechSynthesis' in window && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      safeOnEnd();
    }, estimatedDuration);

    try {
      const success = await speakWithElevenLabs(cleanText, safeOnEnd, onStart);
      if (success) {
        return;
      }
    } catch (e) {
      console.log('[TTS] ElevenLabs failed, falling back to browser TTS');
    }
    
    if (!('speechSynthesis' in window)) {
      console.warn("Text-to-speech not supported");
      safeOnEnd();
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    
    const voices = availableVoices.length > 0 
      ? availableVoices 
      : window.speechSynthesis.getVoices();
    
    if (voiceMode === 'custom' && customVoiceName) {
      const customVoice = voices.find(v => v.name === customVoiceName);
      if (customVoice) {
        utterance.voice = customVoice;
        utterance.pitch = customPitch;
        utterance.rate = customRate;
        console.log(`[TTS] Using CUSTOM voice: ${customVoice.name}, pitch: ${customPitch}, rate: ${customRate}`);
      } else {
        const { pitch, rate } = getVoiceSettings(voiceStyle, voiceGender);
        utterance.pitch = pitch;
        utterance.rate = rate;
        const selectedVoice = findVoiceByGender(voices, voiceGender);
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
      }
    } else {
      const { pitch, rate } = getVoiceSettings(voiceStyle, voiceGender);
      utterance.pitch = pitch;
      utterance.rate = rate;
      
      if (voices.length > 0) {
        const selectedVoice = findVoiceByGender(voices, voiceGender);
        if (selectedVoice) {
          utterance.voice = selectedVoice;
          console.log(`[TTS] Using voice: ${selectedVoice.name}, pitch: ${pitch}, rate: ${rate}, gender: ${voiceGender}`);
        }
      }
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => safeOnEnd();
    utterance.onerror = (e) => {
      console.error('Speech synthesis error:', e);
      safeOnEnd();
    };

    window.speechSynthesis.speak(utterance);
  }, [voiceStyle, voiceGender, autoSpeak, availableVoices, getVoiceSettings, voiceMode, customVoiceName, customPitch, customRate, removeEmojis, speakWithElevenLabs]);

  const cancel = useCallback(() => {
    if (elevenLabsAudioRef.current) {
      elevenLabsAudioRef.current.pause();
      elevenLabsAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  const testVoice = useCallback((style: VoiceStyle, gender?: VoiceGender) => {
    if (!('speechSynthesis' in window)) return;
    
    window.speechSynthesis.cancel();
    
    const genderToUse = gender || voiceGender;
    const testText = style === 'professional' 
      ? "Hello, I'm your professional AI assistant."
      : style === 'friendly'
      ? "Hey there! I'm here to help you out!"
      : style === 'energetic'
      ? "Hi! I'm super excited to help you today!"
      : "Hello. I'm here to assist you calmly and peacefully.";
    
    const utterance = new SpeechSynthesisUtterance(testText);
    const { pitch, rate } = getVoiceSettings(style, genderToUse);
    utterance.pitch = pitch;
    utterance.rate = rate;
    
    const tempVoices = window.speechSynthesis.getVoices();
    const selectedVoice = findVoiceByGender(tempVoices, genderToUse);
    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    window.speechSynthesis.speak(utterance);
  }, [voiceGender, getVoiceSettings]);

  const testGender = useCallback((gender: VoiceGender) => {
    if (!('speechSynthesis' in window)) return;
    
    window.speechSynthesis.cancel();
    
    const testText = gender === 'male' 
      ? "Hello, this is the male voice speaking."
      : "Hello, this is the female voice speaking.";
    
    const utterance = new SpeechSynthesisUtterance(testText);
    const { pitch, rate } = getVoiceSettings(voiceStyle, gender);
    utterance.pitch = pitch;
    utterance.rate = rate;
    
    const tempVoices = window.speechSynthesis.getVoices();
    const selectedVoice = findVoiceByGender(tempVoices, gender);
    if (selectedVoice) {
      utterance.voice = selectedVoice;
      console.log(`[TTS] Testing gender: ${gender}, voice: ${selectedVoice.name}, pitch: ${pitch}`);
    }
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    window.speechSynthesis.speak(utterance);
  }, [voiceStyle, getVoiceSettings]);

  const testCustomVoice = useCallback((voiceName: string, pitch: number, rate: number) => {
    if (!('speechSynthesis' in window)) return;
    
    window.speechSynthesis.cancel();
    
    const testText = "Hello! This is how I sound with your custom voice settings.";
    const utterance = new SpeechSynthesisUtterance(testText);
    utterance.pitch = pitch;
    utterance.rate = rate;
    
    const tempVoices = window.speechSynthesis.getVoices();
    const voice = tempVoices.find(v => v.name === voiceName);
    if (voice) {
      utterance.voice = voice;
      console.log(`[TTS] Testing custom voice: ${voice.name}, pitch: ${pitch}, rate: ${rate}`);
    }
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    window.speechSynthesis.speak(utterance);
  }, []);

  return { 
    speak, 
    cancel, 
    isSpeaking,
    voiceStyle,
    setVoiceStyle,
    voiceGender,
    setVoiceGender,
    autoSpeak,
    setAutoSpeak,
    voiceMode,
    setVoiceMode,
    customVoiceName,
    customPitch,
    customRate,
    setCustomVoice,
    setCustomPitch,
    setCustomRate,
    testVoice,
    testGender,
    testCustomVoice,
    availableVoices,
    voiceStyleOptions: VOICE_STYLE_OPTIONS,
    isSupported,
    hasClonedVoice,
    setHasClonedVoice
  };
}
