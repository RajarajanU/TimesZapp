import { pgTable, text, serial, timestamp, jsonb, boolean, integer } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique().notNull(),
  name: text("name"),
  password: text("password").notNull(),
  elevenlabsVoiceId: text("elevenlabs_voice_id"),
  elevenlabsVoiceName: text("elevenlabs_voice_name"),
  techNewsNotifications: boolean("tech_news_notifications").default(false),
  phoneNumber: text("phone_number"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  conversations: many(conversations),
  connectedServices: many(connectedServices),
  notifications: many(notifications),
  socialItems: many(socialItems),
  aiInsights: many(aiInsights),
  reminders: many(reminders),
}));

// Conversations (chat history)
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, {
    fields: [conversations.userId],
    references: [users.id],
  }),
  messages: many(messages),
}));

// Messages within conversations
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  role: text("role").notNull(), // 'user' | 'assistant' | 'system'
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // for storing rich content like charts, images, etc.
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

// Connected Services (Gmail, LinkedIn, etc.)
export const connectedServices = pgTable("connected_services", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  serviceName: text("service_name").notNull(), // 'gmail', 'linkedin', 'twitter', etc.
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  metadata: jsonb("metadata"), // service-specific data
  isActive: boolean("is_active").default(true),
  connectedAt: timestamp("connected_at").defaultNow().notNull(),
});

export const connectedServicesRelations = relations(connectedServices, ({ one }) => ({
  user: one(users, {
    fields: [connectedServices.userId],
    references: [users.id],
  }),
}));

// Notifications aggregated from all services
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  source: text("source").notNull(), // 'gmail', 'linkedin', 'system', etc.
  type: text("type").notNull(), // 'email', 'message', 'job', 'alert'
  title: text("title").notNull(),
  description: text("description"),
  isRead: boolean("is_read").default(false),
  metadata: jsonb("metadata"), // original notification data
  receivedAt: timestamp("received_at").defaultNow().notNull(),
});

// Password reset tokens
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  token: text("token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Social Items - Normalized data from all social networks for AI analysis
export const socialItems = pgTable("social_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  source: text("source").notNull(), // 'gmail', 'facebook', 'instagram', 'linkedin', 'twitter', 'whatsapp'
  itemType: text("item_type").notNull(), // 'email', 'post', 'message', 'story', 'comment', 'news'
  title: text("title"),
  content: text("content"),
  author: text("author"), // sender name or account
  authorHandle: text("author_handle"), // @username or email
  url: text("url"), // link to original item
  mediaUrls: text("media_urls").array(), // attached images/videos
  trustScore: integer("trust_score"), // 0-100, AI-calculated reliability score
  sentiment: text("sentiment"), // 'positive', 'negative', 'neutral'
  tags: text("tags").array(), // AI-detected topics/categories
  isVerified: boolean("is_verified").default(false), // verified source
  engagementCount: integer("engagement_count").default(0), // likes, shares, etc
  rawData: jsonb("raw_data"), // original API response
  fetchedAt: timestamp("fetched_at").defaultNow().notNull(),
  itemDate: timestamp("item_date"), // when the original item was created
});

export const socialItemsRelations = relations(socialItems, ({ one }) => ({
  user: one(users, {
    fields: [socialItems.userId],
    references: [users.id],
  }),
}));

// AI Insights - Generated trends, summaries, and proactive suggestions
export const aiInsights = pgTable("ai_insights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  insightType: text("insight_type").notNull(), // 'trend', 'digest', 'alert', 'travel', 'recommendation'
  title: text("title").notNull(),
  content: text("content").notNull(),
  sources: text("sources").array(), // which networks contributed
  relatedItemIds: integer("related_item_ids").array(), // social_items IDs
  priority: text("priority").default("normal"), // 'low', 'normal', 'high', 'urgent'
  metadata: jsonb("metadata"), // extra data like locations, dates, etc
  isRead: boolean("is_read").default(false),
  expiresAt: timestamp("expires_at"), // when insight becomes stale
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiInsightsRelations = relations(aiInsights, ({ one }) => ({
  user: one(users, {
    fields: [aiInsights.userId],
    references: [users.id],
  }),
}));

// Reminders - User-set alerts and scheduled notifications
export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  remindAt: timestamp("remind_at").notNull(),
  isCompleted: boolean("is_completed").default(false),
  isNotified: boolean("is_notified").default(false),
  priority: text("priority").default("normal"), // 'low', 'normal', 'high', 'urgent'
  recurrence: text("recurrence"), // 'none', 'daily', 'weekly', 'monthly'
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const remindersRelations = relations(reminders, ({ one }) => ({
  user: one(users, {
    fields: [reminders.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Tech News - Mr Techie agent hourly technology updates
export const techNews = pgTable("tech_news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  source: text("source"),
  url: text("url"),
  category: text("category"), // 'ai', 'mobile', 'web', 'security', 'startups', etc.
  hourBucket: timestamp("hour_bucket").notNull(), // The hour this news was fetched for
  fetchedAt: timestamp("fetched_at").defaultNow().notNull(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type ConnectedService = typeof connectedServices.$inferSelect;
export type InsertConnectedService = z.infer<typeof insertConnectedServiceSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = z.infer<typeof insertPasswordResetTokenSchema>;

export type SocialItem = typeof socialItems.$inferSelect;
export type InsertSocialItem = z.infer<typeof insertSocialItemSchema>;

export type AiInsight = typeof aiInsights.$inferSelect;
export type InsertAiInsight = z.infer<typeof insertAiInsightSchema>;

export type Reminder = typeof reminders.$inferSelect;
export type InsertReminder = z.infer<typeof insertReminderSchema>;

// Zod schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const selectUserSchema = createSelectSchema(users);

export const insertConversationSchema = createInsertSchema(conversations).omit({ id: true, createdAt: true, updatedAt: true });
export const selectConversationSchema = createSelectSchema(conversations);

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true });
export const selectMessageSchema = createSelectSchema(messages);

export const insertConnectedServiceSchema = createInsertSchema(connectedServices).omit({ id: true, connectedAt: true });
export const selectConnectedServiceSchema = createSelectSchema(connectedServices);

export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, receivedAt: true });
export const selectNotificationSchema = createSelectSchema(notifications);

export const insertPasswordResetTokenSchema = createInsertSchema(passwordResetTokens).omit({ id: true, createdAt: true });
export const selectPasswordResetTokenSchema = createSelectSchema(passwordResetTokens);

export const insertSocialItemSchema = createInsertSchema(socialItems).omit({ id: true, fetchedAt: true });
export const selectSocialItemSchema = createSelectSchema(socialItems);

export const insertAiInsightSchema = createInsertSchema(aiInsights).omit({ id: true, createdAt: true });
export const selectAiInsightSchema = createSelectSchema(aiInsights);

export const insertReminderSchema = createInsertSchema(reminders).omit({ id: true, createdAt: true });
export const selectReminderSchema = createSelectSchema(reminders);

export const insertTechNewsSchema = createInsertSchema(techNews).omit({ id: true, fetchedAt: true });
export const selectTechNewsSchema = createSelectSchema(techNews);

export type TechNews = typeof techNews.$inferSelect;
export type InsertTechNews = z.infer<typeof insertTechNewsSchema>;

// Friends / Friend Requests table
export const friendships = pgTable("friendships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  friendId: integer("friend_id").notNull().references(() => users.id),
  status: text("status").notNull().default("pending"), // 'pending', 'accepted', 'declined'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const friendshipsRelations = relations(friendships, ({ one }) => ({
  user: one(users, {
    fields: [friendships.userId],
    references: [users.id],
  }),
  friend: one(users, {
    fields: [friendships.friendId],
    references: [users.id],
  }),
}));

export const insertFriendshipSchema = createInsertSchema(friendships).omit({ id: true, createdAt: true, updatedAt: true });
export const selectFriendshipSchema = createSelectSchema(friendships);

export type Friendship = typeof friendships.$inferSelect;
export type InsertFriendship = z.infer<typeof insertFriendshipSchema>;
